## Deprecated Assets

##### 2024-11-21

- Old launcher has been deprecated due to it not supporting non-Linux platforms, and for using FF's debugging protocol to load addons [#90](https://github.com/daijro/lucid_browser/issues/90).
- `generate-locales.sh` (based on [LibreWolf's locale build system](https://gitlab.com/librewolf-community/browser/source/-/blob/3dc56de7b0665724bf3842198cebe961c42a81e0/scripts/generate-locales.sh)) was deprecated due to "Lucid Empire" leaking to the page [#90](https://github.com/daijro/lucid_browser/issues/90).