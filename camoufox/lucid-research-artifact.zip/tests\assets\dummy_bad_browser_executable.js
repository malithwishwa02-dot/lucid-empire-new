#!/usr/bin/env node

process.exit(1);
