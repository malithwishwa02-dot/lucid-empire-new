window.__injected = 42;
window.injected = 123;
window.__injectedError = new Error('hi');
