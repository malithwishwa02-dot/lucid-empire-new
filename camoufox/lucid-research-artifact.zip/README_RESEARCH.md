# Lucid Empire (Research Copy)
stripped-down version containing only source logic and patches.
Binaries and assets removed to minimize footprint.
