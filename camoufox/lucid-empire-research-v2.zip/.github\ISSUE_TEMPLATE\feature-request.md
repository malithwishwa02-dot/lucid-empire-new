---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

--- 

### Describe the feature:

Describe an idea for this project. Provide as much detail and additional context as possible.

### Is your feature request related to a problem? Please describe.

If you are looking to solve a problem, please describe it!