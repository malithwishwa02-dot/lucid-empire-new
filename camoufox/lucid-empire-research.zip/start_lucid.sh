#!/bin/bash
echo "[*] LUCID EMPIRE INITIALIZATION..."
echo "[*] Installing GUI Dependencies..."
pip3 install tk --quiet
echo "[*] Launching Commander..."
python3 lucid_manager.py
