# LUCID EMPIRE v5.0.0-TITAN :: Platform Launchers

## Quick Start

### Installation (Windows)
```batch
platforms\INSTALL_LUCID.bat
```
This will:
1. Create virtual environment
2. Install all dependencies
3. Install local Camoufox module from `camoufox/pythonlib`
4. Fetch Camoufox browser binary (530MB)
5. Install Playwright Firefox fallback
6. Create desktop shortcut

### Launch Browser
```batch
platforms\LAUNCH_LUCID.bat
```

Or use the GUI:
```batch
python platforms\windows\lucid_control_panel_windows.py
```

---

## Directory Structure

```
platforms/
├── INSTALL_LUCID.bat          # Windows installer
├── LAUNCH_LUCID.bat           # Windows unified launcher
├── unified_launcher.py        # Cross-platform Python launcher
├── README.md                  # This file
│
├── windows/
│   ├── lucid_control_panel_windows.py  # Full GUI control panel
│   ├── setup_lucid.ps1                 # PowerShell setup script
│   └── LAUNCH_INSTALLER.bat            # Legacy installer
│
├── linux/
│   └── (TITAN Class launchers)
│
└── common/
    ├── config_template.json    # Profile configuration template
    └── requirements.txt        # Common dependencies
```

---

## Launch Options

### Command Line
```batch
# Interactive menu
python platforms\unified_launcher.py

# List profiles
python platforms\unified_launcher.py --list-profiles

# Launch with profile
python platforms\unified_launcher.py --profile Titan_SoftwareEng_USA_001

# Headless mode
python platforms\unified_launcher.py --headless

# With proxy
python platforms\unified_launcher.py --proxy 192.168.1.1:8080
```

### Launcher Modes
| Mode | Description |
|------|-------------|
| GUI Control Panel | Full graphical interface with profile management |
| Profile Launch | Launch with specific aged profile |
| Headless | No visible window (for automation) |
| Generate Profile | Create new aged profile with Genesis Engine |
| Stealth Audit | Verify anti-detect capabilities |

---

## Anti-Detect Features

### STEALTH Class (Windows)
- ✅ Canvas/WebGL fingerprint spoofing
- ✅ WebRTC IP leak protection
- ✅ Human-like mouse/keyboard behavior
- ✅ Timezone/locale spoofing
- ✅ WinDivert network masking (admin required)

### TITAN Class (Linux)
- ✅ All STEALTH features
- ✅ eBPF/XDP kernel-level network masking
- ✅ libfaketime system time spoofing
- ✅ Full hardware signature masking

---

## Camoufox Integration

The local Camoufox module at `camoufox/pythonlib` is automatically used before the PyPI version. This allows custom modifications.

### Binary Download
If Camoufox binary is not installed:
```batch
python -m camoufox fetch
```

### Verify Installation
```batch
python -c "from camoufox.pkgman import camoufox_path; print(camoufox_path())"
```

---

## Troubleshooting

### "Camoufox binary not found"
Run: `python -m camoufox fetch`

### "Administrator privileges required"
Right-click → Run as Administrator

### "PyQt6 not installed"
Run: `pip install PyQt6`

### Font warnings in GUI
Harmless Qt warnings, can be ignored.

---

## Version

LUCID EMPIRE v5.0.0-TITAN
Authority: Dva.12 | PROMETHEUS-CORE v2.1
