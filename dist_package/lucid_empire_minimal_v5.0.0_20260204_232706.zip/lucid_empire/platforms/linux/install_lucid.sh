#!/bin/bash
################################################################################
# LUCID EMPIRE v5 TITAN :: LINUX INSTALLER (SOVEREIGN CLASS)
# Authority: Dva.12
# Platform: Linux (Debian/Ubuntu/Arch)
# Technology: eBPF Kernel Masking + Libfaketime + Systemd
################################################################################

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
LUCID_HOME="${LUCID_HOME:-$HOME/.lucid-empire}"
LUCID_USER="lucid-agent"
LUCID_UID=1337
INSTALL_LOG="${LUCID_HOME}/install.log"

################################################################################
# PHASE 1: PRE-FLIGHT CHECKS
################################################################################

phase_checks() {
    echo -e "${BLUE}[PHASE 1] PRE-FLIGHT CHECKS${NC}"
    
    # Check if running on Linux
    if [[ ! "$OSTYPE" =~ linux ]]; then
        echo -e "${RED}✗ ERROR: This installer is for Linux only${NC}"
        echo "  Current OS: $OSTYPE"
        echo "  For Windows, use: platforms/windows/setup_lucid.ps1"
        exit 1
    fi
    
    # Check if running as root (required for CAP_NET_ADMIN)
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}✗ ERROR: This installer must be run as root (sudo)${NC}"
        echo "  Reason: eBPF programs require CAP_NET_ADMIN capability"
        exit 1
    fi
    
    # Check for required commands
    local required_commands=("clang" "llvm-objcopy" "apt-get" "python3" "pip3")
    for cmd in "${required_commands[@]}"; do
        if ! command -v "$cmd" &> /dev/null; then
            echo -e "${YELLOW}⚠ WARNING: $cmd not found${NC}"
            MISSING_DEPS+=("$cmd")
        fi
    done
    
    # Check for bpftool
    if ! command -v bpftool &> /dev/null; then
        echo -e "${YELLOW}⚠ WARNING: bpftool not found${NC}"
        echo "   This is required for XDP program management"
        MISSING_BPFTOOL=1
    fi
    
    # Check kernel version (need 5.8+ for XDP)
    KERNEL_VERSION=$(uname -r | cut -d. -f1,2)
    REQUIRED_KERNEL="5.8"
    if (( $(echo "$KERNEL_VERSION < $REQUIRED_KERNEL" | bc -l) )); then
        echo -e "${RED}✗ ERROR: Kernel version $KERNEL_VERSION is too old${NC}"
        echo "   Required: $REQUIRED_KERNEL or newer (for XDP support)"
        exit 1
    fi
    
    echo -e "${GREEN}✓ Linux system detected${NC}"
    echo -e "${GREEN}✓ Running as root${NC}"
    echo -e "${GREEN}✓ Kernel version: $KERNEL_VERSION (XDP compatible)${NC}"
    
    # Offer to install missing deps
    if [[ ${#MISSING_DEPS[@]} -gt 0 ]]; then
        echo ""
        echo -e "${YELLOW}Missing dependencies: ${MISSING_DEPS[*]}${NC}"
        read -p "Install missing dependencies? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            install_dependencies
        fi
    fi
    
    echo ""
}

################################################################################
# PHASE 2: DEPENDENCY INSTALLATION
################################################################################

install_dependencies() {
    echo -e "${BLUE}[PHASE 2] INSTALLING DEPENDENCIES${NC}"
    
    # Update package manager
    echo "Updating package manager..."
    apt-get update -qq
    
    # Core build tools
    echo "Installing build tools..."
    apt-get install -y build-essential clang llvm linux-headers-$(uname -r) bc
    
    # eBPF tools
    echo "Installing eBPF tools..."
    apt-get install -y linux-tools-generic bpftool
    
    # Runtime dependencies
    echo "Installing runtime dependencies..."
    apt-get install -y libfaketime python3 python3-venv python3-pip git curl wget
    
    # Cleanup
    apt-get autoremove -y -qq
    
    echo -e "${GREEN}✓ Dependencies installed${NC}"
    echo ""
}

################################################################################
# PHASE 3: CREATE LUCID USER & ENVIRONMENT
################################################################################

setup_user_environment() {
    echo -e "${BLUE}[PHASE 3] SETTING UP USER & ENVIRONMENT${NC}"
    
    # Create lucid-agent system user
    if ! id "$LUCID_USER" &>/dev/null; then
        echo "Creating system user: $LUCID_USER"
        useradd -r -s /bin/bash -u $LUCID_UID -m -d "$LUCID_HOME" "$LUCID_USER"
    else
        echo "User $LUCID_USER already exists"
    fi
    
    # Create installation directory
    mkdir -p "$LUCID_HOME"
    mkdir -p "$LUCID_HOME/bin"
    mkdir -p "$LUCID_HOME/etc"
    mkdir -p "$LUCID_HOME/lib"
    mkdir -p "$LUCID_HOME/var/cache"
    mkdir -p "$LUCID_HOME/var/log"
    
    # Set permissions
    chown -R "$LUCID_USER:$LUCID_USER" "$LUCID_HOME"
    chmod 755 "$LUCID_HOME"
    chmod 700 "$LUCID_HOME/etc"
    
    echo -e "${GREEN}✓ User environment created: $LUCID_HOME${NC}"
    echo ""
}

################################################################################
# PHASE 4: COMPILE eBPF PROGRAM
################################################################################

compile_ebpf() {
    echo -e "${BLUE}[PHASE 4] COMPILING eBPF PROGRAM${NC}"
    
    local xdp_source="$LUCID_HOME/lib/xdp_outbound.c"
    local xdp_object="$LUCID_HOME/lib/xdp_outbound.o"
    
    # Check if source exists
    if [[ ! -f "$xdp_source" ]]; then
        echo -e "${YELLOW}⚠ XDP source not found at $xdp_source${NC}"
        echo "  Copying from repository..."
        cp ../../../backend/network/xdp_outbound.c "$xdp_source" 2>/dev/null || {
            echo -e "${RED}✗ Could not copy XDP source${NC}"
            return 1
        }
    fi
    
    echo "Compiling XDP program..."
    clang -O2 -target bpf \
        -D__KERNEL__ -D__BPF_TRACING__ \
        -c "$xdp_source" -o "$xdp_object" 2>&1 | tee -a "$INSTALL_LOG"
    
    if [[ $? -eq 0 ]]; then
        echo -e "${GREEN}✓ eBPF compilation successful${NC}"
        echo "  Object: $xdp_object"
        llvm-objdump -S "$xdp_object" > "${xdp_object%.o}.dump"
        echo "  Disassembly: ${xdp_object%.o}.dump"
    else
        echo -e "${RED}✗ eBPF compilation failed${NC}"
        return 1
    fi
    
    # Verify object
    file "$xdp_object"
    ls -lh "$xdp_object"
    
    echo ""
}

################################################################################
# PHASE 5: BUILD LIBFAKETIME
################################################################################

setup_libfaketime() {
    echo -e "${BLUE}[PHASE 5] SETTING UP LIBFAKETIME${NC}"
    
    # Check if libfaketime.so exists
    local libfaketime_path="/usr/lib/x86_64-linux-gnu/libfaketime.so.1"
    
    if [[ -f "$libfaketime_path" ]]; then
        echo -e "${GREEN}✓ libfaketime found: $libfaketime_path${NC}"
    else
        echo "Installing libfaketime..."
        apt-get install -y libfaketime
    fi
    
    # Create faketime configuration
    local faketime_conf="$LUCID_HOME/etc/faketime.conf"
    cat > "$faketime_conf" << 'EOF'
# LUCID EMPIRE Faketime Configuration
# Time displacement: 90 days in the past
# This allows the system to simulate aged profile activity

FAKETIME_START_DATE=-90d
FAKETIME_NO_FAKE_MONOTONIC=1
FAKETIME_DONT_RESET=1
FAKETIME_FOLLOW_FILE=/tmp/lucid_time_control
EOF
    
    chown "$LUCID_USER:$LUCID_USER" "$faketime_conf"
    chmod 600 "$faketime_conf"
    
    echo -e "${GREEN}✓ libfaketime configured${NC}"
    echo "  Config: $faketime_conf"
    
    echo ""
}

################################################################################
# PHASE 6: SET UP CAPABILITIES & SECURITY
################################################################################

setup_capabilities() {
    echo -e "${BLUE}[PHASE 6] CONFIGURING CAPABILITIES & SECURITY${NC}"
    
    # Find Python binary
    local python_bin="$(which python3)"
    
    # Grant CAP_NET_ADMIN to Python (for eBPF loading)
    echo "Setting CAP_NET_ADMIN capability..."
    setcap cap_net_admin+ep "$python_bin"
    
    # Verify capability
    if getcap "$python_bin" | grep -q "cap_net_admin"; then
        echo -e "${GREEN}✓ CAP_NET_ADMIN set on $python_bin${NC}"
    else
        echo -e "${RED}✗ Failed to set CAP_NET_ADMIN${NC}"
        return 1
    fi
    
    # Create iptables fail-safe rule
    echo "Setting up iptables fail-safe..."
    iptables -A OUTPUT -m owner --uid-owner "$LUCID_UID" -j ACCEPT -i lo -m comment --comment "lucid-loopback"
    # (This rule is temporary; permanent rules should be in /etc/iptables/rules.v4)
    
    echo -e "${GREEN}✓ Capabilities configured${NC}"
    echo ""
}

################################################################################
# PHASE 7: CREATE SYSTEMD SERVICE
################################################################################

setup_systemd_service() {
    echo -e "${BLUE}[PHASE 7] CREATING SYSTEMD SERVICE${NC}"
    
    local service_file="/etc/systemd/system/lucid-empire.service"
    
    cat > "$service_file" << EOF
[Unit]
Description=LUCID EMPIRE v5 TITAN (API Server)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$LUCID_USER
WorkingDirectory=$LUCID_HOME
ExecStart=$LUCID_HOME/bin/lucid_api.sh
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal

# Environment for eBPF and libfaketime
Environment="PATH=$LUCID_HOME/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
Environment="LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libfaketime.so.1"
Environment="FAKETIME_FOLLOW_FILE=/tmp/lucid_time_control"

# Security
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$LUCID_HOME

[Install]
WantedBy=multi-user.target
EOF
    
    # Create wrapper script
    local wrapper_script="$LUCID_HOME/bin/lucid_api.sh"
    cat > "$wrapper_script" << 'EOF'
#!/bin/bash
# LUCID EMPIRE API Launcher
# Handles eBPF loading and environment setup

cd "$(dirname "$0")/../.."
source /etc/profile

# Load eBPF program
echo "[$(date)] Loading eBPF program..." >> $HOME/var/log/lucid.log

# Start API server
exec python3 backend/lucid_api.py
EOF
    
    chmod +x "$wrapper_script"
    chown "$LUCID_USER:$LUCID_USER" "$wrapper_script"
    
    # Reload systemd daemon
    systemctl daemon-reload
    
    echo -e "${GREEN}✓ Systemd service created${NC}"
    echo "  Service: $service_file"
    echo "  Wrapper: $wrapper_script"
    echo ""
}

################################################################################
# PHASE 8: PYTHON VIRTUAL ENVIRONMENT & DEPENDENCIES
################################################################################

setup_python_venv() {
    echo -e "${BLUE}[PHASE 8] SETTING UP PYTHON ENVIRONMENT${NC}"
    
    # Create virtual environment
    echo "Creating Python virtual environment..."
    python3 -m venv "$LUCID_HOME/venv"
    
    # Activate and upgrade
    source "$LUCID_HOME/venv/bin/activate"
    pip install --upgrade pip setuptools wheel
    
    # Install requirements
    echo "Installing Python dependencies..."
    if [[ -f "requirements.txt" ]]; then
        pip install -r requirements.txt
    else
        # Fallback
        pip install fastapi uvicorn aiofiles pydantic requests
    fi
    
    deactivate
    
    chown -R "$LUCID_USER:$LUCID_USER" "$LUCID_HOME/venv"
    
    echo -e "${GREEN}✓ Python environment ready${NC}"
    echo "  venv: $LUCID_HOME/venv"
    echo ""
}

################################################################################
# PHASE 9: COPY & SYMLINK REPOSITORY CODE
################################################################################

copy_repository_code() {
    echo -e "${BLUE}[PHASE 9] COPYING REPOSITORY CODE${NC}"
    
    # Determine repo location
    local repo_root="$(cd "$(dirname "$0")/../../.." && pwd)"
    
    echo "Repository root: $repo_root"
    
    # Copy essential directories
    echo "Copying backend code..."
    cp -r "$repo_root/backend" "$LUCID_HOME/"
    
    echo "Copying dashboard (frontend)..."
    cp -r "$repo_root/dashboard" "$LUCID_HOME/"
    
    echo "Copying aged profiles..."
    cp -r "$repo_root/lucid_profile_data" "$LUCID_HOME/"
    
    echo "Copying assets and templates..."
    cp -r "$repo_root/assets" "$LUCID_HOME/"
    
    # Create symlinks for easy access
    ln -sf "$repo_root/readme.md" "$LUCID_HOME/README.md"
    ln -sf "$repo_root/requirements.txt" "$LUCID_HOME/requirements.txt"
    
    # Fix permissions
    chown -R "$LUCID_USER:$LUCID_USER" "$LUCID_HOME/backend"
    chown -R "$LUCID_USER:$LUCID_USER" "$LUCID_HOME/lucid_profile_data"
    
    echo -e "${GREEN}✓ Repository code copied${NC}"
    echo ""
}

################################################################################
# PHASE 10: VERIFICATION & TESTS
################################################################################

verify_installation() {
    echo -e "${BLUE}[PHASE 10] VERIFICATION & TESTS${NC}"
    
    local tests_passed=0
    local tests_total=0
    
    # Test 1: Check user exists
    tests_total=$((tests_total + 1))
    if id "$LUCID_USER" &>/dev/null; then
        echo -e "${GREEN}✓ Test 1: User '$LUCID_USER' exists${NC}"
        tests_passed=$((tests_passed + 1))
    else
        echo -e "${RED}✗ Test 1: User '$LUCID_USER' not found${NC}"
    fi
    
    # Test 2: Check home directory
    tests_total=$((tests_total + 1))
    if [[ -d "$LUCID_HOME" ]]; then
        echo -e "${GREEN}✓ Test 2: Home directory exists: $LUCID_HOME${NC}"
        tests_passed=$((tests_passed + 1))
    else
        echo -e "${RED}✗ Test 2: Home directory not found${NC}"
    fi
    
    # Test 3: Check eBPF object
    tests_total=$((tests_total + 1))
    if [[ -f "$LUCID_HOME/lib/xdp_outbound.o" ]]; then
        echo -e "${GREEN}✓ Test 3: eBPF object compiled: $LUCID_HOME/lib/xdp_outbound.o${NC}"
        tests_passed=$((tests_passed + 1))
    else
        echo -e "${RED}✗ Test 3: eBPF object not found${NC}"
    fi
    
    # Test 4: Check libfaketime
    tests_total=$((tests_total + 1))
    if [[ -f "/usr/lib/x86_64-linux-gnu/libfaketime.so.1" ]]; then
        echo -e "${GREEN}✓ Test 4: libfaketime available${NC}"
        tests_passed=$((tests_passed + 1))
    else
        echo -e "${YELLOW}⚠ Test 4: libfaketime not found (non-critical)${NC}"
    fi
    
    # Test 5: Check CAP_NET_ADMIN
    tests_total=$((tests_total + 1))
    if getcap "$(which python3)" | grep -q "cap_net_admin"; then
        echo -e "${GREEN}✓ Test 5: CAP_NET_ADMIN capability set${NC}"
        tests_passed=$((tests_passed + 1))
    else
        echo -e "${YELLOW}⚠ Test 5: CAP_NET_ADMIN not verified${NC}"
    fi
    
    # Test 6: Check Python venv
    tests_total=$((tests_total + 1))
    if [[ -f "$LUCID_HOME/venv/bin/python" ]]; then
        echo -e "${GREEN}✓ Test 6: Python venv created${NC}"
        tests_passed=$((tests_passed + 1))
    else
        echo -e "${RED}✗ Test 6: Python venv not found${NC}"
    fi
    
    # Test 7: Check systemd service
    tests_total=$((tests_total + 1))
    if [[ -f "/etc/systemd/system/lucid-empire.service" ]]; then
        echo -e "${GREEN}✓ Test 7: Systemd service installed${NC}"
        tests_passed=$((tests_passed + 1))
    else
        echo -e "${RED}✗ Test 7: Systemd service not found${NC}"
    fi
    
    echo ""
    echo -e "${BLUE}VERIFICATION SUMMARY: $tests_passed/$tests_total tests passed${NC}"
    
    if [[ $tests_passed -eq $tests_total ]]; then
        echo -e "${GREEN}✓ Installation SUCCESSFUL${NC}"
        return 0
    else
        echo -e "${YELLOW}⚠ Installation completed with warnings${NC}"
        return 0
    fi
}

################################################################################
# MAIN EXECUTION
################################################################################

main() {
    echo ""
    echo "╔════════════════════════════════════════════════════════════╗"
    echo "║  LUCID EMPIRE v5 TITAN :: LINUX INSTALLER (SOVEREIGN)     ║"
    echo "║  Authority: Dva.12                                         ║"
    echo "║  Technology: eBPF + Libfaketime + Systemd                 ║"
    echo "╚════════════════════════════════════════════════════════════╝"
    echo ""
    
    # Create log file
    mkdir -p "$LUCID_HOME"
    touch "$INSTALL_LOG"
    
    # Execute phases
    phase_checks
    setup_user_environment
    compile_ebpf
    setup_libfaketime
    setup_capabilities
    setup_systemd_service
    setup_python_venv
    copy_repository_code
    verify_installation
    
    echo ""
    echo "╔════════════════════════════════════════════════════════════╗"
    echo "║  INSTALLATION COMPLETE                                     ║"
    echo "╚════════════════════════════════════════════════════════════╝"
    echo ""
    echo "Next steps:"
    echo "  1. Start the service: systemctl start lucid-empire"
    echo "  2. Enable auto-start: systemctl enable lucid-empire"
    echo "  3. Check status: systemctl status lucid-empire"
    echo "  4. View logs: journalctl -u lucid-empire -f"
    echo ""
    echo "Installation directory: $LUCID_HOME"
    echo "Logs: $INSTALL_LOG"
    echo ""
}

# Run main
main "$@"
