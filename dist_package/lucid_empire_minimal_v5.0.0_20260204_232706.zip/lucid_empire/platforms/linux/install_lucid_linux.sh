#!/bin/bash
#
# LUCID EMPIRE v5.0 TITAN :: LINUX FULL INSTALLER
# Purpose: Complete installation script for Linux/Ubuntu with eBPF, libfaketime, systemd
# Authority: Dva.12
# Platform: Linux (TITAN Class)
#
# This script follows IRON_RULES.md:
# - LR-1: Root/CAP_NET_ADMIN
# - LR-2: libfaketime LD_PRELOAD
# - LR-3: systemd service
# - LR-4: iptables backup
# - LR-5: Network interface binding
#

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# Configuration
LUCID_HOME="/opt/lucid-empire"
LUCID_USER="lucid-agent"
LUCID_UID=1337
SERVICE_NAME="lucid-empire"
API_PORT=8000

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Logging
log_info() { echo -e "${CYAN}[INFO]${NC} $1"; }
log_ok() { echo -e "${GREEN}[OK]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_header() { echo -e "\n${BOLD}${CYAN}=== $1 ===${NC}\n"; }

# Banner
show_banner() {
    echo -e "${CYAN}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║                                                              ║"
    echo "║     LUCID EMPIRE v5.0 TITAN :: LINUX INSTALLER               ║"
    echo "║                                                              ║"
    echo "║     Authority: Dva.12                                        ║"
    echo "║     Platform: Linux / TITAN Class                            ║"
    echo "║     Classification: SOVEREIGN ARCHITECTURE                   ║"
    echo "║                                                              ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

# Check root
check_root() {
    if [ "$EUID" -ne 0 ]; then
        log_error "This installer must be run as root"
        echo ""
        echo "Please run: sudo $0"
        echo ""
        exit 1
    fi
    log_ok "Running as root"
}

# Check kernel version (LR-5 prerequisite)
check_kernel() {
    log_header "CHECKING KERNEL VERSION"
    
    KERNEL_VERSION=$(uname -r)
    log_info "Current kernel: $KERNEL_VERSION"
    
    MAJOR=$(echo "$KERNEL_VERSION" | cut -d. -f1)
    MINOR=$(echo "$KERNEL_VERSION" | cut -d. -f2)
    
    if [ "$MAJOR" -gt 5 ] || ([ "$MAJOR" -eq 5 ] && [ "$MINOR" -ge 8 ]); then
        log_ok "Kernel 5.8+ detected - eBPF compatible"
        return 0
    else
        log_warn "Kernel < 5.8 - eBPF may not work properly"
        log_warn "Consider upgrading kernel for full functionality"
        return 1
    fi
}

# Detect distribution
detect_distro() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        DISTRO=$ID
        DISTRO_VERSION=$VERSION_ID
        log_info "Detected: $DISTRO $DISTRO_VERSION"
    else
        DISTRO="unknown"
        log_warn "Could not detect distribution"
    fi
}

# Install system packages
install_packages() {
    log_header "INSTALLING SYSTEM PACKAGES"
    
    case $DISTRO in
        ubuntu|debian)
            log_info "Using apt package manager"
            apt-get update -qq
            
            PACKAGES=(
                python3 python3-pip python3-venv python3-dev
                faketime libfaketime
                clang llvm llvm-dev libelf-dev zlib1g-dev
                libbpf-dev bpftool
                linux-headers-$(uname -r)
                iptables
                curl wget git
            )
            
            for pkg in "${PACKAGES[@]}"; do
                log_info "Installing $pkg..."
                apt-get install -y -qq "$pkg" 2>/dev/null || log_warn "Could not install $pkg"
            done
            ;;
        fedora|rhel|centos)
            log_info "Using dnf package manager"
            dnf install -y \
                python3 python3-pip python3-devel \
                libfaketime \
                clang llvm llvm-devel elfutils-libelf-devel \
                bpftool \
                kernel-headers \
                iptables \
                curl wget git
            ;;
        arch|manjaro)
            log_info "Using pacman package manager"
            pacman -Sy --noconfirm \
                python python-pip \
                libfaketime \
                clang llvm \
                bpf \
                linux-headers \
                iptables \
                curl wget git
            ;;
        *)
            log_warn "Unknown distribution - please install packages manually"
            log_info "Required: python3, pip, faketime, clang, llvm, bpftool, iptables"
            ;;
    esac
    
    log_ok "System packages installed"
}

# Create lucid-agent user (LR-1)
create_user() {
    log_header "CREATING LUCID-AGENT USER"
    
    if id "$LUCID_USER" &>/dev/null; then
        log_ok "User $LUCID_USER already exists"
    else
        useradd -r -s /usr/sbin/nologin -u $LUCID_UID -d $LUCID_HOME "$LUCID_USER" 2>/dev/null || \
        useradd -r -s /usr/sbin/nologin -d $LUCID_HOME "$LUCID_USER"
        log_ok "Created user $LUCID_USER"
    fi
}

# Create directory structure
create_directories() {
    log_header "CREATING DIRECTORY STRUCTURE"
    
    mkdir -p "$LUCID_HOME"/{bin,lib,config,profiles,logs,cache,ebpf}
    
    # Copy project files
    if [ -d "$PROJECT_ROOT" ]; then
        log_info "Copying project files..."
        cp -r "$PROJECT_ROOT/backend" "$LUCID_HOME/" 2>/dev/null || true
        cp -r "$PROJECT_ROOT/modules" "$LUCID_HOME/" 2>/dev/null || true
        cp -r "$PROJECT_ROOT/camoufox" "$LUCID_HOME/" 2>/dev/null || true
        cp -r "$PROJECT_ROOT/lucid_profile_data" "$LUCID_HOME/profiles/" 2>/dev/null || true
        cp "$PROJECT_ROOT/requirements.txt" "$LUCID_HOME/" 2>/dev/null || true
        cp "$PROJECT_ROOT/main.py" "$LUCID_HOME/" 2>/dev/null || true
    fi
    
    # Set ownership
    chown -R "$LUCID_USER:$LUCID_USER" "$LUCID_HOME"
    chmod -R 755 "$LUCID_HOME"
    
    log_ok "Directory structure created at $LUCID_HOME"
}

# Setup Python virtual environment
setup_python() {
    log_header "SETTING UP PYTHON ENVIRONMENT"
    
    VENV_PATH="$LUCID_HOME/venv"
    
    if [ ! -d "$VENV_PATH" ]; then
        log_info "Creating virtual environment..."
        python3 -m venv "$VENV_PATH"
    fi
    
    log_info "Installing Python dependencies..."
    source "$VENV_PATH/bin/activate"
    
    pip install --upgrade pip -q
    
    if [ -f "$LUCID_HOME/requirements.txt" ]; then
        pip install -r "$LUCID_HOME/requirements.txt" -q
    else
        pip install fastapi uvicorn playwright requests PyQt6 -q
    fi
    
    # Install Playwright browsers
    log_info "Installing Playwright browsers..."
    python -m playwright install firefox 2>/dev/null || log_warn "Playwright install may need manual run"
    
    deactivate
    
    log_ok "Python environment ready"
}

# Grant CAP_NET_ADMIN capability (LR-1)
grant_capabilities() {
    log_header "GRANTING NETWORK CAPABILITIES (LR-1)"
    
    PYTHON_PATH="$LUCID_HOME/venv/bin/python"
    
    if [ -f "$PYTHON_PATH" ]; then
        setcap cap_net_admin+ep "$PYTHON_PATH"
        log_ok "Granted CAP_NET_ADMIN to $PYTHON_PATH"
        
        # Verify
        CAPS=$(getcap "$PYTHON_PATH" 2>/dev/null)
        log_info "Capabilities: $CAPS"
    else
        log_warn "Python not found at $PYTHON_PATH"
    fi
}

# Find libfaketime path (LR-2)
find_libfaketime() {
    LIBFAKETIME_PATHS=(
        "/usr/lib/x86_64-linux-gnu/faketime/libfaketime.so.1"
        "/usr/lib/x86_64-linux-gnu/libfaketime.so.1"
        "/usr/local/lib/faketime/libfaketime.so.1"
        "/usr/lib/faketime/libfaketime.so.1"
        "/usr/lib64/faketime/libfaketime.so.1"
    )
    
    for path in "${LIBFAKETIME_PATHS[@]}"; do
        if [ -f "$path" ]; then
            echo "$path"
            return 0
        fi
    done
    
    echo ""
    return 1
}

# Configure libfaketime (LR-2)
configure_libfaketime() {
    log_header "CONFIGURING LIBFAKETIME (LR-2)"
    
    LIBFAKETIME=$(find_libfaketime)
    
    if [ -n "$LIBFAKETIME" ]; then
        log_ok "libfaketime found: $LIBFAKETIME"
        
        # Create config file
        cat > "$LUCID_HOME/config/faketime.conf" << EOF
# libfaketime configuration for LUCID EMPIRE
# Authority: Dva.12

LIBFAKETIME_PATH=$LIBFAKETIME
FAKETIME_OFFSET=-90d
LIBFAKETIME_NO_CACHE=1
LIBFAKETIME_SKIP_CLOCK_NANOSLEEP=1
EOF
        
        log_ok "libfaketime configuration saved"
    else
        log_warn "libfaketime not found - time displacement will not work"
        log_info "Install with: apt install faketime"
    fi
}

# Install systemd service (LR-3)
install_systemd_service() {
    log_header "INSTALLING SYSTEMD SERVICE (LR-3)"
    
    LIBFAKETIME=$(find_libfaketime)
    PYTHON_PATH="$LUCID_HOME/venv/bin/python"
    
    cat > "/etc/systemd/system/${SERVICE_NAME}.service" << EOF
[Unit]
Description=LUCID EMPIRE - Sovereignty Masking Platform (TITAN Class)
Documentation=https://github.com/lucid-empire
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$LUCID_USER
Group=$LUCID_USER
WorkingDirectory=$LUCID_HOME
EOF

    if [ -n "$LIBFAKETIME" ]; then
        cat >> "/etc/systemd/system/${SERVICE_NAME}.service" << EOF
Environment="LD_PRELOAD=$LIBFAKETIME"
Environment="FAKETIME=-90d"
Environment="FAKETIME_NO_CACHE=1"
EOF
    fi

    cat >> "/etc/systemd/system/${SERVICE_NAME}.service" << EOF
ExecStart=$PYTHON_PATH -m uvicorn backend.lucid_api:app --host 0.0.0.0 --port $API_PORT
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal

# Security hardening
NoNewPrivileges=false
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$LUCID_HOME
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

    # Reload systemd
    systemctl daemon-reload
    
    # Enable service
    systemctl enable "$SERVICE_NAME"
    
    log_ok "systemd service installed: $SERVICE_NAME"
    log_info "Commands:"
    log_info "  sudo systemctl start $SERVICE_NAME"
    log_info "  sudo systemctl status $SERVICE_NAME"
    log_info "  sudo journalctl -u $SERVICE_NAME -f"
}

# Configure iptables backup rules (LR-4)
configure_iptables() {
    log_header "CONFIGURING IPTABLES BACKUP (LR-4)"
    
    # Create backup chain
    iptables -t nat -N LUCID-BACKUP 2>/dev/null || true
    
    # Flush existing rules in chain
    iptables -t nat -F LUCID-BACKUP 2>/dev/null || true
    
    # Add backup redirect rules
    iptables -t nat -A LUCID-BACKUP -p tcp --dport 443 -j REDIRECT --to-port 8443 2>/dev/null || true
    iptables -t nat -A LUCID-BACKUP -p tcp --dport 80 -j REDIRECT --to-port 8080 2>/dev/null || true
    
    # Check if rule already exists in OUTPUT
    if ! iptables -t nat -C OUTPUT -j LUCID-BACKUP 2>/dev/null; then
        iptables -t nat -I OUTPUT 1 -j LUCID-BACKUP 2>/dev/null || true
    fi
    
    # Save rules
    if command -v iptables-save &> /dev/null; then
        mkdir -p /etc/iptables
        iptables-save > /etc/iptables/rules.v4 2>/dev/null || true
        log_ok "iptables rules saved"
    fi
    
    log_ok "iptables backup chain configured"
}

# Detect primary network interface (LR-5)
detect_interface() {
    log_header "DETECTING NETWORK INTERFACE (LR-5)"
    
    # Get default route interface
    INTERFACE=$(ip route show default | awk '/default/ {print $5}' | head -1)
    
    if [ -n "$INTERFACE" ]; then
        log_ok "Primary interface: $INTERFACE"
        
        # Save to config
        cat > "$LUCID_HOME/config/network.conf" << EOF
# Network configuration for LUCID EMPIRE
# Authority: Dva.12

PRIMARY_INTERFACE=$INTERFACE
BACKUP_INTERFACES=
XDP_PROGRAM=$LUCID_HOME/ebpf/xdp_outbound.o
EOF
        
        log_ok "Network configuration saved"
    else
        log_warn "Could not detect primary interface"
        log_info "Please configure manually in $LUCID_HOME/config/network.conf"
    fi
}

# Create main configuration file
create_config() {
    log_header "CREATING CONFIGURATION"
    
    LIBFAKETIME=$(find_libfaketime)
    INTERFACE=$(ip route show default | awk '/default/ {print $5}' | head -1)
    
    cat > "$LUCID_HOME/config/config.json" << EOF
{
  "api": {
    "host": "0.0.0.0",
    "port": $API_PORT
  },
  "masking": {
    "enabled": true,
    "platform": "linux",
    "class": "TITAN",
    "ebpf": {
      "primary_interface": "$INTERFACE",
      "xdp_program": "$LUCID_HOME/ebpf/xdp_outbound.o"
    },
    "libfaketime": {
      "path": "$LIBFAKETIME",
      "offset_days": -90,
      "cache_disabled": true
    },
    "logging": {
      "level": "INFO",
      "file": "$LUCID_HOME/logs/main.log"
    }
  },
  "profiles": {
    "data_dir": "$LUCID_HOME/profiles"
  }
}
EOF

    chown "$LUCID_USER:$LUCID_USER" "$LUCID_HOME/config/config.json"
    
    log_ok "Configuration created at $LUCID_HOME/config/config.json"
}

# Create launcher scripts
create_launchers() {
    log_header "CREATING LAUNCHER SCRIPTS"
    
    LIBFAKETIME=$(find_libfaketime)
    
    # CLI launcher
    cat > "$LUCID_HOME/bin/lucid-empire" << EOF
#!/bin/bash
# LUCID EMPIRE CLI Launcher
cd $LUCID_HOME
source venv/bin/activate
EOF

    if [ -n "$LIBFAKETIME" ]; then
        cat >> "$LUCID_HOME/bin/lucid-empire" << EOF
export LD_PRELOAD=$LIBFAKETIME
export FAKETIME=-90d
export FAKETIME_NO_CACHE=1
EOF
    fi

    cat >> "$LUCID_HOME/bin/lucid-empire" << EOF
python -m uvicorn backend.lucid_api:app --host 0.0.0.0 --port $API_PORT "\$@"
EOF

    chmod +x "$LUCID_HOME/bin/lucid-empire"
    
    # Create symlink in /usr/local/bin
    ln -sf "$LUCID_HOME/bin/lucid-empire" /usr/local/bin/lucid-empire 2>/dev/null || true
    
    # GUI launcher
    cat > "$LUCID_HOME/bin/lucid-gui" << EOF
#!/bin/bash
# LUCID EMPIRE GUI Launcher
cd $LUCID_HOME
source venv/bin/activate
EOF

    if [ -n "$LIBFAKETIME" ]; then
        cat >> "$LUCID_HOME/bin/lucid-gui" << EOF
export LD_PRELOAD=$LIBFAKETIME
export FAKETIME=-90d
EOF
    fi

    cat >> "$LUCID_HOME/bin/lucid-gui" << EOF
python platforms/linux/lucid_control_panel_linux.py "\$@"
EOF

    chmod +x "$LUCID_HOME/bin/lucid-gui"
    ln -sf "$LUCID_HOME/bin/lucid-gui" /usr/local/bin/lucid-gui 2>/dev/null || true
    
    log_ok "Launcher scripts created"
    log_info "Commands available: lucid-empire, lucid-gui"
}

# Verification
verify_installation() {
    log_header "VERIFYING INSTALLATION"
    
    ERRORS=0
    
    # Check directories
    if [ -d "$LUCID_HOME" ]; then
        log_ok "Installation directory: $LUCID_HOME"
    else
        log_error "Installation directory missing"
        ((ERRORS++))
    fi
    
    # Check Python
    if [ -f "$LUCID_HOME/venv/bin/python" ]; then
        log_ok "Python virtual environment"
    else
        log_error "Python venv missing"
        ((ERRORS++))
    fi
    
    # Check capabilities
    CAPS=$(getcap "$LUCID_HOME/venv/bin/python" 2>/dev/null)
    if [[ "$CAPS" == *"cap_net_admin"* ]]; then
        log_ok "CAP_NET_ADMIN capability (LR-1)"
    else
        log_warn "CAP_NET_ADMIN not set (LR-1)"
    fi
    
    # Check libfaketime
    LIBFAKETIME=$(find_libfaketime)
    if [ -n "$LIBFAKETIME" ]; then
        log_ok "libfaketime available (LR-2)"
    else
        log_warn "libfaketime not found (LR-2)"
    fi
    
    # Check systemd service
    if systemctl is-enabled "$SERVICE_NAME" &>/dev/null; then
        log_ok "systemd service enabled (LR-3)"
    else
        log_warn "systemd service not enabled (LR-3)"
    fi
    
    # Check iptables
    if iptables -t nat -L LUCID-BACKUP &>/dev/null; then
        log_ok "iptables backup chain (LR-4)"
    else
        log_warn "iptables backup chain missing (LR-4)"
    fi
    
    # Check config
    if [ -f "$LUCID_HOME/config/config.json" ]; then
        log_ok "Configuration file"
    else
        log_warn "Configuration file missing"
    fi
    
    echo ""
    if [ $ERRORS -eq 0 ]; then
        log_ok "Installation verification passed"
    else
        log_error "Installation has $ERRORS errors"
    fi
}

# Show completion message
show_completion() {
    echo ""
    echo -e "${GREEN}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║                                                              ║"
    echo "║     LUCID EMPIRE INSTALLATION COMPLETE                       ║"
    echo "║                                                              ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo ""
    echo -e "${CYAN}Installation Directory:${NC} $LUCID_HOME"
    echo ""
    echo -e "${CYAN}Commands:${NC}"
    echo "  Start service:    sudo systemctl start $SERVICE_NAME"
    echo "  Stop service:     sudo systemctl stop $SERVICE_NAME"
    echo "  View logs:        sudo journalctl -u $SERVICE_NAME -f"
    echo "  Launch GUI:       lucid-gui"
    echo "  Launch CLI:       lucid-empire"
    echo ""
    echo -e "${CYAN}API Endpoint:${NC} http://localhost:$API_PORT"
    echo -e "${CYAN}API Docs:${NC} http://localhost:$API_PORT/docs"
    echo ""
    echo -e "${YELLOW}Note: Run 'sudo systemctl start $SERVICE_NAME' to start the backend${NC}"
    echo ""
}

# Main installation flow
main() {
    show_banner
    check_root
    detect_distro
    check_kernel
    
    log_header "STARTING INSTALLATION"
    
    install_packages
    create_user
    create_directories
    setup_python
    grant_capabilities
    configure_libfaketime
    install_systemd_service
    configure_iptables
    detect_interface
    create_config
    create_launchers
    
    verify_installation
    show_completion
}

# Run main
main "$@"
