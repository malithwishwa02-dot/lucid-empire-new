#!/bin/bash
#
# LUCID EMPIRE v5.0 TITAN :: LINUX LAUNCHER
# Purpose: One-click launcher for Linux/Ubuntu control panel
# Authority: Dva.12
# Platform: Linux (TITAN Class)
#

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${CYAN}"
echo "========================================================"
echo "       LUCID EMPIRE v5.0 TITAN :: LINUX LAUNCHER"
echo "========================================================"
echo ""
echo "   Anti-Detect Browser System"
echo "   Authority: Dva.12"
echo "   Platform: Linux / TITAN Class"
echo ""
echo "========================================================"
echo -e "${NC}"

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Check if running as root
if [ "$EUID" -eq 0 ]; then
    echo -e "${GREEN}[OK] Running as root${NC}"
else
    echo -e "${YELLOW}[INFO] Not running as root - some features may be limited${NC}"
    echo -e "${YELLOW}[INFO] For full functionality, run: sudo $0${NC}"
fi

# Check Python
echo ""
echo -e "${CYAN}[*] Checking Python...${NC}"
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version 2>&1)
    echo -e "${GREEN}[OK] $PYTHON_VERSION${NC}"
else
    echo -e "${RED}[ERROR] Python 3 is not installed!${NC}"
    echo ""
    echo "Please install Python 3.10+:"
    echo "  Ubuntu/Debian: sudo apt install python3 python3-pip python3-venv"
    echo "  Fedora: sudo dnf install python3 python3-pip"
    echo "  Arch: sudo pacman -S python python-pip"
    echo ""
    exit 1
fi

# Check PyQt6
echo ""
echo -e "${CYAN}[*] Checking PyQt6...${NC}"
if python3 -c "import PyQt6" 2>/dev/null; then
    echo -e "${GREEN}[OK] PyQt6 installed${NC}"
else
    echo -e "${YELLOW}[*] Installing PyQt6...${NC}"
    pip3 install --user PyQt6 requests 2>/dev/null || pip3 install PyQt6 requests
fi

# Check for virtual environment
VENV_PATH="$PROJECT_ROOT/venv"
if [ -d "$VENV_PATH" ]; then
    echo -e "${GREEN}[OK] Virtual environment found${NC}"
    source "$VENV_PATH/bin/activate" 2>/dev/null || true
fi

# Check libfaketime
echo ""
echo -e "${CYAN}[*] Checking libfaketime...${NC}"
LIBFAKETIME_PATHS=(
    "/usr/lib/x86_64-linux-gnu/faketime/libfaketime.so.1"
    "/usr/lib/x86_64-linux-gnu/libfaketime.so.1"
    "/usr/local/lib/faketime/libfaketime.so.1"
    "/usr/lib/faketime/libfaketime.so.1"
)

LIBFAKETIME=""
for path in "${LIBFAKETIME_PATHS[@]}"; do
    if [ -f "$path" ]; then
        LIBFAKETIME="$path"
        break
    fi
done

if [ -n "$LIBFAKETIME" ]; then
    echo -e "${GREEN}[OK] libfaketime found: $LIBFAKETIME${NC}"
else
    echo -e "${YELLOW}[WARN] libfaketime not found${NC}"
    echo -e "${YELLOW}[INFO] Install with: sudo apt install faketime${NC}"
fi

# Launch the Control Panel
echo ""
echo -e "${CYAN}[*] Launching Lucid Empire Control Panel...${NC}"
echo ""

cd "$SCRIPT_DIR"

# Set display if not set (for SSH sessions)
if [ -z "$DISPLAY" ]; then
    export DISPLAY=:0
fi

# Launch with or without libfaketime
if [ -n "$LIBFAKETIME" ]; then
    echo -e "${GREEN}[*] Launching with libfaketime enabled${NC}"
    LD_PRELOAD="$LIBFAKETIME" FAKETIME="-90d" python3 lucid_control_panel_linux.py
else
    python3 lucid_control_panel_linux.py
fi

EXIT_CODE=$?

if [ $EXIT_CODE -ne 0 ]; then
    echo ""
    echo -e "${RED}[ERROR] Control Panel exited with an error.${NC}"
    echo ""
    echo "Troubleshooting:"
    echo "  1. Install PyQt6: pip3 install PyQt6 requests"
    echo "  2. Install libfaketime: sudo apt install faketime"
    echo "  3. Ensure Python 3.10+ is installed"
    echo "  4. For GUI, ensure X11/Wayland is running"
    echo ""
fi
