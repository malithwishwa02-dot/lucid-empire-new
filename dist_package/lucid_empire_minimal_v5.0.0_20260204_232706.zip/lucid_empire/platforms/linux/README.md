# 🐧 LUCID EMPIRE - LINUX PLATFORM

**Platform Class:** TITAN (Sovereign Kernel Masking)  
**Authority:** Dva.12

---

## Quick Start

```bash
# Make launcher executable
chmod +x LAUNCH_INSTALLER.sh

# Run launcher
./LAUNCH_INSTALLER.sh

# Or with sudo for full features
sudo ./LAUNCH_INSTALLER.sh
```

---

## Features

| Feature | Technology | Status |
|---------|------------|--------|
| **Time Displacement** | libfaketime (LD_PRELOAD) | ✅ |
| **Network Masking** | eBPF/XDP | ✅ |
| **Auto-Start** | systemd service | ✅ |
| **Fail-Safe** | iptables backup | ✅ |
| **GUI** | PyQt6 Control Panel | ✅ |

---

## Iron Rules (LR-1 to LR-5)

| Rule | Requirement | How to Comply |
|------|-------------|---------------|
| **LR-1** | Root or CAP_NET_ADMIN | Run as root or `setcap cap_net_admin+ep /usr/bin/python3` |
| **LR-2** | libfaketime LD_PRELOAD | Install: `sudo apt install faketime` |
| **LR-3** | systemd service | Run full installer: `sudo ./install_lucid_linux.sh` |
| **LR-4** | iptables backup | Configured by installer |
| **LR-5** | Network interface | Auto-detected |

---

## Files

| File | Purpose |
|------|---------|
| `LAUNCH_INSTALLER.sh` | Quick launcher for GUI |
| `install_lucid_linux.sh` | Full system installer |
| `lucid_control_panel_linux.py` | PyQt6 GUI application |

---

## Installation

### Quick Install (GUI Only)
```bash
./LAUNCH_INSTALLER.sh
```

### Full Install (systemd, eBPF, etc.)
```bash
sudo ./install_lucid_linux.sh
```

---

## Requirements

- Linux kernel 5.8+
- Python 3.10+
- libfaketime (`sudo apt install faketime`)
- PyQt6 (`pip install PyQt6`)

---

**Authority:** Dva.12  
**Classification:** TITAN CLASS
