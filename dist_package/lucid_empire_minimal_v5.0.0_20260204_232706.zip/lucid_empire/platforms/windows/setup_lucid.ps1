# LUCID EMPIRE v5 TITAN :: WINDOWS INSTALLER (STEALTH CLASS)
# Authority: Dva.12
# Platform: Windows 10/11
# Technology: DLL Injection + WinAPI Hooks + PowerShell

#Requires -RunAsAdministrator
#Requires -Version 5.0

param(
    [ValidateSet("Install", "Uninstall")]
    [string]$Action = "Install",
    
    [string]$InstallPath = "C:\Program Files\LucidEmpire",
    
    [switch]$SkipDependencies,
    
    [switch]$NoDefenderExclusion
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

################################################################################
# COLORS & LOGGING
################################################################################

$Colors = @{
    Green  = [System.ConsoleColor]::Green
    Red    = [System.ConsoleColor]::Red
    Yellow = [System.ConsoleColor]::Yellow
    Blue   = [System.ConsoleColor]::Blue
    White  = [System.ConsoleColor]::White
}

function Write-Status {
    param([string]$Message, [string]$Status = "INFO")
    
    $color = switch ($Status) {
        "SUCCESS" { $Colors.Green }
        "ERROR"   { $Colors.Red }
        "WARNING" { $Colors.Yellow }
        "INFO"    { $Colors.Blue }
        default   { $Colors.White }
    }
    
    $timestamp = Get-Date -Format "HH:mm:ss"
    $symbol = switch ($Status) {
        "SUCCESS" { "✓" }
        "ERROR"   { "✗" }
        "WARNING" { "⚠" }
        "INFO"    { "→" }
        default   { "•" }
    }
    
    Write-Host -ForegroundColor $color "[$timestamp] [$Status] $symbol $Message"
}

function Test-AdminPrivileges {
    $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object System.Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
}

################################################################################
# PHASE 1: PRE-FLIGHT CHECKS
################################################################################

function Phase-PreflightChecks {
    Write-Status "PHASE 1: PRE-FLIGHT CHECKS" "INFO"
    
    # Check OS
    if ([System.Environment]::OSVersion.Platform -ne "Win32NT") {
        Write-Status "This installer is for Windows only" "ERROR"
        exit 1
    }
    
    $osVersion = [System.Environment]::OSVersion.Version
    if ($osVersion.Major -lt 10) {
        Write-Status "Windows 10 or later required" "ERROR"
        exit 1
    }
    
    Write-Status "Windows $($osVersion.Major).$($osVersion.Minor) detected" "SUCCESS"
    
    # Check admin privileges
    if (-not (Test-AdminPrivileges)) {
        Write-Status "Administrator privileges required" "ERROR"
        Write-Status "Please run PowerShell as Administrator" "INFO"
        exit 1
    }
    
    Write-Status "Running as Administrator" "SUCCESS"
    
    # Check .NET Framework
    $dotnetCheck = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" -EA SilentlyContinue
    if ($null -eq $dotnetCheck) {
        Write-Status ".NET Framework 4.7+ not found" "WARNING"
    } else {
        Write-Status ".NET Framework 4.7+ detected" "SUCCESS"
    }
    
    Write-Status "Pre-flight checks completed" "SUCCESS"
    Write-Host ""
}

################################################################################
# PHASE 2: INSTALL DEPENDENCIES
################################################################################

function Phase-Dependencies {
    if ($SkipDependencies) {
        Write-Status "Skipping dependency installation (as requested)" "INFO"
        return
    }
    
    Write-Status "PHASE 2: INSTALLING DEPENDENCIES" "INFO"
    
    # Check if Python is installed
    $pythonCheck = Get-Command python.exe -EA SilentlyContinue
    
    if ($null -eq $pythonCheck) {
        Write-Status "Python not found in PATH" "WARNING"
        Write-Status "Downloading embedded Python 3.11..." "INFO"
        
        $pythonUrl = "https://www.python.org/ftp/python/3.11.8/python-3.11.8-embed-amd64.zip"
        $pythonZip = "$env:TEMP\python-3.11-embed.zip"
        
        try {
            Write-Status "Downloading Python (150MB)..." "INFO"
            [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
            Invoke-WebRequest -Uri $pythonUrl -OutFile $pythonZip -UseBasicParsing
            Write-Status "Python downloaded" "SUCCESS"
        } catch {
            Write-Status "Failed to download Python: $_" "ERROR"
            Write-Status "Please manually install Python 3.11 from https://www.python.org" "INFO"
            return
        }
        
        # Extract Python
        Write-Status "Extracting Python..." "INFO"
        $pythonExtractPath = "$InstallPath\python"
        New-Item -Path $pythonExtractPath -ItemType Directory -Force | Out-Null
        Expand-Archive -Path $pythonZip -DestinationPath $pythonExtractPath -Force
        
        # Setup pip
        Write-Status "Configuring pip..." "INFO"
        $pthFile = Get-ChildItem "$pythonExtractPath\*.pth" | Select-Object -First 1
        if ($null -ne $pthFile) {
            Add-Content -Path $pthFile.FullName -Value "import site; site.addsitedir('$pythonExtractPath\Lib\site-packages')"
        }
        
        # Download get-pip.py
        $getPipUrl = "https://bootstrap.pypa.io/get-pip.py"
        $getPipPath = "$env:TEMP\get-pip.py"
        
        try {
            Write-Status "Installing pip..." "INFO"
            Invoke-WebRequest -Uri $getPipUrl -OutFile $getPipPath -UseBasicParsing
            & "$pythonExtractPath\python.exe" $getPipPath | Out-Null
            Write-Status "pip installed" "SUCCESS"
        } catch {
            Write-Status "pip installation warning: $_" "WARNING"
        }
        
        # Add to PATH
        $env:Path = "$pythonExtractPath;$env:Path"
        [Environment]::SetEnvironmentVariable("Path", "$pythonExtractPath;$([Environment]::GetEnvironmentVariable('Path', 'Machine'))", "Machine")
        
    } else {
        Write-Status "Python already installed" "SUCCESS"
    }
    
    # Check for git
    $gitCheck = Get-Command git.exe -EA SilentlyContinue
    if ($null -eq $gitCheck) {
        Write-Status "Git not found" "WARNING"
        Write-Status "Some features may require git" "INFO"
    } else {
        Write-Status "Git detected" "SUCCESS"
    }
    
    Write-Status "Dependency installation completed" "SUCCESS"
    Write-Host ""
}

################################################################################
# PHASE 3: CREATE INSTALLATION DIRECTORIES
################################################################################

function Phase-CreateDirectories {
    Write-Status "PHASE 3: CREATING INSTALLATION DIRECTORIES" "INFO"
    
    # Create main directories
    $directories = @(
        $InstallPath,
        "$InstallPath\bin",
        "$InstallPath\lib",
        "$InstallPath\config",
        "$InstallPath\profiles",
        "$InstallPath\logs",
        "$InstallPath\cache"
    )
    
    foreach ($dir in $directories) {
        if (-not (Test-Path $dir)) {
            New-Item -Path $dir -ItemType Directory -Force | Out-Null
            Write-Status "Created: $dir" "SUCCESS"
        } else {
            Write-Status "Already exists: $dir" "INFO"
        }
    }
    
    Write-Host ""
}

################################################################################
# PHASE 4: COPY REPOSITORY CODE
################################################################################

function Phase-CopyCode {
    Write-Status "PHASE 4: COPYING REPOSITORY CODE" "INFO"
    
    $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
    $repoRoot = Resolve-Path "$scriptDir\..\.."
    
    Write-Status "Repository root: $repoRoot" "INFO"
    
    # Copy backend
    if (Test-Path "$repoRoot\backend") {
        Write-Status "Copying backend code..." "INFO"
        Copy-Item -Path "$repoRoot\backend" -Destination "$InstallPath\" -Recurse -Force
        Write-Status "Backend copied" "SUCCESS"
    }
    
    # Copy profiles
    if (Test-Path "$repoRoot\lucid_profile_data") {
        Write-Status "Copying aged profiles..." "INFO"
        Copy-Item -Path "$repoRoot\lucid_profile_data" -Destination "$InstallPath\profiles" -Recurse -Force
        Write-Status "Profiles copied" "SUCCESS"
    }
    
    # Copy dashboard
    if (Test-Path "$repoRoot\dashboard") {
        Write-Status "Copying frontend dashboard..." "INFO"
        Copy-Item -Path "$repoRoot\dashboard" -Destination "$InstallPath\" -Recurse -Force
        Write-Status "Dashboard copied" "SUCCESS"
    }
    
    # Copy requirements.txt
    if (Test-Path "$repoRoot\requirements.txt") {
        Copy-Item -Path "$repoRoot\requirements.txt" -Destination "$InstallPath\"
    }
    
    Write-Status "Repository code copied" "SUCCESS"
    Write-Host ""
}

################################################################################
# PHASE 5: INSTALL PYTHON DEPENDENCIES
################################################################################

function Phase-PythonDependencies {
    Write-Status "PHASE 5: INSTALLING PYTHON DEPENDENCIES" "INFO"
    
    if (Test-Path "$InstallPath\requirements.txt") {
        Write-Status "Installing from requirements.txt..." "INFO"
        
        try {
            & python.exe -m pip install -r "$InstallPath\requirements.txt" --quiet
            Write-Status "Python dependencies installed" "SUCCESS"
        } catch {
            Write-Status "Failed to install dependencies: $_" "ERROR"
            Write-Status "You may need to install manually" "WARNING"
        }
    } else {
        Write-Status "Installing core dependencies..." "INFO"
        
        $packages = @(
            "fastapi",
            "uvicorn",
            "pydantic",
            "aiofiles",
            "requests",
            "python-dotenv"
        )
        
        foreach ($package in $packages) {
            Write-Status "Installing $package..." "INFO"
            & python.exe -m pip install $package --quiet
        }
        
        Write-Status "Core dependencies installed" "SUCCESS"
    }
    
    Write-Host ""
}

################################################################################
# PHASE 6: WINDOWS DEFENDER EXCLUSION
################################################################################

function Phase-DefenderExclusion {
    if ($NoDefenderExclusion) {
        Write-Status "Skipping Windows Defender exclusion (as requested)" "INFO"
        return
    }
    
    Write-Status "PHASE 6: CONFIGURING WINDOWS DEFENDER" "INFO"
    
    try {
        Write-Status "Adding Lucid Empire to Windows Defender exclusions..." "INFO"
        
        # Check if Windows Defender is running
        $defenderStatus = Get-MpPreference -EA SilentlyContinue
        
        if ($null -ne $defenderStatus) {
            # Add path exclusion
            Add-MpPreference -ExclusionPath "$InstallPath" -Force -EA SilentlyContinue
            Write-Status "Added path exclusion: $InstallPath" "SUCCESS"
            
            # Add process exclusion
            $pythonExePath = "C:\Program Files\LucidEmpire\python\python.exe"
            if (Test-Path $pythonExePath) {
                Add-MpPreference -ExclusionProcess $pythonExePath -Force -EA SilentlyContinue
                Write-Status "Added process exclusion: python.exe" "SUCCESS"
            }
            
            Write-Status "Windows Defender configured" "SUCCESS"
        } else {
            Write-Status "Windows Defender not detected (skipping)" "INFO"
        }
        
    } catch {
        Write-Status "Could not configure Windows Defender: $_" "WARNING"
        Write-Status "You may need to manually add exclusions" "INFO"
    }
    
    Write-Host ""
}

################################################################################
# PHASE 7: CREATE LAUNCHER SCRIPTS
################################################################################

function Phase-LauncherScripts {
    Write-Status "PHASE 7: CREATING LAUNCHER SCRIPTS" "INFO"
    
    # Create batch launcher
    $launcherBat = @'
@echo off
REM LUCID EMPIRE v5 TITAN :: Windows Launcher
REM Authority: Dva.12

setlocal enabledelayedexpansion

set LUCID_HOME=%~dp0..
set PYTHONHOME=%LUCID_HOME%\python
set PATH=%PYTHONHOME%;%PATH%

cd /d "%LUCID_HOME%"

echo.
echo ╔════════════════════════════════════════════════════════╗
echo ║  LUCID EMPIRE v5 TITAN :: LAUNCHER (STEALTH)          ║
echo ║  Authority: Dva.12                                     ║
echo ╚════════════════════════════════════════════════════════╝
echo.

echo [*] Starting API server...
python -m backend.lucid_api

pause
'@
    
    Set-Content -Path "$InstallPath\bin\launcher.bat" -Value $launcherBat
    Write-Status "Created launcher batch script" "SUCCESS"
    
    # Create PowerShell launcher
    $launcherPs1 = @'
# LUCID EMPIRE v5 TITAN :: PowerShell Launcher

$LucidHome = Split-Path -Parent $MyInvocation.MyCommand.Path | Split-Path -Parent
$PythonHome = "$LucidHome\python"

$env:Path = "$PythonHome;$env:Path"
$env:PYTHONHOME = $PythonHome

Write-Host ""
Write-Host "╔════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║  LUCID EMPIRE v5 TITAN :: LAUNCHER (STEALTH)          ║" -ForegroundColor Cyan
Write-Host "║  Authority: Dva.12                                     ║" -ForegroundColor Cyan
Write-Host "╚════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

Write-Host "[*] Starting API server..." -ForegroundColor Yellow
Write-Host "[*] Navigate to: http://localhost:8000" -ForegroundColor Green
Write-Host ""

Set-Location $LucidHome
python -m backend.lucid_api
'@
    
    Set-Content -Path "$InstallPath\bin\launcher.ps1" -Value $launcherPs1
    Write-Status "Created launcher PowerShell script" "SUCCESS"
    
    Write-Host ""
}

################################################################################
# PHASE 8: CREATE DESKTOP SHORTCUT
################################################################################

function Phase-DesktopShortcut {
    Write-Status "PHASE 8: CREATING DESKTOP SHORTCUT" "INFO"
    
    try {
        $desktopPath = [System.IO.Path]::Combine(
            [Environment]::GetFolderPath("Desktop"),
            "LUCID EMPIRE.lnk"
        )
        
        $shell = New-Object -ComObject "WScript.Shell"
        $shortcut = $shell.CreateShortcut($desktopPath)
        $shortcut.TargetPath = "powershell.exe"
        $shortcut.Arguments = "-NoExit -ExecutionPolicy Bypass -File `"$InstallPath\bin\launcher.ps1`""
        $shortcut.WorkingDirectory = $InstallPath
        $shortcut.IconLocation = "C:\Windows\System32\powershell.exe,0"
        $shortcut.Save()
        
        Write-Status "Desktop shortcut created" "SUCCESS"
    } catch {
        Write-Status "Could not create desktop shortcut: $_" "WARNING"
    }
    
    Write-Host ""
}

################################################################################
# PHASE 9: CONFIGURE FIREWALL
################################################################################

function Phase-Firewall {
    Write-Status "PHASE 9: CONFIGURING WINDOWS FIREWALL" "INFO"
    
    try {
        # Allow inbound on port 8000
        New-NetFirewallRule -DisplayName "LUCID EMPIRE - API Server" `
            -Direction Inbound `
            -LocalPort 8000 `
            -Protocol TCP `
            -Action Allow `
            -ErrorAction SilentlyContinue | Out-Null
        
        Write-Status "Firewall rule added for API (port 8000)" "SUCCESS"
    } catch {
        Write-Status "Could not configure firewall: $_" "WARNING"
        Write-Status "You may need to manually allow port 8000" "INFO"
    }
    
    Write-Host ""
}

################################################################################
# PHASE 10: VERIFICATION
################################################################################

function Phase-Verification {
    Write-Status "PHASE 10: VERIFICATION & TESTS" "INFO"
    
    $testsPassed = 0
    $testsTotal = 0
    
    # Test 1: Installation path exists
    $testsTotal++
    if (Test-Path $InstallPath) {
        Write-Status "Installation directory: $InstallPath" "SUCCESS"
        $testsPassed++
    } else {
        Write-Status "Installation directory not found" "ERROR"
    }
    
    # Test 2: Python installed
    $testsTotal++
    $pythonCheck = & python.exe --version 2>&1
    if ($?) {
        Write-Status "Python: $pythonCheck" "SUCCESS"
        $testsPassed++
    } else {
        Write-Status "Python not found in PATH" "ERROR"
    }
    
    # Test 3: Core modules copied
    $testsTotal++
    if (Test-Path "$InstallPath\backend") {
        Write-Status "Backend code: Present" "SUCCESS"
        $testsPassed++
    } else {
        Write-Status "Backend code: Missing" "ERROR"
    }
    
    # Test 4: Launcher scripts created
    $testsTotal++
    if (Test-Path "$InstallPath\bin\launcher.bat" -and (Test-Path "$InstallPath\bin\launcher.ps1")) {
        Write-Status "Launcher scripts: Created" "SUCCESS"
        $testsPassed++
    } else {
        Write-Status "Launcher scripts: Not found" "ERROR"
    }
    
    # Test 5: Requirements available
    $testsTotal++
    if (Test-Path "$InstallPath\requirements.txt") {
        Write-Status "Requirements file: Present" "SUCCESS"
        $testsPassed++
    } else {
        Write-Status "Requirements file: Not found" "INFO"
    }
    
    Write-Host ""
    Write-Status "Verification: $testsPassed/$testsTotal tests passed" "INFO"
    
    Write-Host ""
}

################################################################################
# MAIN EXECUTION
################################################################################

function Invoke-Installation {
    Write-Host ""
    Write-Host "╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║  LUCID EMPIRE v5 TITAN :: WINDOWS INSTALLER (STEALTH)    ║" -ForegroundColor Cyan
    Write-Host "║  Authority: Dva.12                                         ║" -ForegroundColor Cyan
    Write-Host "║  Technology: DLL Injection + WinAPI + PowerShell          ║" -ForegroundColor Cyan
    Write-Host "╚════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    
    Write-Status "Installation Path: $InstallPath" "INFO"
    Write-Host ""
    
    Phase-PreflightChecks
    Phase-Dependencies
    Phase-CreateDirectories
    Phase-CopyCode
    Phase-PythonDependencies
    Phase-DefenderExclusion
    Phase-LauncherScripts
    Phase-DesktopShortcut
    Phase-Firewall
    Phase-Verification
    
    Write-Host "╔════════════════════════════════════════════════════════════╗" -ForegroundColor Green
    Write-Host "║  INSTALLATION COMPLETE                                     ║" -ForegroundColor Green
    Write-Host "╚════════════════════════════════════════════════════════════╝" -ForegroundColor Green
    Write-Host ""
    
    Write-Host "Next steps:" -ForegroundColor Yellow
    Write-Host "  1. Click 'LUCID EMPIRE' shortcut on your desktop"
    Write-Host "  2. Or run: $InstallPath\bin\launcher.ps1"
    Write-Host "  3. Navigate to: http://localhost:8000"
    Write-Host ""
    
    Write-Host "Installation Summary:" -ForegroundColor Cyan
    Write-Host "  Path: $InstallPath"
    Write-Host "  Python: $(python.exe --version 2>&1)"
    Write-Host "  Windows: $([System.Environment]::OSVersion.VersionString)"
    Write-Host ""
}

# Main execution
if ($Action -eq "Install") {
    Invoke-Installation
} elseif ($Action -eq "Uninstall") {
    Write-Status "Uninstall functionality not yet implemented" "WARNING"
}
