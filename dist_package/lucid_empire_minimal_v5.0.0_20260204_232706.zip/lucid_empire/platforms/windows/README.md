# 🪟 LUCID EMPIRE - WINDOWS PLATFORM

**Platform Class:** STEALTH (Usermode DLL Injection)  
**Authority:** Dva.12

---

## Quick Start

```
1. Double-click LAUNCH_INSTALLER.bat
2. (Optional) Right-click → "Run as Administrator" for full features
3. Generate or select an aged profile
4. Click [ ENTER OBLIVION ]
```

---

## Features

| Feature | Technology | Status |
|---------|------------|--------|
| **Time Displacement** | DLL Injection / RunAsDate | ✅ |
| **TTL Spoofing** | WinDivert / Custom DLL | ✅ |
| **Defender Bypass** | Exclusion Path | ✅ |
| **Firewall Config** | NetFirewallRule | ✅ |
| **GUI** | PyQt6 Control Panel | ✅ |

---

## Iron Rules (WR-1 to WR-5)

| Rule | Requirement | How to Comply |
|------|-------------|---------------|
| **WR-1** | Administrator Token | Right-click → "Run as Administrator" |
| **WR-2** | Defender Exclusion | Click "Configure Defender" in GUI |
| **WR-3** | Firewall Rule | Click "Configure Firewall" in GUI |
| **WR-4** | Target Process | Browser must be running for DLL injection |
| **WR-5** | Time Spoofing | Automatic via DLL injection |

---

## Files

| File | Purpose |
|------|---------|
| `LAUNCH_INSTALLER.bat` | One-click launcher |
| `lucid_control_panel_windows.py` | PyQt6 GUI application |

---

## Installation

### Quick Install
```
Double-click LAUNCH_INSTALLER.bat
```

### Manual Install
```powershell
pip install PyQt6 requests
python lucid_control_panel_windows.py
```

---

## Requirements

- Windows 10/11
- Python 3.10+
- PyQt6 (`pip install PyQt6`)
- Administrator privileges (for Defender/Firewall config)

---

**Authority:** Dva.12  
**Classification:** STEALTH CLASS
