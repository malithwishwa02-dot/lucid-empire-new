#!/usr/bin/env python3
"""
LUCID EMPIRE v5.0.0-TITAN :: UNIFIED PLATFORM LAUNCHER
========================================================
Authority: Dva.12 | PROMETHEUS-CORE v2.1
Classification: OBLIVION ACTIVE

This module connects all anti-detect browser implementations:
- Camoufox integration (local + PyPI)
- Profile management (Genesis Engine)
- Network masking (WinDivert/eBPF)
- Playwright fallback
"""

import sys
import os
import platform
import logging
from pathlib import Path
from typing import Optional, Dict, Any

# Ensure project root is in path
PROJECT_ROOT = Path(__file__).parent.parent.absolute()
sys.path.insert(0, str(PROJECT_ROOT))

# Add local Camoufox module to path
CAMOUFOX_LOCAL = PROJECT_ROOT / "camoufox" / "pythonlib"
if CAMOUFOX_LOCAL.exists():
    sys.path.insert(0, str(CAMOUFOX_LOCAL))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger("LUCID.Platform")

# Constants
PROFILE_DIR = PROJECT_ROOT / "lucid_profile_data"
PROFILE_DIR.mkdir(exist_ok=True)


class PlatformLauncher:
    """
    Unified launcher for Lucid Anti-Detect Browser
    
    Automatically detects platform and uses appropriate masking:
    - Windows: STEALTH Class (WinDivert, DLL injection)
    - Linux: TITAN Class (eBPF/XDP, libfaketime)
    """
    
    def __init__(self):
        self.platform = self._detect_platform()
        self.camoufox_available = False
        self.playwright_available = False
        self._check_dependencies()
    
    def _detect_platform(self) -> str:
        """Detect operating system"""
        system = platform.system()
        if system == "Linux":
            return "TITAN"
        elif system == "Windows":
            return "STEALTH"
        elif system == "Darwin":
            return "STEALTH"
        return "UNKNOWN"
    
    def _check_dependencies(self):
        """Check available dependencies"""
        # Check Camoufox
        try:
            from camoufox.sync_api import Camoufox
            self.camoufox_available = True
            logger.info("✓ Camoufox: Available")
        except ImportError:
            logger.warning("✗ Camoufox: Not installed")
        
        # Check Playwright
        try:
            from playwright.sync_api import sync_playwright
            self.playwright_available = True
            logger.info("✓ Playwright: Available")
        except ImportError:
            logger.warning("✗ Playwright: Not installed")
        
        # Check browser binary
        try:
            from camoufox.pkgman import camoufox_path
            path = camoufox_path(download_if_missing=False)
            logger.info(f"✓ Camoufox binary: {path}")
        except:
            logger.warning("✗ Camoufox binary: Not downloaded (run: python -m camoufox fetch)")
    
    def list_profiles(self) -> list:
        """List available profiles"""
        profiles = []
        if PROFILE_DIR.exists():
            for p in PROFILE_DIR.iterdir():
                if p.is_dir() and not p.name.startswith('.'):
                    profiles.append(p.name)
        return sorted(profiles)
    
    def launch(
        self,
        profile_name: Optional[str] = None,
        headless: bool = False,
        proxy: Optional[str] = None,
        url: str = "https://www.google.com"
    ) -> bool:
        """
        Launch browser with anti-detect features
        
        Args:
            profile_name: Profile to use (None for new session)
            headless: Run without visible window
            proxy: Proxy server (host:port or user:pass@host:port)
            url: Initial URL to load
        
        Returns:
            True if launched successfully
        """
        logger.info("=" * 60)
        logger.info(f"LUCID EMPIRE :: {self.platform} Class")
        logger.info("=" * 60)
        
        if self.camoufox_available:
            return self._launch_camoufox(profile_name, headless, proxy, url)
        elif self.playwright_available:
            return self._launch_playwright(profile_name, headless, proxy, url)
        else:
            logger.error("No browser engine available!")
            return False
    
    def _launch_camoufox(
        self,
        profile_name: Optional[str],
        headless: bool,
        proxy: Optional[str],
        url: str
    ) -> bool:
        """Launch using Camoufox anti-detect engine"""
        try:
            from camoufox.sync_api import Camoufox
            from camoufox import DefaultAddons
            
            logger.info("Launching Camoufox...")
            
            # Build launch options
            opts: Dict[str, Any] = {
                'headless': headless,
                'humanize': True,
                'block_webrtc': True,
                'exclude_addons': [DefaultAddons.UBO],
            }
            
            # Add proxy if specified
            if proxy:
                if '@' in proxy:
                    # user:pass@host:port format
                    auth, server = proxy.rsplit('@', 1)
                    user, password = auth.split(':', 1)
                    opts['proxy'] = {
                        'server': f'http://{server}',
                        'username': user,
                        'password': password
                    }
                else:
                    opts['proxy'] = {'server': f'http://{proxy}'}
                logger.info(f"  Proxy: {proxy.split('@')[-1] if '@' in proxy else proxy}")
            
            # Launch browser
            with Camoufox(**opts) as browser:
                page = browser.new_page()
                page.goto(url)
                
                logger.info("")
                logger.info("╔════════════════════════════════════════════╗")
                logger.info("║  LUCID BROWSER ACTIVE                      ║")
                logger.info("║                                            ║")
                logger.info("║  • Anti-fingerprinting: ENABLED           ║")
                logger.info("║  • WebRTC leak protection: ENABLED        ║")
                logger.info("║  • Human-like behavior: ENABLED           ║")
                logger.info("╚════════════════════════════════════════════╝")
                logger.info("")
                logger.info(f"  URL: {url}")
                logger.info("")
                logger.info("Press ENTER to close browser...")
                
                try:
                    input()
                except KeyboardInterrupt:
                    pass
                
                return True
                
        except Exception as e:
            error_msg = str(e)
            if "executable doesn't exist" in error_msg or "not found" in error_msg.lower():
                logger.warning("Camoufox binary not installed.")
                logger.info("Run: python -m camoufox fetch")
                logger.info("Falling back to Playwright...")
                return self._launch_playwright(profile_name, headless, proxy, url)
            
            logger.error(f"Camoufox launch failed: {e}")
            return False
    
    def _launch_playwright(
        self,
        profile_name: Optional[str],
        headless: bool,
        proxy: Optional[str],
        url: str
    ) -> bool:
        """Fallback to Playwright Firefox"""
        try:
            from playwright.sync_api import sync_playwright
            
            logger.warning("Using Playwright fallback (limited anti-detect)")
            
            with sync_playwright() as p:
                # Build launch options
                launch_opts = {'headless': headless}
                context_opts = {'locale': 'en-US'}
                
                if proxy:
                    context_opts['proxy'] = {'server': f'http://{proxy}'}
                
                browser = p.firefox.launch(**launch_opts)
                context = browser.new_context(**context_opts)
                page = context.new_page()
                page.goto(url)
                
                logger.info("")
                logger.info("╔════════════════════════════════════════════╗")
                logger.info("║  PLAYWRIGHT BROWSER ACTIVE (FALLBACK)      ║")
                logger.info("╚════════════════════════════════════════════╝")
                logger.info("")
                logger.info(f"  URL: {url}")
                logger.info("")
                logger.info("Press ENTER to close browser...")
                
                try:
                    input()
                except KeyboardInterrupt:
                    pass
                
                browser.close()
                return True
                
        except Exception as e:
            logger.error(f"Playwright launch failed: {e}")
            return False


def main():
    """CLI entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Lucid Empire Anti-Detect Browser Launcher',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python unified_launcher.py                    # Interactive menu
  python unified_launcher.py --list-profiles   # List profiles
  python unified_launcher.py --profile Titan_1 # Launch with profile
  python unified_launcher.py --headless        # Headless mode
        """
    )
    
    parser.add_argument('--profile', '-p', help='Profile name to use')
    parser.add_argument('--headless', '-H', action='store_true', help='Run headless')
    parser.add_argument('--proxy', help='Proxy server (host:port)')
    parser.add_argument('--url', default='https://www.google.com', help='Initial URL')
    parser.add_argument('--list-profiles', '-l', action='store_true', help='List profiles')
    
    args = parser.parse_args()
    
    launcher = PlatformLauncher()
    
    if args.list_profiles:
        profiles = launcher.list_profiles()
        print(f"\nAvailable Profiles ({len(profiles)}):")
        print("-" * 40)
        for p in profiles:
            print(f"  • {p}")
        return
    
    # Launch browser
    launcher.launch(
        profile_name=args.profile,
        headless=args.headless,
        proxy=args.proxy,
        url=args.url
    )


if __name__ == "__main__":
    main()
