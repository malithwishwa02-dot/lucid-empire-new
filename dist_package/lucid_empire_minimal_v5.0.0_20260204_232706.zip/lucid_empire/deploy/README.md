# LUCID EMPIRE - Unified Deployment Documentation
# Platform-specific deployment guides with Iron Rules compliance

## Overview

LUCID EMPIRE v5.0-TITAN supports two distinct deployment classes:

- **TITAN Class** (Linux): Kernel-level sovereignty with eBPF/XDP
- **STEALTH Class** (Windows): Usermode flexibility with DLL injection

## Iron Rules Compliance

Both deployment classes enforce strict operational security rules:

### Linux TITAN Class Iron Rules
- **LR-1**: Root privileges or CAP_NET_ADMIN required
- **LR-2**: libfaketime LD_PRELOAD for temporal masking
- **LR-3**: systemd service persistence
- **LR-4**: iptables fail-safe networking
- **LR-5**: Interface binding mandatory

### Windows STEALTH Class Iron Rules
- **WR-1**: Administrator privileges required
- **WR-2**: Windows Defender exclusion required
- **WR-3**: Firewall rule for port 8000 required
- **WR-4**: Target process must be running
- **WR-5**: Time hook must be active

## Quick Deployment

### Linux TITAN Class

```bash
# Download and run deployment script
curl -fsSL https://raw.githubusercontent.com/your-repo/lucid-empire/main/deploy/linux_titan_deploy.sh -o deploy.sh
chmod +x deploy.sh
sudo ./deploy.sh

# Alternative: Manual deployment
sudo apt-get update
sudo apt-get install -y build-essential clang llvm libelf-dev libbpf-dev linux-headers-$(uname -r)
make -C backend/network
sudo ./backend/network/xdp_loader -i eth0
```

### Windows STEALTH Class

```powershell
# Run deployment script (as Administrator)
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
.\deploy\windows_stealth_deploy.ps1

# Alternative: Manual deployment
# 1. Install Microsoft Detours
# 2. Build TimeShift.dll and dll_injector.exe
# 3. Set up Windows Defender exclusion
Add-MpPreference -ExclusionPath "C:\Program Files\LUCID EMPIRE"
# 4. Set up firewall rule
New-NetFirewallRule -DisplayName "LUCID API" -Direction Inbound -LocalPort 8000 -Protocol TCP -Action Allow
```

## Detailed Deployment Steps

### Linux TITAN Class

#### Prerequisites
- Linux kernel 5.8+ (eBPF/XDP support)
- Root access or CAP_NET_ADMIN capability
- Development tools: clang, llvm, libbpf-dev
- libfaketime for temporal masking

#### Step 1: System Preparation
```bash
# Update system
sudo apt-get update && sudo apt-get upgrade -y

# Install dependencies
sudo apt-get install -y \
    build-essential \
    clang \
    llvm \
    libelf-dev \
    libbpf-dev \
    linux-headers-$(uname -r) \
    libfaketime-dev \
    python3.10 \
    python3.10-dev \
    systemd
```

#### Step 2: Compile eBPF Components
```bash
cd backend/network
make all
# This compiles:
# - xdp_outbound.o (eBPF bytecode)
# - xdp_loader (userspace loader)
```

#### Step 3: Set Capabilities
```bash
# Set CAP_NET_ADMIN for Python (alternative to root)
sudo setcap cap_net_admin+ep /usr/bin/python3.10

# Verify capabilities
getcap /usr/bin/python3.10
# Should show: cap_net_admin+ep
```

#### Step 4: Deploy Network Shield
```bash
# Load XDP program
sudo ./xdp_loader -i eth0

# Verify eBPF program is loaded
sudo bpftool prog list | grep xdp
```

#### Step 5: Install Service
```bash
# Create systemd service
sudo cp deploy/lucid-titan.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable lucid-titan
sudo systemctl start lucid-titan
```

#### Step 6: Verify Deployment
```bash
# Check service status
sudo systemctl status lucid-titan

# Test API
curl http://localhost:8000/

# Validate Iron Rules
sudo ./deploy/linux_titan_deploy.sh --validate
```

### Windows STEALTH Class

#### Prerequisites
- Windows 10/11 (x64)
- Administrator privileges
- Microsoft Visual Studio Build Tools
- Microsoft Detours library

#### Step 1: Install Dependencies
```powershell
# Install Microsoft Detours
Invoke-WebRequest -Uri "https://github.com/microsoft/Detours/archive/refs/tags/v4.0.1.zip" -OutFile "detours.zip"
Expand-Archive -Path "detours.zip" -DestinationPath "C:\Program Files\Microsoft Research"
# Build Detours (follow official instructions)
```

#### Step 2: Set Up Security Exclusions
```powershell
# Windows Defender exclusion (Iron Rule WR-2)
Add-MpPreference -ExclusionPath "C:\Program Files\LUCID EMPIRE"

# Firewall rule (Iron Rule WR-3)
New-NetFirewallRule -DisplayName "LUCID API" -Direction Inbound -LocalPort 8000 -Protocol TCP -Action Allow
```

#### Step 3: Build Components
```powershell
cd backend\network

# Build TimeShift DLL
cl /std:c++17 /EHsc /W3 /O2 /D "_WINDLL" /D "_USRDLL" TimeShift.cpp /Fe:TimeShift.dll /link /DLL kernel32.lib user32.lib advapi32.lib psapi.lib

# Build DLL injector
cl /std:c++17 /EHsc /W3 /O2 dll_injector.cpp /Fe:dll_injector.exe /link kernel32.lib user32.lib advapi32.lib psapi.lib ws2_32.lib
```

#### Step 4: Test DLL Injection
```powershell
# Start Firefox (target process)
Start-Process firefox

# Test injection (Iron Rule WR-4)
.\dll_injector.exe -v --days 90

# Verify TimeShift.log for injection details
```

#### Step 5: Install Service
```powershell
# Create Windows service
New-Service -Name "LucidStealth" -BinaryPathName "C:\Program Files\LUCID EMPIRE\dll_injector.exe" -DisplayName "LUCID STEALTH Service" -StartupType Manual

# Start service
Start-Service -Name "LucidStealth"
```

#### Step 6: Verify Deployment
```powershell
# Check service status
Get-Service -Name "LucidStealth"

# Test API
Invoke-RestMethod -Uri "http://localhost:8000/"

# Validate Iron Rules
.\deploy\windows_stealth_deploy.ps1 -ValidateOnly
```

## Configuration

### Environment Variables

#### Linux TITAN Class
```bash
# Temporal masking
export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libfaketime.so.1
export FAKETIME_FOLLOW_FILE=/tmp/lucid_time_control
export FAKETIME_DONT_RESET=1
export FAKETIME_DONT_FAKE_MONOTONIC=1

# Network shielding
export LUCID_INTERFACE=eth0
export LUCID_TTL_MASK=128
export LUCID_WINDOW_MASK=65535
```

#### Windows STEALTH Class
```powershell
# TimeShift configuration
# TimeShift.conf contents:
enabled=1
time_offset=-7776000000000  # 90 days in 100ns units
target_pid=0  # Auto-detect
log_file=TimeShift.log
```

### Profile Configuration

Both classes use the same profile structure:

```json
{
  "id": "Titan_SoftwareEng_USA_001",
  "name": "Marcus Chen",
  "age": 28,
  "location": "San Francisco",
  "persona": "Software Engineer",
  "trust_score": 94,
  "hardware_fingerprint": {
    "cpu_cores": 8,
    "memory_gb": 16,
    "gpu": "NVIDIA RTX 3060",
    "screen_resolution": "1920x1080"
  },
  "network_config": {
    "proxy_url": "192.168.1.1:8080",
    "ttl_mask": 128,
    "window_size": 65535
  }
}
```

## Troubleshooting

### Linux TITAN Class Issues

#### eBPF Program Fails to Load
```bash
# Check kernel support
ls /proc/sys/net/ipv4/conf/*/forwarding

# Check XDP support
ethtool -k eth0 | grep xdp

# Common solutions:
# 1. Update kernel to 5.8+
# 2. Ensure root privileges
# 3. Check interface binding
```

#### libfaketime Issues
```bash
# Check library installation
find /usr -name "*libfaketime*" 2>/dev/null

# Test temporal masking
LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libfaketime.so.1 FAKETIME="-90d" date

# Common solutions:
# 1. Install libfaketime-dev
# 2. Check library paths
# 3. Verify LD_PRELOAD syntax
```

### Windows STEALTH Class Issues

#### DLL Injection Fails
```powershell
# Check Windows Defender exclusions
Get-MpPreference | Select-Object ExclusionPath

# Check target process
Get-Process firefox

# Common solutions:
# 1. Run as Administrator
# 2. Add Defender exclusion
# 3. Ensure Firefox is running
# 4. Check DLL dependencies
```

#### Time Hook Not Active
```powershell
# Check TimeShift.log
Get-Content "C:\Program Files\LUCID EMPIRE\TimeShift.log"

# Test time functions
# In injected process, check if time is spoofed

# Common solutions:
# 1. Verify DLL injection
# 2. Check TimeShift.conf
# 3. Restart target process
```

## Security Considerations

### Network Security
- All traffic masked at kernel/usermode level
- No plaintext fingerprint leakage
- Proxy configuration mandatory
- Fail-safe mechanisms enabled

### Process Security
- Isolated execution environments
- No cross-profile data leakage
- Secure inter-process communication
- Audit logging enabled

### Data Security
- Local-only storage (no cloud sync)
- Encrypted profile data
- Secure key management
- Automatic cleanup on shutdown

## Performance Optimization

### Linux TITAN Class
```bash
# Optimize eBPF performance
echo 1 > /proc/sys/net/core/netdev_max_backlog
echo 1000000 > /proc/sys/net/core/rmem_max
echo 1000000 > /proc/sys/net/core/wmem_max

# Optimize system limits
ulimit -l unlimited
```

### Windows STEALTH Class
```powershell
# Optimize DLL injection performance
# Set process priority
(Get-Process firefox).PriorityClass = "High"

# Optimize memory usage
[System.GC]::Collect()
```

## Monitoring and Logging

### Linux TITAN Class
```bash
# Service logs
journalctl -u lucid-titan -f

# eBPF statistics
sudo bpftool map show pinned /sys/fs/bpf/xdp_stats_map

# System performance
htop
iotop
```

### Windows STEALTH Class
```powershell
# Service logs
Get-EventLog -LogName Application -Source "LucidStealth" -Newest 10

# Process monitoring
Get-Process | Where-Object {$_.ProcessName -like "*firefox*"}

# Performance counters
Get-Counter "\Processor(_Total)\% Processor Time"
```

## Maintenance

### Regular Tasks
- Update eBPF programs when kernel updates
- Refresh Windows Defender exclusions after updates
- Rotate profile encryption keys
- Update proxy configurations
- Monitor system resource usage

### Backup and Recovery
```bash
# Linux: Backup profiles
tar -czf lucid-backup-$(date +%Y%m%d).tar.gz lucid_profile_data/

# Windows: Backup profiles
Compress-Archive -Path "C:\Program Files\LUCID EMPIRE\lucid_profile_data" -DestinationPath "lucid-backup-$(Get-Date -Format yyyyMMdd).zip"
```

## Support

For deployment issues:
1. Check Iron Rules compliance
2. Review system logs
3. Verify prerequisites
4. Consult troubleshooting section
5. Create issue with system details

Include:
- Operating system and version
- Kernel version (Linux)
- Error messages
- Configuration files
- System logs
