#!/bin/bash
# LUCID EMPIRE TITAN Class - Linux Deployment Script
# Implements Iron Rules validation and automated deployment

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
TITAN_VERSION="v5.0-TITAN"
INSTALL_DIR="/opt/lucid-empire"
SERVICE_NAME="lucid-titan"
LOG_FILE="/var/log/lucid-titan-deploy.log"

# Logging function
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$1] $2" | tee -a "$LOG_FILE"
}

# Print colored output
print_status() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

# Check if running as root (Iron Rule LR-1)
check_root_privileges() {
    print_info "Checking Iron Rule LR-1: Root privileges..."
    
    if [[ $EUID -ne 0 ]]; then
        print_error "Iron Rule LR-1 violation: This script requires root privileges"
        print_error "Please run: sudo $0"
        exit 1
    fi
    
    print_status "✓ Root privileges confirmed"
}

# Check kernel version compatibility
check_kernel_compatibility() {
    print_info "Checking kernel compatibility..."
    
    kernel_version=$(uname -r)
    kernel_major=$(echo $kernel_version | cut -d. -f1)
    kernel_minor=$(echo $kernel_version | cut -d. -f2)
    
    if [[ $kernel_major -lt 5 ]] || [[ $kernel_major -eq 5 && $kernel_minor -lt 8 ]]; then
        print_error "Kernel version $kernel_version is too old"
        print_error "TITAN class requires kernel 5.8+ for eBPF/XDP support"
        exit 1
    fi
    
    print_status "✓ Kernel $kernel_version compatible with eBPF/XDP"
}

# Check network interface
check_network_interface() {
    print_info "Checking network interface..."
    
    # Try to find primary interface
    INTERFACE=$(ip route | grep default | awk '{print $5}' | head -n1)
    
    if [[ -z "$INTERFACE" ]]; then
        INTERFACE="eth0"  # Default fallback
    fi
    
    if ! ip link show "$INTERFACE" &>/dev/null; then
        print_error "Network interface $INTERFACE not found"
        print_error "Available interfaces:"
        ip link show | grep -E "^[0-9]+:" | cut -d: -f2 | sed 's/^ /  /'
        exit 1
    fi
    
    print_status "✓ Network interface $INTERFACE found"
    echo "INTERFACE=$INTERFACE" > /tmp/lucid_interface.conf
}

# Install system dependencies
install_dependencies() {
    print_info "Installing system dependencies..."
    
    # Update package list
    apt-get update
    
    # Install required packages
    apt-get install -y \
        build-essential \
        clang \
        llvm \
        libelf-dev \
        libbpf-dev \
        linux-headers-$(uname -r) \
        pkg-config \
        libfaketime-dev \
        python3.10 \
        python3.10-dev \
        python3-pip \
        systemd
    
    print_status "✓ Dependencies installed"
}

# Set capabilities for Python (Iron Rule LR-1 alternative)
set_python_capabilities() {
    print_info "Setting Python capabilities..."
    
    python_path=$(which python3.10)
    
    if [[ -z "$python_path" ]]; then
        print_error "Python 3.10 not found"
        exit 1
    fi
    
    # Set CAP_NET_ADMIN capability
    setcap cap_net_admin+ep "$python_path"
    
    # Verify capabilities
    if getcap "$python_path" | grep -q "cap_net_admin+ep"; then
        print_status "✓ Python CAP_NET_ADMIN capability set"
    else
        print_error "Failed to set Python capabilities"
        exit 1
    fi
}

# Create installation directory
create_install_directory() {
    print_info "Creating installation directory..."
    
    mkdir -p "$INSTALL_DIR"
    mkdir -p "$INSTALL_DIR/network"
    mkdir -p "$INSTALL_DIR/logs"
    mkdir -p "$INSTALL_DIR/config"
    
    print_status "✓ Installation directory created"
}

# Compile eBPF/XDP components
compile_ebpf_components() {
    print_info "Compiling eBPF/XDP network shield..."
    
    cd "$INSTALL_DIR/network"
    
    # Compile XDP program
    if ! clang -O2 -target bpf -D__KERNEL__ -c xdp_outbound.c -o xdp_outbound.o; then
        print_error "Failed to compile XDP program"
        exit 1
    fi
    
    # Compile loader
    if ! gcc -Wall -O2 -g -o xdp_loader xdp_loader.c -lbpf -lelf -lz; then
        print_error "Failed to compile XDP loader"
        exit 1
    fi
    
    print_status "✓ eBPF/XDP components compiled"
}

# Install Python dependencies
install_python_dependencies() {
    print_info "Installing Python dependencies..."
    
    python3.10 -m pip install --upgrade pip
    python3.10 -m pip install -r requirements.txt
    
    print_status "✓ Python dependencies installed"
}

# Create systemd service (Iron Rule LR-3)
create_systemd_service() {
    print_info "Creating systemd service..."
    
    cat > "/etc/systemd/system/$SERVICE_NAME.service" << EOF
[Unit]
Description=LUCID EMPIRE TITAN Class Network Shield
After=network.target
Wants=network.target

[Service]
Type=simple
User=root
Group=root
WorkingDirectory=$INSTALL_DIR
Environment=LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libfaketime.so.1
Environment=FAKETIME_FOLLOW_FILE=/tmp/lucid_time_control
Environment=FAKETIME_DONT_RESET=1
Environment=FAKETIME_DONT_FAKE_MONOTONIC=1
ExecStart=/usr/bin/python3.10 backend/lucid_api.py
ExecReload=/bin/kill -HUP \$MAINPID
KillMode=mixed
TimeoutStopSec=5
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=$INSTALL_DIR /tmp
NoNewPrivileges=true

# Iron Rules compliance
CapabilityBoundingSet=CAP_NET_ADMIN CAP_SETUID CAP_SETGID
AmbientCapabilities=CAP_NET_ADMIN

[Install]
WantedBy=multi-user.target
EOF
    
    systemctl daemon-reload
    systemctl enable "$SERVICE_NAME"
    
    print_status "✓ Systemd service created"
}

# Configure iptables fail-safe (Iron Rule LR-4)
configure_iptables() {
    print_info "Configuring iptables fail-safe rules..."
    
    # Create fail-safe chain
    iptables -N LUCID_FAILSAFE 2>/dev/null || true
    
    # Add fail-safe rules (drop traffic if XDP fails)
    iptables -A OUTPUT -j LUCID_FAILSAFE 2>/dev/null || true
    
    # Save iptables rules
    if command -v iptables-save &>/dev/null; then
        iptables-save > "$INSTALL_DIR/config/iptables.rules"
    fi
    
    print_status "✓ iptables fail-safe configured"
}

# Validate Iron Rules compliance
validate_iron_rules() {
    print_info "Validating Iron Rules compliance..."
    
    # LR-1: Root privileges
    if [[ $EUID -eq 0 ]]; then
        print_status "✓ LR-1: Root privileges confirmed"
    else
        print_error "✗ LR-1: Root privileges required"
        return 1
    fi
    
    # LR-2: Temporal injection
    if ldconfig -p | grep -q libfaketime; then
        print_status "✓ LR-2: libfaketime available"
    else
        print_warning "⚠ LR-2: libfaketime not found in system paths"
    fi
    
    # LR-3: Persistence
    if systemctl is-enabled "$SERVICE_NAME" &>/dev/null; then
        print_status "✓ LR-3: Systemd service configured"
    else
        print_error "✗ LR-3: Systemd service not configured"
        return 1
    fi
    
    # LR-4: Fail-safe networking
    if iptables -L LUCID_FAILSAFE &>/dev/null; then
        print_status "✓ LR-4: iptables fail-safe configured"
    else
        print_warning "⚠ LR-4: iptables fail-safe may need manual configuration"
    fi
    
    # LR-5: Interface binding
    INTERFACE=$(cat /tmp/lucid_interface.conf 2>/dev/null || echo "eth0")
    if ip link show "$INTERFACE" &>/dev/null; then
        print_status "✓ LR-5: Interface $INTERFACE available for binding"
    else
        print_error "✗ LR-5: Interface $INTERFACE not found"
        return 1
    fi
    
    print_status "✓ Iron Rules validation complete"
}

# Test eBPF/XDP functionality
test_ebpf_functionality() {
    print_info "Testing eBPF/XDP functionality..."
    
    cd "$INSTALL_DIR/network"
    
    # Test XDP loader (dry run)
    if timeout 10s ./xdp_loader -i "$INTERFACE" --test 2>/dev/null; then
        print_status "✓ XDP loader test passed"
    else
        print_warning "⚠ XDP loader test failed (may be normal without full setup)"
    fi
    
    # Check if XDP program is valid
    if file xdp_outbound.o | grep -q "ELF"; then
        print_status "✓ XDP object file valid"
    else
        print_error "✗ XDP object file invalid"
        return 1
    fi
}

# Start services
start_services() {
    print_info "Starting LUCID EMPIRE services..."
    
    # Start main service
    systemctl start "$SERVICE_NAME"
    
    # Check if service is running
    if systemctl is-active "$SERVICE_NAME" &>/dev/null; then
        print_status "✓ TITAN service started"
    else
        print_error "✗ Failed to start TITAN service"
        systemctl status "$SERVICE_NAME"
        return 1
    fi
    
    # Show status
    systemctl status "$SERVICE_NAME" --no-pager
}

# Final verification
final_verification() {
    print_info "Performing final verification..."
    
    # Check API health
    sleep 2
    if curl -s http://localhost:8000/ | grep -q "operational"; then
        print_status "✓ API health check passed"
    else
        print_warning "⚠ API health check failed"
    fi
    
    # Check eBPF program (if loaded)
    if bpftool prog list 2>/dev/null | grep -q "xdp_outbound"; then
        print_status "✓ eBPF program loaded"
    else
        print_warning "⚠ eBPF program not loaded (may load on first request)"
    fi
    
    print_status "✓ TITAN class deployment complete"
}

# Main deployment function
main() {
    echo "LUCID EMPIRE TITAN Class Deployment Script"
    echo "=========================================="
    echo "Version: $TITAN_VERSION"
    echo ""
    
    # Create log file
    mkdir -p "$(dirname "$LOG_FILE")"
    touch "$LOG_FILE"
    
    log "DEPLOY_START" "Starting TITAN class deployment"
    
    # Run deployment steps
    check_root_privileges || exit 1
    check_kernel_compatibility || exit 1
    check_network_interface || exit 1
    
    print_info "Proceeding with installation..."
    install_dependencies || exit 1
    set_python_capabilities || exit 1
    create_install_directory || exit 1
    
    # Copy source files (assuming script is run from source directory)
    if [[ -f "backend/lucid_api.py" ]]; then
        print_info "Copying source files..."
        cp -r backend/* "$INSTALL_DIR/"
        cp -r network/* "$INSTALL_DIR/network/"
    else
        print_error "Source files not found. Please run from project root."
        exit 1
    fi
    
    compile_ebpf_components || exit 1
    install_python_dependencies || exit 1
    create_systemd_service || exit 1
    configure_iptables || exit 1
    
    validate_iron_rules || exit 1
    test_ebpf_functionality || print_warning "eBPF test failed (continuing)"
    
    start_services || exit 1
    final_verification
    
    log "DEPLOY_SUCCESS" "TITAN class deployment completed successfully"
    
    echo ""
    print_status "🎉 LUCID EMPIRE TITAN Class deployment complete!"
    echo ""
    echo "Service Management:"
    echo "  Start:   systemctl start $SERVICE_NAME"
    echo "  Stop:    systemctl stop $SERVICE_NAME"
    echo "  Status:  systemctl status $SERVICE_NAME"
    echo "  Logs:    journalctl -u $SERVICE_NAME -f"
    echo ""
    echo "API Endpoint: http://localhost:8000"
    echo "Documentation: http://localhost:8000/docs"
    echo ""
    echo "Iron Rules Compliance: ✓ PASSED"
    echo "Next: Configure profiles and launch browser"
}

# Handle command line arguments
case "${1:-}" in
    --help|-h)
        echo "LUCID EMPIRE TITAN Class Deployment Script"
        echo "Usage: $0 [options]"
        echo ""
        echo "Options:"
        echo "  --help, -h     Show this help message"
        echo "  --validate     Only validate Iron Rules"
        echo "  --test         Only test eBPF functionality"
        echo "  --status       Show deployment status"
        echo ""
        exit 0
        ;;
    --validate)
        check_root_privileges || exit 1
        validate_iron_rules || exit 1
        exit 0
        ;;
    --test)
        check_root_privileges || exit 1
        test_ebpf_functionality || exit 1
        exit 0
        ;;
    --status)
        echo "LUCID EMPIRE TITAN Class Status"
        echo "==============================="
        systemctl status "$SERVICE_NAME" --no-pager
        echo ""
        echo "Iron Rules Compliance:"
        validate_iron_rules
        exit 0
        ;;
    *)
        main
        ;;
esac
