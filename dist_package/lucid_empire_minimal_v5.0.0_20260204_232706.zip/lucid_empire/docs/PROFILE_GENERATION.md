# 👤 LUCID EMPIRE - AGED PROFILE GENERATION GUIDE

**Version:** 2.0.0 | **Status:** ✅ 100% OPERATIONAL

## Overview

The Genesis Engine creates aged browser profiles that appear to have been actively used for 30-180 days. These profiles contain complete browsing history, cookies, form data, and commerce tokens.

**New in v2.0.0:**
- Firefox SQLite injection via `backend/firefox_injector.py`
- Target warming via `backend/warming_engine.py`
- Profile archival/incineration via `backend/profile_manager.py`

---

## Profile Components

### What's Inside an Aged Profile

| Component | File | Description |
|-----------|------|-------------|
| **Preferences** | `prefs.js` | 217+ Firefox settings |
| **History** | `places.sqlite` | 300+ visited URLs with timestamps |
| **Cookies** | `cookies.sqlite` | 86+ session cookies |
| **Form Data** | `formhistory.sqlite` | Autofill (names, addresses) |
| **Commerce Vault** | `commerce_vault.json` | Payment trust tokens |
| **Metadata** | `profile_metadata.json` | Profile info and status |
| **Extensions** | `extensions/` | Installed browser extensions |
| **Storage** | `storage/` | DOM local/session storage |
| **Cache** | `startupCache/` | Cached resources |

---

## Personas

Choose a persona to determine the browsing pattern:

### Student
- Academic sites (Google Scholar, JSTOR)
- Social media (Discord, Reddit)
- Learning platforms (Canvas, Coursera)
- Entertainment (YouTube, Twitch)

### Worker
- Professional sites (LinkedIn, Slack)
- B2B SaaS (Salesforce, Atlassian)
- Finance (Bloomberg, WSJ)
- Productivity (Zoom, Microsoft 365)

### Gamer
- Gaming platforms (Steam, Epic)
- Streaming (Twitch, YouTube Gaming)
- Game stores (Eneba, G2A)
- Community (Discord, Reddit)

### Professional
- Finance (Chase, Fidelity)
- Travel (Airbnb, Booking.com)
- Executive tools (Salesforce, HubSpot)
- News (Bloomberg, Reuters)

---

## Generation Process

### Phase 1: INCEPTION (T-90 days)
**Establishing Trust Anchors**

The engine visits global trust sites to establish baseline legitimacy:
- Google.com
- Wikipedia.org
- CNN.com / BBC.com
- Major news outlets

### Phase 2: WARMING (T-60 days)
**Building Browsing History**

Persona-specific browsing patterns are simulated:
- Visits relevant websites for the persona
- Creates realistic session durations
- Generates cookie trails
- Builds form history

### Phase 3: COMMERCE (T-30 days)
**Injecting Commerce Tokens**

Trust anchors for e-commerce are established:
- Apple.com/shop
- Amazon.com
- Payment processor tokens
- Cart abandonment signals

### Phase 4: FINALIZE (T-0 days)
**Sealing the Profile**

Final touches:
- Metadata generation
- Profile integrity check
- Status set to "ready"

---

## Using the Control Panel

### Generate New Profile

1. **Open Control Panel**
   ```
   Double-click LAUNCH_INSTALLER.bat
   ```

2. **Fill in Details**
   - **Profile Name:** Enter a unique name (e.g., `Titan_Worker_USA_002`)
   - **Persona:** Select from dropdown (student/worker/gamer/professional)
   - **Age (days):** Set simulation age (30-180, default: 90)

3. **Click Generate**
   ```
   Click: GENERATE AGED PROFILE
   ```

4. **Wait for Completion**
   - Progress bar shows current phase
   - Log displays detailed status
   - Takes ~5-10 seconds for demo mode

5. **Profile Ready**
   - New profile appears in dropdown
   - Select it and click ENTER OBLIVION

---

## Profile Storage

### Location
```
lucid_profile_data/
└── [Profile_Name]/
    ├── prefs.js
    ├── places.sqlite
    ├── cookies.sqlite
    ├── formhistory.sqlite
    ├── commerce_vault.json
    ├── profile_metadata.json
    └── ...
```

### Metadata Format
```json
{
  "id": "Titan_Worker_USA_002",
  "name": "Titan_Worker_USA_002",
  "persona": "worker",
  "age_days": 90,
  "created_at": "2026-02-02T17:30:00.000Z",
  "status": "ready"
}
```

---

## Pre-Configured Profiles

These profiles are included and ready to use:

| Profile | Persona | Age | Status |
|---------|---------|-----|--------|
| `Titan_SoftwareEng_USA_001` | Worker | 90d | Ready |
| `Titan_GovClerk_UK_001` | Worker | 90d | Ready |
| `Phantom_Student_130` | Student | 90d | Ready |
| `sim_airbnb_traveler` | Professional | 90d | Ready |
| `sim_amazon_considered_purchase` | Worker | 90d | Ready |
| `sim_booking_affiliate` | Professional | 90d | Ready |
| `sim_dundle_gift_cards` | Gamer | 90d | Ready |
| `sim_eneba_crypto` | Gamer | 90d | Ready |

---

## Advanced: Genesis Engine API

For programmatic profile generation:

```python
from backend.core.genesis_engine import GenesisEngine

# Create engine with persona
engine = GenesisEngine(
    persona="worker",
    proxy_geo="New York",
    proxy_country="US",
    base_dir="./lucid_profile_data"
)

# Run full 90-day cycle
await engine.execute_90_day_cycle()
```

---

## Tips

1. **Unique Names:** Always use unique profile names to avoid conflicts
2. **Match Persona:** Choose persona that matches your use case
3. **Age Matters:** Older profiles (90+ days) have more trust signals
4. **Backup Profiles:** Copy profile folders to preserve them

---

**Authority:** Dva.12  
**Last Updated:** February 2, 2026
