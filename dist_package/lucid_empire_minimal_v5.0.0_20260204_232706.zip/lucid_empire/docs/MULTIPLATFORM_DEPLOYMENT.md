# LUCID EMPIRE - Multi-Platform Deployment Protocol

**Protocol Authority:** Dva.12 | **STATUS:** ✅ 100% OPERATIONAL | **Classification:** SOVEREIGN ARCHITECTURE  
**Version:** 2.0.0 | **Repository Integration:** Complete

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Repository Separation Strategy](#repository-separation-strategy)
3. [Linux (TITAN Class) Deployment](#linux-titan-class-deployment)
4. [Windows (STEALTH Class) Deployment](#windows-stealth-class-deployment)
5. [Operational Rules (Iron Rules)](#operational-rules-iron-rules)
6. [Troubleshooting](#troubleshooting)
7. [Verification Checklists](#verification-checklists)

---

## Architecture Overview

LUCID EMPIRE implements a **dual-architecture deployment model** that leverages OS-native masking technologies:

### Design Principles

| Principle | Implementation |
|-----------|-----------------|
| **Sovereignty** | Each platform uses its most powerful native technology (eBPF for Linux, DLL injection for Windows) |
| **Separation** | OS-specific code isolated in `/platforms/{os}/` directories |
| **Fallback Safety** | Backup systems (iptables for Linux, Windows Defender for Windows) |
| **Zero Detection** | Kernel-level masking (Linux) vs usermode stealth (Windows) |
| **Temporal Displacement** | libfaketime (Linux) vs RunAsDate/custom DLL (Windows) |

### Technology Stack by Platform

#### Linux (TITAN Class - Sovereign)
```
Kernel Level:   eBPF/XDP (TTL spoofing, packet manipulation)
Time Masking:   libfaketime (LD_PRELOAD + 90-day displacement)
Backup System:  iptables rules (fail-safe network redirection)
User Level:     Python 3.9+ with CAP_NET_ADMIN capability
Service Model:  systemd service (lucid-empire) running as lucid-agent
Compiler:       clang (LLVM) for eBPF bytecode compilation
```

#### Windows (STEALTH Class - Usermode)
```
Usermode Level: DLL Injection (VirtualAllocEx → CreateRemoteThread)
TTL Spoofing:   WinDivert driver or custom DLL (RunAsDate.dll)
Firewall:       Windows Firewall rules (UDP/TCP ports)
Defender:       Exclusion paths for executable and library directories
Privilege:      Administrator required (token elevation)
Python:         Embedded Python 3.11 (no system Python required)
Service Model:  Scheduled task or manual launcher
```

---

## Repository Separation Strategy

### Directory Structure

```
lucid-empire-new/
├── /platforms/                          # Platform-specific code
│   ├── linux/                           # Linux (TITAN) code
│   │   ├── install_lucid.sh             # Linux installer (700+ lines)
│   │   ├── xdp_outbound.c               # eBPF kernel program
│   │   ├── systemd-service.conf         # Service configuration
│   │   └── libfaketime-config.conf      # Time displacement config
│   │
│   ├── windows/                         # Windows (STEALTH) code
│   │   ├── setup_lucid.ps1              # Windows installer (600+ lines)
│   │   ├── TimeShift.dll                # TTL injection DLL
│   │   ├── launcher.bat                 # Command-line launcher
│   │   └── launcher.ps1                 # PowerShell launcher
│   │
│   └── common/                          # Shared utilities
│       ├── requirements.txt             # Python dependencies
│       └── config_template.json         # Configuration template
│
├── /backend/
│   ├── core/
│   │   ├── ebpf_loader.py               # Linux eBPF loader
│   │   ├── windivert_loader.py          # Windows DLL loader
│   │   └── masking_core.py              # OS-agnostic masking interface
│   │
│   ├── lucid_api.py                     # API endpoint
│   ├── lucid_commander.py               # Control interface
│   └── lucid_manager.py                 # Process manager
│
├── main.py                              # OS detection + conditional routing
├── requirements.txt                     # Python dependencies
└── /docs/
    ├── MULTIPLATFORM_DEPLOYMENT.md      # This file
    ├── IRON_RULES.md                    # Operational rules
    └── PLATFORM_COMPARISON.md           # Feature matrix
```

### Separation Rationale

**Why separate /platforms/ from /backend/?**
- **Maintainability:** OS-specific issues isolated to single directory
- **Installation:** Scripts and dependencies bundled with platform code
- **Security:** Prevents accidental loading of wrong platform code
- **Scalability:** Easy to add new platforms (macOS, BSD) without affecting Linux/Windows

**What goes in /backend/?**
- Python core that's **OS-agnostic**
- Conditional imports (`if platform.system() == "Linux"`: use ebpf_loader)
- API endpoints that route to platform-specific loaders
- Database and network modules

**What goes in /platforms/?**
- Scripts that compile or inject into the OS
- Binary dependencies (libfaketime.so, TimeShift.dll)
- OS-specific configuration files
- Installer executables

---

## Linux (TITAN Class) Deployment

### Architecture: Sovereign Kernel Masking

LINUX deployment uses **eBPF/XDP technology** for kernel-level packet manipulation. This provides:
- Transparent masking (no application-level changes needed)
- Kernel-level authority (maximum privilege)
- Impossible for userspace to bypass
- Requires kernel 5.8+

### Prerequisites

```bash
# Kernel version check
uname -r                    # Should be 5.8.0 or higher

# Required packages
apt-get update && apt-get install -y \
  clang llvm llvm-dev libelf-dev zlib1g-dev \
  libbpf-dev bpftool linux-headers-$(uname -r) \
  libfaketime faketime python3.9 python3.9-venv

# Check bpftool
bpftool --version          # Must be present
```

### Installation Process

#### Step 1: Run the Installer
```bash
# Download and execute
curl -fsSL https://github.com/lucid-empire/installer/releases/download/latest/install_lucid.sh \
  | sudo bash

# Or local execution
sudo bash /platforms/linux/install_lucid.sh
```

#### Step 2: Pre-Flight Checks (Automatic)
The installer performs automatic checks:
```
Phase 1: Kernel Version Check
  ✓ Require kernel 5.8.0+
  ✓ Display current version
  ✗ Abort if < 5.8.0

Phase 2: Privilege Verification
  ✓ Require root OR CAP_NET_ADMIN
  ✗ Abort if standard user

Phase 3: Dependency Validation
  ✓ Check for clang, llvm, bpftool
  ✗ Abort with helpful error if missing
```

#### Step 3: System Preparation (Automatic)
```bash
# Create lucid-agent system user (UID 1337)
useradd -r -s /usr/sbin/nologin -u 1337 lucid-agent

# Set installation directory
export LUCID_HOME=/opt/lucid-empire
mkdir -p $LUCID_HOME/{bin,lib,config,profiles,logs,cache}

# Grant network capabilities
setcap cap_net_admin+ep /usr/bin/python3.9
```

#### Step 4: eBPF Compilation (Critical)
```bash
# Compile XDP program
clang -O2 -target bpf -D__KERNEL__ \
  -I/usr/include/bpf \
  -c /platforms/linux/xdp_outbound.c \
  -o /tmp/xdp_outbound.o

# Verify bytecode
llvm-objdump -d /tmp/xdp_outbound.o | head -20
```

**XDP Program Features:**
- Intercepts all outbound packets
- Modifies TTL field to 128 (Windows value)
- Spools TCP window size
- Returns `XDP_PASS` to allow packet

#### Step 5: Time Displacement (libfaketime)
```bash
# Configure libfaketime
cat > /etc/lucid-empire/faketime.conf << EOF
# libfaketime configuration
FAKETIME_OFFSET=-90d
LIBFAKETIME_NO_CACHE=1
LIBFAKETIME_SKIP_CLOCK_NANOSLEEP=1
EOF

# Test time displacement
LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libfaketime.so.1 \
  /usr/bin/date
```

#### Step 6: Service Installation
```bash
# Install systemd service
sudo systemctl daemon-reload
sudo systemctl enable lucid-empire
sudo systemctl start lucid-empire

# Check status
sudo systemctl status lucid-empire
```

#### Step 7: Python Environment
```bash
# Create virtual environment
python3.9 -m venv /opt/lucid-empire/venv
source /opt/lucid-empire/venv/bin/activate

# Install dependencies
pip install -r /platforms/common/requirements.txt
```

### Verification (Linux)

```bash
# 1. Check service status
sudo systemctl status lucid-empire
# Expected: active (running)

# 2. Verify XDP loading
sudo bpftool prog list
# Expected: xdp_outbound visible in list

# 3. Check TTL modification
sudo tcpdump -i eth0 'ip.ttl == 128' -c 5
# Expected: Packets with TTL 128 visible

# 4. Verify time displacement
ps aux | grep faketime
# Expected: LD_PRELOAD=/usr/lib/.../libfaketime.so.1 in output

# 5. Check iptables backup rules
sudo iptables -L -t nat
# Expected: LUCID-BACKUP chain visible

# 6. Verify capabilities
getcap /usr/bin/python3.9
# Expected: cap_net_admin+ep

# 7. Test API endpoint
curl http://localhost:8000/api/masking-status
# Expected: {"platform": "linux", "status": "active", "loader": "ebpf"}
```

---

## Windows (STEALTH Class) Deployment

### Architecture: Usermode DLL Injection

WINDOWS deployment uses **DLL injection with WinAPI hooks** for stealth masking:
- Usermode operation (no driver required)
- VirtualAllocEx + CreateRemoteThread injection
- TTL and timestamp spoofing
- Requires Administrator privileges

### Prerequisites

```powershell
# Windows version
[System.Environment]::OSVersion.Version
# Should be 10.0.19041 or higher (Windows 10 October 2020 update)

# Administrator check
$IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $IsAdmin) { Write-Host "Must run as Administrator"; exit 1 }

# .NET Framework (for some DLL injection techniques)
Get-ItemProperty -Path 'HKLM:\Software\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release
```

### Installation Process

#### Step 1: Run the Installer (As Administrator)
```powershell
# Right-click PowerShell → Run as Administrator
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force
& 'C:\path\to\setup_lucid.ps1'
```

#### Step 2: Pre-Flight Checks (Automatic)
The installer performs automatic checks:
```
Phase 1: Windows Version Check
  ✓ Require Windows 10.0.19041+ (October 2020 Update)
  ✓ Provide version information
  ✗ Abort if unsupported

Phase 2: Administrator Privilege Check
  ✓ Verify elevated token
  ✗ Abort with UAC re-prompt option

Phase 3: Firewall Configuration
  ✓ Detect Windows Defender
  ✗ Show configuration instructions if missing
```

#### Step 3: Embedded Python Installation
```powershell
# Detect or download Python 3.11
$PythonPath = "C:\Program Files\LUCID EMPIRE\python\python.exe"

if (-not (Test-Path $PythonPath)) {
    # Download Python 3.11 embedded
    $PythonZip = "C:\Temp\python-3.11-embed.zip"
    Invoke-WebRequest -Uri "https://www.python.org/ftp/python/3.11.9/python-3.11.9-embed-amd64.zip" `
      -OutFile $PythonZip
    
    # Extract to installation directory
    Expand-Archive -Path $PythonZip -DestinationPath "C:\Program Files\LUCID EMPIRE\python"
}
```

#### Step 4: Directory Structure Creation
```powershell
$InstallDir = "C:\Program Files\LUCID EMPIRE"
@(
    "$InstallDir\bin",
    "$InstallDir\lib",
    "$InstallDir\config",
    "$InstallDir\profiles",
    "$InstallDir\logs",
    "$InstallDir\cache",
    "$InstallDir\dlls"
) | ForEach-Object {
    New-Item -ItemType Directory -Path $_ -Force | Out-Null
}
```

#### Step 5: Python Dependencies Installation
```powershell
# Install requirements
& "$PythonPath" -m pip install -r "$InstallDir\requirements.txt" `
  --target "$InstallDir\lib" `
  --platform win_amd64
```

#### Step 6: Windows Defender Exclusion
```powershell
# Add exclusion paths (requires Admin)
$ExclusionPaths = @(
    "C:\Program Files\LUCID EMPIRE",
    "$env:APPDATA\LUCID EMPIRE",
    "$env:TEMP\lucid-*"
)

$ExclusionPaths | ForEach-Object {
    Add-MpPreference -ExclusionPath $_ -Force
    Write-Host "Excluded: $_"
}

# Disable real-time monitoring for DLL injection success
# Note: This is optional and user-controlled
# Add-MpPreference -DisableRealtimeMonitoring $true
```

#### Step 7: DLL Injection Setup
```powershell
# Copy TimeShift.dll
Copy-Item -Path ".\platforms\windows\TimeShift.dll" `
  -Destination "$InstallDir\dlls\TimeShift.dll" -Force

# Create launcher script that injects DLL
$LauncherContent = @"
@echo off
set PYTHONPATH=$InstallDir\lib
set WINDIVERT_DLL=$InstallDir\dlls\TimeShift.dll
"$PythonPath" "%~dp0\main.py"
"@
$LauncherContent | Set-Content -Path "$InstallDir\launcher.bat"
```

#### Step 8: Desktop Shortcut Creation
```powershell
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\LUCID EMPIRE.lnk")
$Shortcut.TargetPath = "$InstallDir\launcher.bat"
$Shortcut.WorkingDirectory = $InstallDir
$Shortcut.Description = "LUCID EMPIRE - Anonymity Platform"
$Shortcut.Save()
```

#### Step 9: Firewall Rule Configuration
```powershell
# Create firewall rule for API endpoint
New-NetFirewallRule -DisplayName "LUCID EMPIRE API" `
  -Direction Inbound `
  -Action Allow `
  -Protocol TCP `
  -LocalPort 8000 `
  -Program "$InstallDir\python\python.exe"
```

#### Step 10: Verification and Testing
See [Verification (Windows)](#verification-windows) section below.

### Verification (Windows)

```powershell
# 1. Check installation directory
Get-ChildItem "C:\Program Files\LUCID EMPIRE" -Recurse | Select-Object FullName

# 2. Verify Python installation
& "C:\Program Files\LUCID EMPIRE\python\python.exe" --version
# Expected: Python 3.11.x

# 3. Verify DLL presence
Get-ChildItem "C:\Program Files\LUCID EMPIRE\dlls\TimeShift.dll"
# Expected: File exists

# 4. Check Windows Defender exclusions
Get-MpPreference | Select-Object -ExpandProperty ExclusionPath

# 5. Verify firewall rule
Get-NetFirewallRule -DisplayName "LUCID EMPIRE API"

# 6. Check running processes (if service installed)
Get-Process | Where-Object {$_.ProcessName -like "*lucid*" -or $_.ProcessName -like "*python*"}

# 7. Test API endpoint
Invoke-WebRequest -Uri "http://localhost:8000/api/masking-status"
# Expected: {"platform": "windows", "status": "active", "loader": "dllinjection"}
```

---

## Operational Rules (Iron Rules)

### Linux Iron Rules (TITAN Class)

#### Rule 1: Root/CAP_NET_ADMIN Mandatory
```bash
# The eBPF loader requires either:
# Option A: Root user
sudo systemctl start lucid-empire

# Option B: CAP_NET_ADMIN capability
setcap cap_net_admin+ep /path/to/python3
```
**Consequence:** Without either, eBPF program load fails silently.

#### Rule 2: libfaketime LD_PRELOAD Mandatory
```bash
# Python process must have LD_PRELOAD set
export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libfaketime.so.1
export FAKETIME_OFFSET=-90d

# If systemd service: must be in ExecStart=env LD_PRELOAD=...
```
**Consequence:** System time will be reported as future date (2-3 years ahead).

#### Rule 3: systemd Service = Automatic Start
```bash
# Must be enabled and started
sudo systemctl enable lucid-empire
sudo systemctl start lucid-empire

# Logs available via
sudo journalctl -u lucid-empire -f
```
**Consequence:** Service failure = no masking active.

#### Rule 4: iptables Backup = Fail-Safe
```bash
# If eBPF unloads, backup iptables rule prevents detection
sudo iptables -L -t nat | grep LUCID-BACKUP
```
**Consequence:** Prevents packet leakage during service restart.

#### Rule 5: Network Interface Binding Required
```bash
# XDP program must be attached to primary interface
ip link show
# Then configure in /etc/lucid-empire/config.json:
# "primary_interface": "eth0"
```
**Consequence:** If interface doesn't exist, XDP attach fails.

### Windows Iron Rules (STEALTH Class)

#### Rule 1: Administrator Token Mandatory
```powershell
# Every injection attempt requires:
$IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $IsAdmin) {
    Write-Host "Administrator privileges required"
    exit 1
}
```
**Consequence:** Non-admin execution = DLL injection fails.

#### Rule 2: Windows Defender Exclusion Required
```powershell
# Installation directory MUST be in exclusion list
# Otherwise, Defender blocks DLL injection

# Check current exclusions
Get-MpPreference | Select-Object -ExpandProperty ExclusionPath | Where-Object {$_ -match "LUCID"}
```
**Consequence:** Without exclusion, Windows Defender terminates injected processes.

#### Rule 3: Firewall Rule for API Endpoint
```powershell
# Firewall must allow TCP 8000
Get-NetFirewallRule -DisplayName "LUCID EMPIRE API" | Get-NetFirewallPortFilter
```
**Consequence:** Without rule, API unreachable from network.

#### Rule 4: DLL Injection Target = Active Process
```powershell
# TimeShift.dll injection target must be Firefox or specified browser
# If process terminates, re-injection required

Get-Process | Where-Object {$_.ProcessName -eq "firefox"}
```
**Consequence:** Target process exit = need to re-inject DLL.

#### Rule 5: RunAsDate or TimeShift.dll Mandatory
```powershell
# One of these must be active for time spoofing:
# Option A: RunAsDate.exe wrapper
# Option B: TimeShift.dll injected into process

# Check which is active
Get-Process | Where-Object {$_.ProcessName -match "RunAsDate"}
```
**Consequence:** Without either, Windows reports true system time.

---

## Troubleshooting

### Linux Troubleshooting

#### Issue: "Kernel version too old"
```bash
# Current
uname -r
# Expected: 5.8.0 or higher

# Solution: Kernel upgrade required
sudo apt-get update && sudo apt-get install linux-image-generic
sudo reboot
```

#### Issue: "bpftool not found"
```bash
# Install
sudo apt-get install linux-tools-generic

# Verify
which bpftool
bpftool --version
```

#### Issue: "Permission denied for XDP attach"
```bash
# Check if running as root
whoami  # Expected: root

# If not root, check CAP_NET_ADMIN
getcap /usr/bin/python3.9
# Expected: cap_net_admin+ep

# If not present, add capability
sudo setcap cap_net_admin+ep /usr/bin/python3.9
```

#### Issue: "libfaketime not working (time is real)"
```bash
# Verify LD_PRELOAD is set
ps aux | grep python | grep LD_PRELOAD
# Expected: LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libfaketime.so.1

# If not set in systemd service, edit:
sudo systemctl edit lucid-empire
# Add: Environment="LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libfaketime.so.1"
# Add: Environment="FAKETIME_OFFSET=-90d"

# Reload and restart
sudo systemctl daemon-reload
sudo systemctl restart lucid-empire
```

#### Issue: "XDP program not loading"
```bash
# Check XDP errors
sudo bpftool prog list
# If no xdp_outbound visible, check dmesg

dmesg | tail -20
# Look for "BPF program failed to load" or similar

# Check eBPF source compilation
clang -O2 -target bpf -D__KERNEL__ -c xdp_outbound.c -o test.o
llvm-objdump -d test.o | head -20
```

### Windows Troubleshooting

#### Issue: "Administrator token required"
```powershell
# Current user
[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent() | `
  Select-Object -ExpandProperty Groups

# Solution: Right-click PowerShell → "Run as Administrator"
# Or use runas.exe:
runas /user:Administrator "powershell.exe"
```

#### Issue: "Windows Defender blocked DLL injection"
```powershell
# Check if path is excluded
Get-MpPreference | Select-Object -ExpandProperty ExclusionPath

# Add exclusion
Add-MpPreference -ExclusionPath "C:\Program Files\LUCID EMPIRE" -Force

# Or disable real-time monitoring (not recommended)
Add-MpPreference -DisableRealtimeMonitoring $true
```

#### Issue: "Python not found"
```powershell
# Check installation path
Get-ChildItem "C:\Program Files\LUCID EMPIRE\python\python.exe"

# If not found, re-run installer in Python installation phase
& ".\setup_lucid.ps1" -Phase "Dependencies"
```

#### Issue: "Firewall blocking API endpoint"
```powershell
# Check firewall rule
Get-NetFirewallRule -DisplayName "LUCID EMPIRE API" | Format-List

# If missing, create:
New-NetFirewallRule -DisplayName "LUCID EMPIRE API" `
  -Direction Inbound `
  -Action Allow `
  -Protocol TCP `
  -LocalPort 8000

# Test connectivity
Test-NetConnection -ComputerName localhost -Port 8000
```

#### Issue: "Time spoofing not active"
```powershell
# Check if RunAsDate or TimeShift.dll is active
Get-Process | Where-Object {$_.ProcessName -match "RunAsDate|firefox"}

# Verify TimeShift.dll exists
Get-ChildItem "C:\Program Files\LUCID EMPIRE\dlls\TimeShift.dll"

# If missing, restore from installer
Copy-Item -Path ".\platforms\windows\TimeShift.dll" `
  -Destination "C:\Program Files\LUCID EMPIRE\dlls\TimeShift.dll" -Force
```

---

## Verification Checklists

### Linux Verification Checklist

- [ ] **Kernel Version**
  ```bash
  uname -r | grep -E '^[5-9]\.[8-9]|^[1-9][0-9]'
  ```

- [ ] **Root or CAP_NET_ADMIN**
  ```bash
  whoami  # root
  # OR
  getcap /usr/bin/python3.9 | grep cap_net_admin
  ```

- [ ] **eBPF Compilation Successful**
  ```bash
  file /tmp/xdp_outbound.o | grep -i elf
  ```

- [ ] **Service Running**
  ```bash
  sudo systemctl is-active lucid-empire
  # Expected: active
  ```

- [ ] **XDP Program Loaded**
  ```bash
  sudo bpftool prog list | grep xdp_outbound
  ```

- [ ] **libfaketime Active**
  ```bash
  ps aux | grep python | grep LD_PRELOAD
  ```

- [ ] **iptables Backup Rule**
  ```bash
  sudo iptables -L -t nat | grep LUCID
  ```

- [ ] **API Responds**
  ```bash
  curl -s http://localhost:8000/api/masking-status | jq .
  ```

### Windows Verification Checklist

- [ ] **Administrator Token**
  ```powershell
  ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
  # Expected: True
  ```

- [ ] **Windows Version Compatible**
  ```powershell
  [System.Environment]::OSVersion.Version.Major -ge 10
  # Expected: True
  ```

- [ ] **Python Installed**
  ```powershell
  Get-ChildItem "C:\Program Files\LUCID EMPIRE\python\python.exe"
  ```

- [ ] **Dependencies Installed**
  ```powershell
  & "C:\Program Files\LUCID EMPIRE\python\python.exe" -m pip list | grep -E "requests|fastapi"
  ```

- [ ] **TimeShift.dll Present**
  ```powershell
  Get-ChildItem "C:\Program Files\LUCID EMPIRE\dlls\TimeShift.dll"
  ```

- [ ] **Defender Exclusion Added**
  ```powershell
  Get-MpPreference | Select-Object -ExpandProperty ExclusionPath | Where-Object {$_ -match "LUCID"}
  ```

- [ ] **Firewall Rule Active**
  ```powershell
  Get-NetFirewallRule -DisplayName "LUCID EMPIRE API" | Select-Object Enabled
  # Expected: True
  ```

- [ ] **API Responds**
  ```powershell
  Invoke-WebRequest -Uri "http://localhost:8000/api/masking-status" | Select-Object -ExpandProperty Content | ConvertFrom-Json
  ```

---

## Deployment Summary

| Aspect | Linux (TITAN) | Windows (STEALTH) |
|--------|---------------|-------------------|
| **Installer** | Bash script | PowerShell script |
| **Root/Admin** | Required | Required |
| **Kernel Technology** | eBPF/XDP | DLL Injection |
| **Time Masking** | libfaketime | RunAsDate/DLL |
| **Compilation** | clang (eBPF) | No compilation |
| **Service Model** | systemd | Scheduled task |
| **Backup System** | iptables rules | Windows Defender |
| **Testing Time** | ~10 minutes | ~15 minutes |

---

**Document Authority:** Dva.12  
**Last Updated:** 2024  
**Classification:** SOVEREIGN ARCHITECTURE - MULTI-PLATFORM DEPLOYMENT
