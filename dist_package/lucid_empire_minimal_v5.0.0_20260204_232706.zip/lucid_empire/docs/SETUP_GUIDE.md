# 🚀 LUCID EMPIRE v5 TITAN - SETUP GUIDE

**Complete Installation & Configuration Instructions**

---

## 📋 Prerequisites

Before starting, ensure you have:

- **Python 3.12+** - [Download](https://www.python.org/downloads/)
- **Node.js 18+** - [Download](https://nodejs.org/)
- **npm 9+** - Included with Node.js
- **Firefox** - [Download](https://www.mozilla.org/firefox/)
- **Git** - [Download](https://git-scm.com/)
- **bash/PowerShell** - For running scripts

### System Requirements

- **OS:** Windows, macOS, or Linux
- **RAM:** Minimum 4GB (8GB recommended)
- **Disk:** 2GB free space (for profiles and dependencies)
- **Network:** Stable internet connection

---

## 📦 Installation Steps

### Step 1: Clone Repository

```bash
git clone https://github.com/malithwishwa02-dot/lucid-empire-new.git
cd lucid-empire-new
```

### Step 2: Install Python Dependencies

```bash
# Create virtual environment (optional but recommended)
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

**Key dependencies:**
- FastAPI 5.0.0-TITAN
- Playwright (Async browser automation)
- Python 3.12+

### Step 3: Install Frontend Dependencies

```bash
# Option A: Main frontend (React + Vite)
cd frontend
npm install
cd ..

# Option B: Alternative dashboard
cd dashboard
npm install
cd ..
```

**Key dependencies:**
- React 18.2.0
- Vite 5.0.0
- Tailwind CSS 3.4.1
- Lucide React (Icons)

### Step 4: Verify Installation

```bash
# Check Python
python --version      # Should be 3.12+

# Check Node
node --version        # Should be 18+
npm --version         # Should be 9+

# Check pip packages
pip list | grep -E "fastapi|playwright|uvicorn"
```

---

## 🔧 Configuration

### Backend Configuration

**Primary Server:** `backend/server.py`
**Alternative API:** `backend/lucid_api.py`

Default settings:
```python
# API Server
HOST = "127.0.0.1"
PORT = 8000
RELOAD = True  # Auto-reload on file changes

# CORS
ALLOW_ORIGINS = ["*"]  # All origins (development only)

# Profile Storage
PROFILE_DIR = "./lucid_profile_data"

# Firefox
FIREFOX_BIN = "firefox"  # or "firefox.exe" on Windows
```

### Frontend Configuration

**File:** `dashboard/vite.config.js`

Default settings:
```javascript
// Dev Server
port: 5173
host: 'localhost'

// API Proxy
proxy: {
  '/api': {
    target: 'http://localhost:8000',
    changeOrigin: true,
  }
}
```

### Environment Variables (Optional)

Create `.env` file in project root:
```bash
# Backend
BACKEND_HOST=localhost
BACKEND_PORT=8000
PROFILE_STORAGE_PATH=./lucid_profile_data

# Frontend
VITE_API_URL=http://localhost:8000
```

---

## 🏃 Running the System

### Quick Start (3 Terminals)

**Terminal 1: Backend API**
```bash
python -m uvicorn backend.lucid_api:app --reload --host 0.0.0.0 --port 8000
```

Expected output:
```
INFO:     Uvicorn running on http://0.0.0.0:8000
INFO:     Application startup complete
```

**Terminal 2: Frontend Dev Server**
```bash
cd dashboard
npm run dev
```

Expected output:
```
VITE v5.0.0  ready in 234 ms

➜  Local:   http://localhost:5173/
➜  press h to show help
```

**Terminal 3: Open Dashboard**
```bash
# Open in browser
http://localhost:5173/

# Or use curl to test backend
curl http://localhost:8000/
```

### Alternative: Run Backend Only

For testing API without frontend:
```bash
python -m uvicorn backend.lucid_api:app --port 8000
```

Test endpoints with curl:
```bash
# Get aged profiles
curl http://localhost:8000/api/aged-profiles

# Launch browser
curl -X POST http://localhost:8000/api/browser/launch \
  -H "Content-Type: application/json" \
  -d '{"profile_id": "Titan_SoftwareEng_USA_001"}'
```

---

## 🧪 Verification Steps

### Step 1: Backend Health Check

```bash
curl http://localhost:8000/
```

Expected response:
```json
{
  "status": "operational",
  "message": "Lucid Empire API - Advanced Behavioral Simulation",
  "docs": "/docs"
}
```

### Step 2: Verify Aged Profiles

```bash
curl http://localhost:8000/api/aged-profiles
```

Expected response:
```json
{
  "status": "success",
  "total": 12,
  "profiles": [
    {
      "name": "Titan_SoftwareEng_USA_001",
      "path": "...",
      "age_days": 90,
      "has_history": true,
      "has_cookies": true,
      "has_commerce": true,
      "has_proxy": true
    }
    // ... 11 more profiles
  ]
}
```

### Step 3: Frontend Loads

1. Open http://localhost:5173/ in browser
2. You should see:
   - LUCID EMPIRE header with green status indicator
   - RAW INTEL INGEST textarea
   - NETWORK TUNNEL input field
   - Identity card (credit card visualization)
   - Pre-flight forensics checklist
   - Console log at bottom

### Step 4: Test Data Input

1. Paste sample data in INGEST field:
   ```
   4147202155019988 09/28 112 JONATHAN DOE
   ```

2. Enter sample proxy:
   ```
   192.168.45.12:8080:user:pass
   ```

3. Click VERIFY button

4. Watch system status update with green checkmarks

---

## 🔍 Troubleshooting

### Issue: Port Already in Use

**Problem:** `Address already in use on 0.0.0.0:8000`

**Solution:**
```bash
# Find process using port 8000 (macOS/Linux)
lsof -i :8000
kill -9 <PID>

# Or use different port
python -m uvicorn backend.lucid_api:app --port 8001
```

### Issue: CORS Error

**Problem:** `Access to XMLHttpRequest blocked by CORS`

**Solution:** Backend CORS is enabled. If still failing:
```python
# In backend/lucid_api.py, ensure this is present:
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

### Issue: Firefox Not Found

**Problem:** `firefox: command not found`

**Solution:**
1. Install Firefox from https://mozilla.org/firefox/
2. Or, update path in `backend/lucid_api.py`:
```python
firefox_bin = "/usr/bin/firefox"  # Linux
firefox_bin = "/Applications/Firefox.app/Contents/MacOS/firefox"  # macOS
firefox_bin = "C:\\Program Files\\Mozilla Firefox\\firefox.exe"  # Windows
```

### Issue: Module Import Errors

**Problem:** `ModuleNotFoundError: No module named 'fastapi'`

**Solution:**
```bash
# Ensure virtual environment is activated
source venv/bin/activate  # macOS/Linux
venv\Scripts\activate     # Windows

# Reinstall dependencies
pip install -r requirements.txt
```

### Issue: Node Modules Missing

**Problem:** `Cannot find module 'react'`

**Solution:**
```bash
cd dashboard
npm install
cd ..
```

---

## 📝 Project Structure After Installation

```
lucid-empire-new/
├── README.md                    # Main documentation
├── requirements.txt             # Python dependencies
├── .gitignore
│
├── backend/
│   ├── lucid_api.py            # FastAPI server (START HERE)
│   ├── __init__.py
│   ├── core/
│   │   ├── genesis_engine.py   # 90-day aging
│   │   ├── profile_store.py    # Profile management
│   │   └── ... (other core modules)
│   ├── network/
│   │   ├── ebpf_loader.py
│   │   └── ... (network modules)
│   └── modules/
│       ├── commerce_injector.py
│       ├── humanization.py
│       └── biometric_mimicry.py
│
├── dashboard/
│   ├── src/
│   │   ├── LucidTitanConsole.jsx  # Main React component
│   │   ├── main.jsx
│   │   └── index.css
│   ├── package.json
│   ├── vite.config.js
│   └── tailwind.config.js
│
├── lucid_profile_data/          # 12 aged profiles
│   ├── Titan_SoftwareEng_USA_001/
│   ├── Titan_GovClerk_UK_001/
│   └── ... (10 more profiles)
│
├── docs/                        # This documentation
│   ├── SETUP_GUIDE.md          # You are here
│   ├── API_DOCUMENTATION.md
│   ├── FRONTEND_GUIDE.md
│   ├── BACKEND_ARCHITECTURE.md
│   └── WORKFLOW.md
│
└── ... (utility scripts)
```

---

## 🚀 First Operation

Once everything is running:

1. **Open Dashboard**
   - http://localhost:5173/

2. **Input Data**
   ```
   FULLZ: 4147202155019988 09/28 112 JONATHAN DOE 88 University Rd Boston MA 02215
   PROXY: 192.168.45.12:8080:user:pass
   ```

3. **Run Pre-Flight Check**
   - Click VERIFY button
   - Wait for all checks (green checkmarks)

4. **Genesis Engine**
   - Click FABRICATE REALITY
   - Watch 10-second aging simulation

5. **Browser Launch**
   - Select profile
   - Click ENTER OBLIVION
   - Firefox opens with aged profile

6. **Manual Operations**
   - You now have complete browser control
   - All profile data loaded (history, cookies, commerce)

7. **Hard Burn**
   - Click BURN when done
   - System resets

---

## 🔧 Advanced Configuration

### Custom Profile Storage

To use different profile directory:
```python
# In backend/lucid_api.py
PROFILE_DIR = "/path/to/custom/profiles"

# Must contain profiles directory structure:
# /path/to/custom/profiles/Titan_SoftwareEng_USA_001/
#   ├── prefs.js
#   ├── places.sqlite
#   └── ... (profile files)
```

### Custom Firefox Binary

To use specific Firefox installation:
```python
# In backend/lucid_api.py line ~150
firefox_bin = "/custom/path/to/firefox"
```

### Development Mode vs Production

**Development (Current):**
```bash
python -m uvicorn backend.lucid_api:app --reload
npm run dev
```

**Production:**
```bash
# Build frontend
cd dashboard
npm run build
cd ..

# Run backend only (serves built frontend)
python -m uvicorn backend.lucid_api:app --host 0.0.0.0 --port 8000
```

---

## 📊 Verification Checklist

After setup, verify:

- [ ] Python 3.12+ installed
- [ ] Node.js 18+ installed
- [ ] Repository cloned successfully
- [ ] Python dependencies installed
- [ ] Frontend dependencies installed
- [ ] Backend starts on port 8000
- [ ] Frontend dev server starts on port 5173
- [ ] Dashboard loads in browser
- [ ] API health check works (curl test)
- [ ] Aged profiles visible (12 total)
- [ ] Pre-flight checks work
- [ ] Genesis engine starts
- [ ] Browser launch works
- [ ] Console logs display correctly

---

## 🆘 Support

For installation issues:
1. Check [WORKFLOW.md](WORKFLOW.md) for complete process
2. Review error messages carefully
3. Check terminal output for specific error details
4. Verify all prerequisites installed correctly
5. Try running in clean virtual environment

---

**Last Updated:** February 2, 2026
**Authority:** Dva.12
