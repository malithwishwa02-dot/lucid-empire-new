# PLATFORM COMPARISON - Linux vs Windows Masking Architecture

**Authority:** Dva.12 | **Classification:** TECHNICAL ANALYSIS | **Document Type:** Architecture Reference  
**Version:** 2.0.0 | **Status:** ✅ 100% OPERATIONAL

---

## Executive Summary

LUCID EMPIRE implements platform-specific masking technologies optimized for each operating system's architecture:

- **Linux (TITAN):** Kernel-level eBPF/XDP masking for maximum sovereignty
- **Windows (STEALTH):** Usermode DLL injection for stealth and flexibility

This document provides detailed technical comparisons to inform deployment decisions.

---

## Technology Comparison Matrix

| Feature | Linux (TITAN) | Windows (STEALTH) | Winner |
|---------|---------------|-------------------|--------|
| **Masking Method** | eBPF/XDP (kernel) | DLL injection (usermode) | Linux (deeper level) |
| **Detectability** | Very low (kernel) | Medium (usermode) | Linux |
| **Performance** | <1ms per packet | 5-10ms per packet | Linux |
| **Memory Overhead** | ~5MB | ~50MB | Linux |
| **Privilege Required** | root/CAP_NET_ADMIN | Administrator | Equal |
| **Compilation** | Required (clang) | None | Windows |
| **Time Spoofing** | libfaketime (LD_PRELOAD) | RunAsDate/DLL | Equal |
| **Network Masking** | XDP transparently | DLL hooks APIs | Linux |
| **Kernel Requirement** | 5.8+ | Windows 10.0.19041+ | Windows (more lenient) |
| **Installation Time** | ~15-20 minutes | ~5-10 minutes | Windows |
| **Persistence** | systemd service | Scheduled task | Linux (more robust) |
| **Firewall Control** | iptables + XDP | WinDivert | Equal |
| **API Endpoint** | HTTP 8000 | HTTP 8000 | Equal |

---

## Detailed Technology Breakdown

### Linux (TITAN Class) Architecture

#### eBPF/XDP Technology

**What is eBPF?**
eBPF (Extended Berkeley Packet Filter) is a lightweight virtual machine running inside the Linux kernel that can execute user-provided programs without recompiling the kernel.

**XDP Layer:**
```
┌─────────────────────────────────────────┐
│  Application Layer (Python FastAPI)     │
│  /api/masking-status endpoint           │
└─────────────────────┬───────────────────┘
                      │
┌─────────────────────▼───────────────────┐
│  ebpf_loader.py                         │
│  Load/unload XDP programs               │
└─────────────────────┬───────────────────┘
                      │
┌─────────────────────▼───────────────────┐
│  Kernel eBPF/XDP Program (xdp_outbound) │
│  - Intercept all outbound packets       │
│  - Modify TTL field (→ 128)             │
│  - Spoof TCP window size                │
│  - Allow packet to proceed              │
│  - Return XDP_PASS                      │
└─────────────────────┬───────────────────┘
                      │
┌─────────────────────▼───────────────────┐
│  Network Interface (eth0, wlan0, etc.)  │
│  Packet transmitted with spoofed fields │
└─────────────────────────────────────────┘
```

**Advantages:**
1. **Kernel-Level Execution:** Runs at packet processing level (impossible to bypass)
2. **Transparent Masking:** No application modification needed
3. **Performance:** <1ms latency per packet (hardware-near)
4. **Sovereignty:** Full control over network traffic
5. **XDP Safety:** Sandboxed execution environment (no kernel crashes)

**Disadvantages:**
1. **Compilation Required:** Must compile eBPF bytecode with clang
2. **Kernel 5.8+ Required:** Not available on older systems
3. **Complexity:** eBPF C programming is complex
4. **Debugging:** Kernel debugging is harder than usermode

**XDP Packet Processing:**
```c
#include <linux/bpf.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <arpa/inet.h>

SEC("xdp_outbound")
int outbound_masking(struct xdp_md *ctx) {
    void *data_end = (void *)(long)ctx->data_end;
    void *data = (void *)(long)ctx->data;
    
    struct ethhdr *eth = data;
    struct iphdr *ip = (struct iphdr *)(eth + 1);
    struct tcphdr *tcp = (struct tcphdr *)((void *)ip + (ip->ihl << 2));
    
    // Check packet bounds
    if ((void *)(tcp + 1) > data_end)
        return XDP_PASS;
    
    // Modify TTL to 128 (Windows value)
    if (ip->protocol == IPPROTO_TCP) {
        ip->ttl = 128;
        // Recalculate checksum...
        
        // Spoof TCP window size
        tcp->window = htons(65535);
    }
    
    return XDP_PASS;  // Allow packet through
}
```

#### Time Displacement (libfaketime)

**What is libfaketime?**
libfaketime is a C library that intercepts time-related system calls and returns fabricated timestamps.

**How it works:**
```bash
# Set environment variables
export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libfaketime.so.1
export FAKETIME_OFFSET=-90d  # 90 days in past
export LIBFAKETIME_NO_CACHE=1

# Launch application
python3 main.py

# Inside Python, when code calls:
import time
time.time()  # Returns: (real_time - 90 days)

from datetime import datetime
datetime.now()  # Returns: (real_date - 90 days)
```

**System Call Interception:**
```
Application Code
    ↓
System Call: gettimeofday() / time() / clock_gettime()
    ↓
libfaketime.so.1 intercepts
    ↓
Compute: real_time + FAKETIME_OFFSET
    ↓
Return: Fabricated time to application
```

**Advantages:**
1. **Transparent:** No code modifications needed
2. **Zero Performance Overhead:** Minimal interception cost
3. **Comprehensive:** Intercepts all major time APIs
4. **Configurable:** Simple environment variables

**Disadvantages:**
1. **Library-Level Only:** Doesn't intercept direct kernel syscalls
2. **Not for Embedded Time:** JavaScript timestamps in DOM not affected
3. **Per-Process:** Each process needs LD_PRELOAD set
4. **Cache Issues:** Must disable caching with LIBFAKETIME_NO_CACHE=1

---

### Windows (STEALTH Class) Architecture

#### DLL Injection Technology

**What is DLL Injection?**
DLL (Dynamic Link Library) injection is a technique to load a custom DLL into another process's memory space, allowing the injector to hook Windows API functions.

**Injection Process:**
```
┌──────────────────────────────┐
│  Python Process              │
│  windivert_loader.py         │
│                              │
│  1. Find target PID (Firefox)│
│  2. OpenProcess()            │
│  3. VirtualAllocEx()         │
│  4. WriteProcessMemory()     │
│  5. CreateRemoteThread()     │
│  6. WaitForSingleObject()    │
└──────────────────────────────┘
              │
              ↓
┌──────────────────────────────┐
│  Firefox Process             │
│  (Injection Target)          │
│                              │
│  CreateRemoteThread Executes:│
│  LoadLibraryA("TimeShift.dll")
└──────────────────────────────┘
              │
              ↓
┌──────────────────────────────┐
│  Firefox Process             │
│  + TimeShift.dll Loaded      │
│                              │
│  DLL Initialization:         │
│  - Hook GetSystemTime()      │
│  - Hook time()               │
│  - Hook clock_gettime()      │
│  - Hook socket operations    │
└──────────────────────────────┘
```

**Injection Steps:**

**Step 1: Find Target Process**
```c
HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
PROCESSENTRY32 pe;
pe.dwSize = sizeof(PROCESSENTRY32);

if (Process32First(hSnapshot, &pe)) {
    do {
        if (strcmp(pe.szExeFile, "firefox.exe") == 0) {
            DWORD dwFirefoxPID = pe.th32ProcessID;
            break;
        }
    } while (Process32Next(hSnapshot, &pe));
}
```

**Step 2: Open Target Process**
```c
HANDLE hProcess = OpenProcess(
    PROCESS_ALL_ACCESS,     // Desired access
    FALSE,                   // Inherit handles
    dwFirefoxPID             // Process ID
);
```

**Step 3: Allocate Memory in Target**
```c
LPVOID lpAlloc = VirtualAllocEx(
    hProcess,                       // Target process handle
    NULL,                           // Base address (auto)
    MAX_PATH,                       // Size: 260 bytes
    MEM_COMMIT | MEM_RESERVE,      // Allocation type
    PAGE_READWRITE                  // Protection
);
```

**Step 4: Write DLL Path to Target Memory**
```c
const char *dllPath = "C:\\Program Files\\LUCID EMPIRE\\dlls\\TimeShift.dll";
WriteProcessMemory(
    hProcess,                       // Target process
    lpAlloc,                        // Remote memory address
    (LPVOID)dllPath,               // Local buffer
    strlen(dllPath) + 1,           // Size
    NULL                            // Bytes written
);
```

**Step 5: Create Remote Thread**
```c
// Get address of LoadLibraryA in target's kernel32.dll
HMODULE hKernel32 = GetModuleHandle("kernel32.dll");
FARPROC pLoadLibraryA = GetProcAddress(hKernel32, "LoadLibraryA");

// Create thread in target process that calls LoadLibraryA(dllPath)
HANDLE hThread = CreateRemoteThread(
    hProcess,                       // Target process
    NULL,                           // Security attributes
    0,                              // Stack size (default)
    (LPTHREAD_START_ROUTINE)pLoadLibraryA,  // Thread function
    lpAlloc,                        // Argument (DLL path)
    0,                              // Creation flags
    NULL                            // Thread ID
);
```

**Step 6: Wait for Injection to Complete**
```c
WaitForSingleObject(hThread, INFINITE);
CloseHandle(hThread);
CloseHandle(hProcess);
```

**Advantages:**
1. **Usermode Operation:** No driver required
2. **Flexible:** Can inject into any process
3. **Fast:** No compilation needed
4. **API Hooking:** Can intercept Windows API calls
5. **No Kernel Changes:** Doesn't require kernel 5.8+

**Disadvantages:**
1. **Detectable:** Antiviruses can detect injection
2. **Process-Dependent:** Must target specific process
3. **Permission Requirement:** Administrator needed
4. **Complexity:** Must understand Windows API
5. **Fragile:** If process crashes, must re-inject

#### TimeShift.dll: API Hooking

**What is DLL Hooking?**
Once TimeShift.dll is injected into Firefox, it hooks (intercepts) Windows API function calls to spoof time and network information.

**Hooked APIs:**
```c
// Original Firefox call:
GetSystemTime(&systemTime);

// Intercepted by TimeShift.dll:
HOOK_GetSystemTime(SYSTEMTIME *pst) {
    // Call real GetSystemTime
    Real_GetSystemTime(pst);
    
    // Modify the output
    pst->wYear = 2023;     // Spoof to 2023
    pst->wMonth = 1;
    pst->wDay = 1;
    
    return;  // Return modified time to Firefox
}
```

**APIs Typically Hooked:**
| API | Purpose | Spoofed Value |
|-----|---------|---------------|
| GetSystemTime() | Current system time | 2023-01-01 |
| GetLocalTime() | Local time | 2023-01-01 |
| GetSystemTimeAsFileTime() | High-precision time | Adjusted |
| time() | UNIX timestamp | Adjusted |
| clock_gettime() | Monotonic clock | Adjusted |
| WSASocket() / socket() | Network socket creation | Modified TTL |

**Hook Chain:**
```
Firefox Code
    ↓
call GetSystemTime()
    ↓
TimeShift.dll Hook Intercepts
    ↓
Call Real GetSystemTime()
    ↓
Modify Output (spoof date)
    ↓
Return to Firefox Code
```

#### Windows Defender Integration

**What is Defender Exclusion?**
Windows Defender real-time protection scans all file access and DLL loads. Exclusion paths bypass this scanning.

**How to Configure:**
```powershell
Add-MpPreference -ExclusionPath "C:\Program Files\LUCID EMPIRE"

# This prevents Defender from:
# - Scanning files in that directory
# - Quarantining suspicious DLLs
# - Blocking DLL injection attempts
```

**Without Exclusion:**
```
DLL Injection Attempt
    ↓
Defender Real-Time Protection Activated
    ↓
Detects: Suspicious LoadLibrary() call
    ↓
Quarantine/Terminate Process
    ↓
Masking Fails
```

**With Exclusion:**
```
DLL Injection Attempt
    ↓
Defender Real-Time Protection
    ↓
Path in Exclusion List → Skip Scanning
    ↓
DLL Loads Successfully
    ↓
Masking Active
```

---

## Performance Comparison

### Latency Analysis

**Linux (XDP Processing):**
```
Packet arrives at NIC
    ↓
XDP program runs (kernel space) [~0.1-0.5 ms]
    ↓
TTL modified, returned to network layer
    ↓
Total latency: < 1 ms
```

**Windows (DLL Hook Processing):**
```
Firefox calls GetSystemTime()
    ↓
Hook intercepts (usermode jump) [~1-2 ms]
    ↓
Real GetSystemTime() called
    ↓
Output modified [~1-2 ms]
    ↓
Return to Firefox [~2-4 ms]
    ↓
Total latency: 5-10 ms
```

### Memory Usage

**Linux eBPF Program:**
- eBPF kernel program: ~10KB
- eBPF maps/buffers: ~100KB
- libfaketime.so.1: ~50KB
- **Total per process: ~50-100MB**

**Windows DLL Injection:**
- TimeShift.dll: ~200KB
- Hooked function trampoline code: ~50KB
- Hook context structures: ~500KB
- **Total per process: ~50-100MB**

### CPU Utilization

**Linux:**
- XDP processing: Hardware-accelerated (near-zero CPU impact)
- libfaketime: Minimal overhead per time call

**Windows:**
- DLL hooking: CPU cost per API call interception
- Multiple hooks can accumulate overhead

---

## Security Analysis

### Linux Security Posture

**Strengths:**
1. **Kernel Authority:** Running in kernel space is harder to detect/bypass
2. **Transparent:** No usermode artifacts
3. **Atomic Operations:** TTL modification in single instruction
4. **No File Artifacts:** Kernel code not stored as file

**Weaknesses:**
1. **Kernel Introspection:** Advanced tools can detect eBPF programs
2. **Capability Detection:** CAP_NET_ADMIN is visible via `getcap` or `/proc`
3. **Systemd Service:** Service file visible to root users

**Detection Vector:**
```bash
# Adversary can detect:
bpftool prog list        # Lists all eBPF programs
ip link show             # Shows XDP attachment
cat /proc/sys/kernel/perf_event_paranoid  # May restrict visibility
```

### Windows Security Posture

**Strengths:**
1. **No Driver Required:** No kernel component to detect
2. **Common Technique:** DLL injection is common (harder to detect as malicious)
3. **Process-Isolated:** Isolated to target process

**Weaknesses:**
1. **API Hooking Detectable:** Hook chains visible in memory
2. **Usermode Access:** Any usermode debugger can dump injected DLL
3. **Defender Exclusion:** Removing exclusion breaks masking

**Detection Vector:**
```powershell
# Adversary can detect:
Get-MpPreference | Select -ExpandProperty ExclusionPath  # See exclusions
Get-Process | Where { ... }  # Enumerate hooks via debugging APIs
Invoke-DMDebugging -Process firefox  # View injected DLLs
```

---

## Installation Complexity

### Linux Installation

**Time Required:** 15-20 minutes

**Complexity Steps:**
1. Kernel version check (1 min)
2. Install build tools (3 min)
3. Compile eBPF program (2 min)
4. Create system user (1 min)
5. Install systemd service (2 min)
6. Setup libfaketime (2 min)
7. Configure iptables (2 min)
8. Verification tests (2 min)

**Error Scenarios:**
- Kernel too old → Abort with helpful message
- clang not installed → Install automatically
- libfaketime missing → Install automatically

### Windows Installation

**Time Required:** 5-10 minutes

**Complexity Steps:**
1. Admin elevation check (1 min)
2. Download Python 3.11 embedded (2 min, may be cached)
3. Extract Python (1 min)
4. Install dependencies (2 min)
5. Configure Defender (1 min)
6. Create firewall rule (1 min)
7. Verification tests (1 min)

**Error Scenarios:**
- Not running as admin → Offer UAC re-prompt
- Python download fails → Use cached version or prompt user
- Defender blocks → Guide user to add exclusion

---

## Operational Deployment Matrix

| Aspect | Linux | Windows |
|--------|-------|---------|
| **Installer Language** | Bash | PowerShell |
| **Service Type** | systemd | Scheduled Task |
| **Log Location** | journalctl / `/var/log/` | Event Viewer / Files |
| **Config Location** | `/etc/lucid-empire/` | `%ProgramFiles%\LUCID EMPIRE\` |
| **Python Method** | System Python 3.9+ | Embedded Python 3.11 |
| **Privilege Escalation** | `sudo` + CAP_NET_ADMIN | UAC elevation |
| **Uninstall Process** | `systemctl stop`, remove files | Remove `%ProgramFiles%` dir |
| **Backup/Restore** | Configuration snapshot | Registry + file backup |

---

## Failure Modes and Recovery

### Linux Failure Modes

| Failure | Symptom | Recovery |
|---------|---------|----------|
| eBPF unload | XDP no longer attached | Restart systemd service |
| Interface down/up | XDP detaches | Systemd service restarts auto-attachment |
| libfaketime missing | Time is real | Install libfaketime package |
| CAP_NET_ADMIN lost | Cannot load eBPF | `setcap cap_net_admin+ep` binary |
| iptables purged | No fail-safe | Restore from backup config |

**Recovery Command:**
```bash
sudo systemctl restart lucid-empire
```

### Windows Failure Modes

| Failure | Symptom | Recovery |
|---------|---------|----------|
| Process terminates | DLL unloaded | Restart process |
| Defender blocks | Cannot inject | Add to exclusion list |
| Admin token lost | Can't access APIs | Run as Administrator |
| DLL missing | Injection fails | Restore from installation |
| Firewall rule deleted | API unreachable | Recreate firewall rule |

**Recovery Command:**
```powershell
Stop-Process -Name firefox -Force
& "C:\Program Files\LUCID EMPIRE\launcher.bat"
```

---

## Feature Comparison by Use Case

### Use Case 1: Web Browsing Anonymity

| Requirement | Linux | Windows |
|-------------|-------|---------|
| **Time Spoofing** | ✓ libfaketime | ✓ TimeShift.dll |
| **TTL Spoofing** | ✓ eBPF/XDP | ✓ WinDivert/DLL |
| **SSL/TLS Transparent** | ✓ Kernel-level | ✓ Hook SSL APIs |
| **DNS Masking** | ✓ eBPF | ✓ DLL hook |
| **Timestamp Obfuscation** | ✓ Excellent | ✓ Good |
| **Detection Resistance** | ✓✓ Excellent | ✓ Good |

**Winner:** Linux (kernel transparency)

### Use Case 2: Remote Operations

| Requirement | Linux | Windows |
|-------------|-------|---------|
| **Process Isolation** | ✓ OS-level | ✓ Process-level |
| **Privilege Requirement** | ✓ Single (root) | ✓ Single (Admin) |
| **Recovery from Crash** | ✓ Auto (systemd) | ○ Manual |
| **Stealth (no visible service)** | ○ Service visible | ✓ Task Scheduler less obvious |
| **API Availability** | ✓ Consistent | ✓ Consistent |
| **Log Cleanup** | ○ Journalctl visible | ✓ Event logs clean |

**Winner:** Windows (less discoverable)

### Use Case 3: Long-Running Operations

| Requirement | Linux | Windows |
|-------------|-------|---------|
| **Uptime/Reliability** | ✓✓ Excellent | ✓ Good |
| **Service Recovery** | ✓ Auto-restart | ○ Manual |
| **Memory Leak Resistance** | ✓ Kernel VM | ✓ Usermode GC |
| **Crash Handling** | ✓ systemd restart | ○ Process restart only |
| **Monitoring/Alerts** | ✓ journalctl | ○ Event Viewer |
| **Scaling Multiple Ops** | ✓ Single eBPF | ✓ Multiple processes |

**Winner:** Linux (systemd recovery)

---

## Recommendation Matrix

### Recommended Platform Based on Scenario

| Scenario | Platform | Reason |
|----------|----------|--------|
| **Mission-Critical Operation** | Linux | Kernel-level guarantees, systemd reliability |
| **Quick Deployment** | Windows | No compilation, 5-10 min install |
| **High-Risk Environment** | Linux | Harder to detect, more sovereign |
| **Multiple Operations** | Windows | Process-isolated, scale independently |
| **Long-Duration (>24h)** | Linux | More stable, better recovery |
| **Shared System** | Windows | Less privilege escalation |
| **Forensic Evasion** | Linux | Kernel artifacts harder to detect |
| **System Admin Available** | Both | Linux preferred if available |
| **Root Access Unavailable** | Windows | Only option if admin only |

---

**Document Authority:** Dva.12  
**Classification:** TECHNICAL ANALYSIS - ARCHITECTURE REFERENCE  
**Last Updated:** 2024  
**Comparison Version:** 1.0
