# 📂 LUCID EMPIRE - PLATFORM STRUCTURE

**Authority:** Dva.12 | **Version:** 5.0.0-TITAN (Backend v2.0.0)  
**Status:** ✅ 100% OPERATIONAL | **Repository Integration:** Complete

---

## Repository Structure

```
lucid-empire-new/
│
├── launch.py                           # Universal launcher (auto-detects OS)
├── LAUNCH_INSTALLER.bat                # Windows quick launcher (root level)
├── lucid_control_panel.py              # Generic control panel (fallback)
├── requirements.txt                    # Python dependencies
├── README.md                           # Main documentation
│
├── platforms/                          # PLATFORM-SPECIFIC CODE
│   │
│   ├── linux/                          # LINUX (TITAN Class)
│   │   ├── LAUNCH_INSTALLER.sh         # Linux quick launcher
│   │   ├── install_lucid_linux.sh      # Full Linux installer
│   │   ├── lucid_control_panel_linux.py # Linux GUI control panel
│   │   └── README.md                   # Linux documentation
│   │
│   ├── windows/                        # WINDOWS (STEALTH Class)
│   │   ├── LAUNCH_INSTALLER.bat        # Windows quick launcher
│   │   ├── lucid_control_panel_windows.py # Windows GUI control panel
│   │   └── README.md                   # Windows documentation
│   │
│   └── common/                         # SHARED RESOURCES
│       ├── requirements.txt            # Common Python dependencies
│       └── config_template.json        # Configuration template
│
├── backend/                            # BACKEND API (Cross-platform)
│   ├── lucid_api.py                    # FastAPI server
│   ├── lucid_commander.py              # Command orchestrator
│   ├── lucid_manager.py                # Profile manager
│   │
│   ├── core/                           # Core modules
│   │   ├── genesis_engine.py           # 90-day aging simulation
│   │   ├── profile_store.py            # Profile management
│   │   ├── time_displacement.py        # Time manipulation
│   │   ├── ebpf_loader.py              # Linux eBPF loader
│   │   └── cortex.py                   # Core orchestrator
│   │
│   └── network/                        # Network modules
│       ├── ebpf_loader.py              # eBPF program loader
│       └── xdp_outbound.c              # XDP kernel code
│
├── modules/                            # SHARED MODULES
│   ├── commerce_injector.py            # Trust anchor injection
│   ├── biometric_mimicry.py            # Human behavior simulation
│   └── humanization.py                 # Additional humanization
│
├── camoufox/                           # CAMOUFOX BROWSER
│   └── pythonlib/
│       └── camoufox/
│           ├── sync_api.py
│           ├── async_api.py
│           └── ...
│
├── lucid_profile_data/                 # AGED PROFILES
│   ├── Titan_SoftwareEng_USA_001/
│   ├── Titan_GovClerk_UK_001/
│   ├── Phantom_Student_130/
│   └── ...
│
└── docs/                               # DOCUMENTATION
    ├── COMPLETE_DOCUMENTATION.md
    ├── QUICK_START.md
    ├── API_REFERENCE.md
    ├── PROFILE_GENERATION.md
    ├── ARCHITECTURE.md
    ├── TROUBLESHOOTING.md
    ├── IRON_RULES.md
    ├── MULTIPLATFORM_DEPLOYMENT.md
    └── PLATFORM_STRUCTURE.md           # This file
```

---

## Platform Comparison

| Aspect | Linux (TITAN) | Windows (STEALTH) |
|--------|---------------|-------------------|
| **Class** | TITAN (Sovereign) | STEALTH (Usermode) |
| **Masking Level** | Kernel (eBPF/XDP) | Usermode (DLL) |
| **Time Displacement** | libfaketime | RunAsDate/DLL |
| **Privileges** | Root/CAP_NET_ADMIN | Administrator |
| **Auto-Start** | systemd service | Scheduled task |
| **Fail-Safe** | iptables rules | Windows Defender |
| **GUI Theme** | Cyan/Green | Purple/Cyan |

---

## How to Launch

### Universal Launcher (Recommended)
```bash
# Detects OS and launches correct control panel
python launch.py
```

### Linux Direct
```bash
cd platforms/linux
chmod +x LAUNCH_INSTALLER.sh
./LAUNCH_INSTALLER.sh
```

### Windows Direct
```
Double-click: platforms\windows\LAUNCH_INSTALLER.bat
```

---

## Iron Rules by Platform

### Linux Iron Rules (LR-1 to LR-5)

| Rule | Requirement |
|------|-------------|
| LR-1 | Root or CAP_NET_ADMIN capability |
| LR-2 | libfaketime LD_PRELOAD mandatory |
| LR-3 | systemd service for persistence |
| LR-4 | iptables backup rules |
| LR-5 | Primary network interface binding |

### Windows Iron Rules (WR-1 to WR-5)

| Rule | Requirement |
|------|-------------|
| WR-1 | Administrator token mandatory |
| WR-2 | Windows Defender exclusion |
| WR-3 | Firewall rule for API port |
| WR-4 | DLL injection target process |
| WR-5 | Time spoofing method active |

---

## Platform-Specific Features

### Linux Only
- eBPF/XDP kernel-level packet manipulation
- libfaketime for system-wide time displacement
- systemd service integration
- CAP_NET_ADMIN capability support

### Windows Only
- DLL injection for process-level masking
- Windows Defender exclusion management
- Windows Firewall rule configuration
- RunAsDate integration

### Cross-Platform
- PyQt6 GUI control panel
- Camoufox browser integration
- Aged profile generation
- Backend API (FastAPI)

---

**Authority:** Dva.12  
**Last Updated:** February 2, 2026
