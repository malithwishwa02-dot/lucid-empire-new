# ⚙️ BACKEND ARCHITECTURE

**Core Modules & System Design**  
**Version:** 2.0.0  
**Status:** ✅ 100% COMPLETE

---

## System Overview

LUCID EMPIRE backend is a modular Python system built on FastAPI. The architecture separates concerns into:

1. **API Layer** - HTTP endpoints & request handling
2. **Core Modules** - Business logic & simulations
3. **Profile System** - Storage & management
4. **Network Layer** - Hardware & network masking
5. **Validation Layer** - Profile & proxy validation (NEW v2.0.0)

---

## API Layer

### server.py (Primary Entry Point - v2.0.0)

**File:** `backend/server.py` (378+ lines)

**Purpose:** FastAPI server with all endpoints including v2.0.0 additions

### lucid_api.py (Alternative API)

**File:** `backend/lucid_api.py` (572 lines)

**Purpose:** FastAPI server with core endpoints

**Key Components:**

**1. Initialization**
```python
app = FastAPI(
    title="Lucid Empire API",
    version="5.0.0-TITAN"
)

# CORS enabled for all origins (development)
app.add_middleware(CORSMiddleware, ...)

api = LucidAPI()  # Main API instance
```

**2. Request Models (Pydantic)**
```python
class BrowserLaunchRequest(BaseModel):
    profile_id: str = "Titan_SoftwareEng_USA_001"
    profile_name: Optional[str] = None

class ProfileResponse(BaseModel):
    status: str
    message: Optional[str] = None
    profile: Optional[Dict] = None
    profiles: Optional[List[Dict]] = None
```

**3. Main Endpoints**
```python
GET  /                          # Health check
GET  /api/profiles              # List profiles
GET  /api/aged-profiles         # List aged profiles (12 total)
GET  /api/profiles/{id}         # Get specific profile
POST /api/profiles              # Create profile
DELETE /api/profiles/{id}       # Delete profile
POST /api/browser/launch        # MAIN: Launch Firefox with profile
GET  /demo                      # Demo page
GET  /gui                       # Dashboard
```

**4. Browser Launch Logic**
```python
@app.post("/api/browser/launch")
async def launch_browser(request: BrowserLaunchRequest):
    # 1. Validate profile_id
    profile_id = request.profile_id
    
    # 2. Construct path
    profile_path = os.path.abspath(
        os.path.join("lucid_profile_data", profile_id)
    )
    
    # 3. Verify exists
    if not os.path.exists(profile_path):
        return {"status": "error", "message": "Not found"}
    
    # 4. Detect Firefox binary (cross-platform)
    firefox_bin = "firefox"
    if os.name == 'nt':  # Windows
        firefox_bin = "firefox.exe"
    
    # 5. Launch subprocess
    cmd = [firefox_bin, "-profile", profile_path, "url"]
    subprocess.Popen(cmd)
    
    # 6. Return success
    return {
        "status": "success",
        "message": f"Browser launched with aged profile: {profile_id}",
        "profile": {...}
    }
```

---

## Core Modules

### 1. Genesis Engine

**File:** `backend/core/genesis_engine.py` (385 lines)

**Purpose:** 90-day temporal aging simulation with history injection

**Key Classes:**

**GenesisEngine Class**
```python
class GenesisEngine:
    def __init__(self, persona="student", proxy_geo="New York"):
        self.persona = persona
        self.proxy_geo = proxy_geo
        self.location = LocationInfo(proxy_geo)
```

**Three-Phase Warming Cycle**

**Phase 1: INCEPTION (T-90d)**
- Trust anchors from major services
- URLs: Google, Wikipedia, CNN, BBC
- Purpose: Establish baseline legitimacy
```python
if phase == "INCEPTION":
    return ["https://www.google.com", "https://www.cnn.com", ...]
```

**Phase 2: WARMING (T-60d)**
- Persona-specific browsing
- Student: Discord, Scholar, Reddit, Canvas
- Worker: LinkedIn, Slack, Salesforce, Zoom
- Purpose: Build behavioral profile
```python
if self.persona == "student":
    return ["https://canvas.instructure.com", 
            "https://scholar.google.com", 
            "https://www.discord.com", ...]
```

**Phase 3: KILL_CHAIN (T-30d)**
- Commerce injection phase
- URLs: Apple, Amazon, Discord Billing
- Purpose: Inject payment signals
```python
if phase == "KILL_CHAIN":
    await inject_commerce_vector(page, platform="shopify")
```

**Key Methods**
```python
async execute_90_day_cycle()      # Main entry point
async run_phase(phase_name, days_ago)  # Run single phase
def get_persona_urls(phase)       # Get URLs for phase
def is_persona_active(time)       # Check activity window
def set_time_warp(days_ago)       # Configure libfaketime
```

**Time Integration**
```python
def initialize_time_warp(start_date_delta_days=90):
    initial_time = datetime.datetime.now() - datetime.timedelta(days=90)
    # Set /tmp/lucid_time_control file timestamp
    os.utime(TIME_CONTROL_FILE, (initial_time.timestamp(), ...))
```

**Persona-Activity Logic**
```python
def is_persona_active(self, current_time):
    if self.persona == "student":
        # Late start: 11 AM - 2 AM
        if is_sunday:
            return local_hour >= 11 or local_hour <= 3
        if is_friday:
            return (12 <= local_hour <= 17) or (22 <= local_hour <= 2)
        return local_hour >= 11 or local_hour <= 2
```

---

### 2. Commerce Injector

**File:** `backend/modules/commerce_injector.py` (84 lines)

**Purpose:** Inject trust anchor tokens into browser storage

**Key Functions**

**inject_trust_anchors(page)**
```python
async def inject_trust_anchors(page):
    # Double-Tap injection pattern:
    # 1. Write to localStorage
    # 2. Dispatch StorageEvent to wake fraud detection
    
    js_code = """
    const gamingHistory = [
        {
            "domain": "steampowered.com",
            "event": "purchase_success",
            "item": "Counter-Strike 2 Prime",
            "value": 14.99,
            "timestamp": Date.now() - (60 * 86400 * 1000)
        }
    ];
    localStorage.setItem('trust_score_gaming', '88');
    window.dispatchEvent(new StorageEvent('storage', { 
        key: 'trust_score_gaming' 
    }));
    """
    await page.evaluate(js_code)
```

**inject_commerce_vector(page, platform)**
```python
async def inject_commerce_vector(page, platform="shopify"):
    if platform == "shopify":
        # Shopify payment injection
        inject_payload = {
            "payment_method": "visa",
            "last_four": "9988",
            "verified": True,
            "trusted": True
        }
    elif platform == "stripe":
        # Stripe token injection
        inject_payload = {...}
    
    # Inject into page context
    await page.evaluate(f"""
        window._commerce_vault = {json.dumps(inject_payload)};
    """)
```

**Supported Platforms:**
- Shopify (payment methods)
- Stripe (card tokens)
- Custom (domain-specific)

---

### 3. Biometric Mimicry

**File:** `backend/modules/biometric_mimicry.py` (400+ lines)

**Purpose:** Human-like interaction patterns

**Key Methods**

**human_scroll()**
```python
async def human_scroll(self):
    # Variable speed scrolling with random pauses
    scroll_height = await self.page.evaluate("window.innerHeight")
    
    for _ in range(random.randint(3, 8)):
        distance = random.randint(200, 800)
        await self.page.evaluate(f"window.scrollBy(0, {distance})")
        
        # Random pause (reading)
        await asyncio.sleep(random.uniform(0.5, 3.0))
```

**human_mouse_move()**
```python
async def human_mouse_move(self, x, y):
    # Bézier curve trajectory
    current_x, current_y = await self.get_mouse_position()
    
    # Calculate Bézier points
    bezier_points = self.curve_mouse(current_x, current_y, x, y)
    
    # Move along curve
    for px, py in bezier_points:
        await self.page.mouse.move(px, py)
        await asyncio.sleep(random.uniform(0.01, 0.05))
```

**human_type()**
```python
async def human_type(self, text):
    # Keystroke latency: 80-150ms
    for char in text:
        await self.page.keyboard.down(char)
        await asyncio.sleep(random.uniform(0.08, 0.15))
        await self.page.keyboard.up(char)
```

**human_click()**
```python
async def human_click(self, selector):
    # Click duration: 80-120ms
    element = await self.page.query_selector(selector)
    
    await self.page.mouse.click(
        x=element.x,
        y=element.y,
        delay=random.uniform(0.08, 0.12)
    )
```

**curve_mouse()**
```python
def curve_mouse(self, start_x, start_y, end_x, end_y):
    # Bézier curve between two points
    # Creates natural-looking mouse movement
    points = []
    for t in range(0, 101):
        t_norm = t / 100.0
        # Cubic Bézier formula
        x = (1-t_norm)**3 * start_x + ...
        y = (1-t_norm)**3 * start_y + ...
        points.append((x, y))
    return points
```

**Audio Fingerprinting Noise**
```python
async def spoof_audio_context(self):
    # 0.0001% noise on audio buffer
    js = """
    const ac = new AudioContext();
    const original = ac.getChannelData;
    ac.getChannelData = function() {
        const data = original.call(this);
        // Add noise
        for (let i = 0; i < data.length; i++) {
            data[i] += (Math.random() - 0.5) * 0.00001;
        }
        return data;
    };
    """
    await self.page.evaluate(js)
```

---

### 4. Time Displacement

**File:** `backend/core/time_displacement.py`

**Purpose:** libfaketime integration for temporal control

**Key Features**

**Initialize Time Warp**
```python
def initialize_time_warp(start_date_delta_days=90):
    initial_time = datetime.datetime.now() - datetime.timedelta(days=90)
    
    # Write to control file (read by libfaketime)
    with open(TIME_CONTROL_FILE, 'w') as f:
        f.write(initial_time.isoformat())
    
    os.utime(TIME_CONTROL_FILE, (initial_time.timestamp(), ...))
```

**Update Time Warp**
```python
def update_time_warp(days_to_advance):
    current_fake = datetime.datetime.fromtimestamp(
        os.path.getmtime(TIME_CONTROL_FILE)
    )
    new_fake = current_fake + datetime.timedelta(days=days_to_advance)
    os.utime(TIME_CONTROL_FILE, (new_fake.timestamp(), ...))
```

**JavaScript Date Hijacking**
```python
async def hijack_js_date():
    js = """
    const originalDate = window.Date;
    window.Date = function() {
        // Return geographically-matched time
        // Boston time zone: UTC-5
        const offset = new Date().getTimezoneOffset();
        return new originalDate();
    };
    window.Date.now = originalDate.now;
    """
    await page.evaluate(js)
```

**Environment Variables**
```python
env = {
    "LD_PRELOAD": "/usr/lib/x86_64-linux-gnu/libfaketime.so.1",
    "FAKETIME": "-90d",  # 90 days in the past
    "FAKETIME_FOLLOW_FILE": "/tmp/lucid_time_control",
    "FAKETIME_DONT_RESET": "1",
    "FAKETIME_DONT_FAKE_MONOTONIC": "1"
}
```

**Disable During Manual Takeover**
```python
env["FAKETIME"] = ""  # Empty = disable time warp
# User now operates in real-time
```

---

### 5. Profile Store

**File:** `backend/core/profile_store.py` (104 lines)

**Purpose:** Profile factory, storage, and management

**Key Classes**

**PersonaFactory** (NEW)
```python
class PersonaFactory:
    def determine_persona(self, age, bin_tier, address=None):
        if age < 25 and bin_tier in ['PLATINUM', 'SIGNATURE']:
            if address and "university" in address.lower():
                return "COLLEGE_STUDENT"
        elif age > 40 and bin_tier == 'CENTURION':
            return "EXECUTIVE"
        return "STANDARD_CONSUMER"
    
    def get_warming_strategy(self, persona):
        if persona == "COLLEGE_STUDENT":
            return [
                {"phase": "T-90d", "action": "visit", "url": "https://bu.edu"},
                {"phase": "T-60d", "action": "visit", "url": "https://twitch.tv"},
                {"phase": "T-30d", "action": "visit", "url": "https://eneba.com"},
                {"phase": "T-30d", "action": "cart", "item": "Xbox Game Pass"},
                # ... 7 more actions
            ]
    
    def geo_correlation(self, proxy_city, billing_city):
        return "MATCH_PERFECT" if proxy_city == billing_city else "DISTANCE_WARNING"
```

**ProfileFactory**
```python
class ProfileFactory:
    def create(self, identifier):
        profile_hash = sha256(f"{identifier}{self.seed}".encode()).hexdigest()
        
        profile = {
            "id": identifier,
            "hardware": self._generate_hardware_fingerprint(profile_hash),
            "network": self._generate_network_fingerprint(profile_hash),
        }
        return profile
    
    def _generate_hardware_fingerprint(self, seed_hash):
        n1 = int(seed_hash[:8], 16)
        return {
            "cpu_cores": (n1 % 8) + 4,      # 4-12 cores
            "memory_gb": ((n2 % 64) // 8 + 1) * 8,  # 8-64GB
            "gpu": f"GPU_{n3 % 100}",
            "screen_res": f"{1920 + (n4 % 960)}x{1080 + (n4 % 540)}"
        }
```

**ProfileStore**
```python
class ProfileStore:
    def create_profile_directory(self, profile_id):
        profile_path = os.path.join(self.store_dir, profile_id)
        os.makedirs(profile_path, exist_ok=True)
        return profile_path
    
    def list_profiles(self):
        return [d for d in os.listdir(self.store_dir) 
                if os.path.isdir(os.path.join(self.store_dir, d))]
    
    def delete_profile(self, profile_id):
        profile_path = os.path.join(self.store_dir, profile_id)
        if os.path.exists(profile_path):
            shutil.rmtree(profile_path)
```

---

### 6. eBPF Network Shield

**File:** `backend/network/ebpf_loader.py`

**Purpose:** Linux kernel-level network masking

**Key Components**

**XDP Program Loading**
```python
def load_xdp_program(interface="eth0"):
    # Load eBPF/XDP program onto network interface
    # Rewrites outbound packet headers
    
    with open("xdp_outbound.c", 'r') as f:
        xdp_code = f.read()
    
    # Compile C code to eBPF bytecode
    bpf = BPF(text=xdp_code)
    
    # Attach to network interface
    bpf.attach_xdp(interface, fn_name="xdp_prog_func")
```

**TTL Spoofing (Windows = 128)**
```c
// xdp_outbound.c
int xdp_prog_func(struct xdp_md *ctx) {
    void *data_end = (void *)(long)ctx->data_end;
    void *data = (void *)(long)ctx->data;
    
    struct ethhdr *eth = data;
    struct iphdr *ip = (void *)(eth + 1);
    
    if ((void *)(ip + 1) > data_end)
        return XDP_PASS;
    
    // Windows TTL is 128
    ip->ttl = 128;
    
    return XDP_PASS;
}
```

**Window Size Manipulation**
```c
// Modify TCP window size to match Windows patterns
struct tcphdr *tcp = (void *)(ip + 1);
tcp->window = htons(65535);  // Windows standard
```

---

## Module Integration

### Data Flow Example: Browser Launch

```
1. Frontend (React)
   └─ POST /api/browser/launch
      └─ {profile_id: "Titan_SoftwareEng_USA_001"}

2. Backend API (lucid_api.py)
   ├─ Validate request
   ├─ Check profile exists
   └─ Launch subprocess

3. Firefox Process
   ├─ Read profile from lucid_profile_data/
   ├─ Load prefs.js (settings)
   ├─ Open places.sqlite (history)
   ├─ Load cookies.sqlite (sessions)
   ├─ Read commerce_vault.json (payment data)
   └─ Apply proxy_config.json (network)

4. Browser Navigation
   ├─ Navigate to http://127.0.0.1:8000/demo
   ├─ All profile data active
   └─ User has manual control

5. Frontend (React)
   └─ Receives success response
      └─ Console log: "Handing over control"
```

---

## Configuration & Customization

### Adding New Module

1. Create file in `backend/core/` or `backend/modules/`
2. Implement class with `__init__` and main methods
3. Import in `backend/core/__init__.py`
4. Register in `LucidAPI.setup_modules()`

### Adding New Endpoint

1. Define request model (Pydantic)
2. Create async function decorated with `@app.post()` or `@app.get()`
3. Add error handling
4. Return JSON response

---

## New v2.0.0 Modules

### Firefox Injector (`backend/firefox_injector.py`)
- **Lines:** 917
- **Purpose:** SQLite injection for cookies/history
- **Key Classes:** FirefoxInjector, CookieBuilder, HistoryGenerator

### Blacklist Validator (`backend/blacklist_validator.py`)
- **Lines:** 352
- **Purpose:** DNSBL + AbuseIPDB IP reputation checking
- **Key Functions:** check_blacklists(), query_dnsbl(), check_abuseipdb()

### Profile Manager (`backend/profile_manager.py`)
- **Lines:** 507
- **Purpose:** Archive to ZIP + secure 3-pass deletion
- **Key Functions:** archive_profile(), incinerate_profile()

### Warming Engine (`backend/warming_engine.py`)
- **Lines:** 469
- **Purpose:** Target site warming with Playwright + fallback
- **Key Classes:** WarmingEngine, TargetSite, WarmingSession

### Forensic Validator (`backend/validation/forensic_validator.py`)
- **Lines:** ~400
- **Purpose:** Profile validation with 5 pre-flight checks
- **Key Classes:** ForensicValidator, ValidationResult

---

## Package Structure (v2.0.0)

```
backend/
├── __init__.py         → exports core, modules, network, validation, LucidAPI, BackendManager
├── server.py           → Primary FastAPI server (15+ endpoints)
├── lucid_api.py        → Alternative API server
├── firefox_injector.py → SQLite injection (NEW)
├── blacklist_validator.py → IP reputation (NEW)
├── profile_manager.py  → Archive/incinerate (NEW)
├── warming_engine.py   → Target warming (NEW)
├── core/
│   └── __init__.py     → exports genesis_engine, time_displacement, etc.
├── modules/
│   └── __init__.py     → exports commerce_injector, biometric_mimicry, etc.
├── network/
│   └── __init__.py     → exports XDPLoader, eBPFLoader
└── validation/
    └── __init__.py     → exports ForensicValidator, ValidationTool (NEW)
```

### Modifying Warming Strategy

Edit `GenesisEngine.get_persona_urls()` to add/change URLs for each phase

---

**Last Updated:** February 2, 2026
**Authority:** Dva.12
