# 🎨 FRONTEND GUIDE

**React Component Architecture & State Management**  
**Version:** 2.0.0  
**Status:** ✅ 100% COMPLETE

---

## System Overview

LUCID EMPIRE frontend is a React 18.2 + Vite 5.0 application with Tailwind CSS styling. The architecture includes:

- **LucidTitanConsole** - Main dashboard component
- **PreFlightPanel** - 5-indicator validation panel (NEW v2.0.0)
- Profile selection & customization
- Proxy configuration
- Browser launch
- Real-time console logging

---

## Component Structure

### LucidTitanConsole.jsx

**File:** `dashboard/src/LucidTitanConsole.jsx` (730+ lines)

**Purpose:** Main dashboard component for all user interactions

### PreFlightPanel.jsx (NEW v2.0.0)

**File:** `frontend/src/components/PreFlightPanel.jsx` (~300 lines)

**Purpose:** Real-time 5-indicator validation status panel

**Indicators:**
1. PROXY_TUNNEL - Proxy connectivity check
2. GEO_MATCH - Location verification
3. TRUST_SCORE - Profile trust rating
4. TIME_SYNC - Temporal synchronization
5. BLACKLIST - IP reputation check

---

## State Variables

**Total: 11 reactive state variables**

### 1. Aged Profiles
```javascript
const [agedProfiles, setAgedProfiles] = useState([]);
```
- **Type:** Array of profile objects
- **Structure:** `{id, name, age, location, persona, bio, ...}`
- **Loaded By:** `fetchAgedProfiles()`
- **Used In:** Profile dropdown selector
- **Example:**
```json
{
  "id": "Titan_SoftwareEng_USA_001",
  "name": "Marcus Chen",
  "age": 28,
  "location": "San Francisco",
  "persona": "Software Engineer",
  "bio": "Frontend developer with 5 years experience..."
}
```

### 2. Selected Profile
```javascript
const [selectedProfile, setSelectedProfile] = useState(agedProfiles[0] || {});
```
- **Type:** Object (single profile)
- **Default:** First profile from agedProfiles
- **Changed By:** Profile dropdown onChange
- **Used In:** Display profile details, launch browser
- **Display Fields:**
  - Name, age, location, persona, BIN tier
  - Trust score, account age, spending pattern
  - Last login, device fingerprint, proxy location

### 3. Proxy URL
```javascript
const [proxyURL, setProxyURL] = useState("");
```
- **Type:** String
- **Format:** `http://username:password@ip:port` or `ip:port`
- **Validated By:** Smart INGEST regex
- **Used By:** Browser launch
- **Validation Pattern:**
```javascript
const proxyRegex = /^(?:[a-zA-Z0-9\-._~%!$&'()*+,;=:]*@)?(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)(?::\d{1,5})?$/;
```

### 4. Console Messages
```javascript
const [consoleMessages, setConsoleMessages] = useState([]);
```
- **Type:** Array of log objects
- **Structure:** `{timestamp, level, message, context}`
- **Max Messages:** 1000 (auto-trim old)
- **Display:** Bottom panel with scrolling
- **Levels:** `info`, `success`, `error`, `warning`, `debug`

### 5. Proxy Status
```javascript
const [proxyStatus, setProxyStatus] = useState("idle");
```
- **Type:** String (enum)
- **Values:** `"idle" | "validating" | "valid" | "invalid" | "connected"`
- **Determines:** Button colors and loading states
- **Used By:** Smart INGEST engine validation

### 6. Loading State
```javascript
const [isLoading, setIsLoading] = useState(false);
```
- **Type:** Boolean
- **Set By:** API calls (fetch profiles, launch browser)
- **Controls:** Spinner display, button disabled state
- **Duration:** Until response received

### 7. Launch Button Active
```javascript
const [isLaunchActive, setIsLaunchActive] = useState(false);
```
- **Type:** Boolean
- **Condition:** `profileSelected && proxyValid && !loading`
- **Determines:** Launch button clickability
- **Color States:**
  - `false` → `bg-gray-400` (disabled)
  - `true` → `bg-emerald-600 hover:bg-emerald-700` (active)

### 8. Manual Control Mode
```javascript
const [manualControl, setManualControl] = useState(false);
```
- **Type:** Boolean
- **Set By:** After successful browser launch
- **Display:** Large console message: "Manual takeover engaged"
- **Purpose:** Inform user they now control Firefox directly

### 9. Terminal Output
```javascript
const [terminalOutput, setTerminalOutput] = useState("");
```
- **Type:** String
- **Content:** Subprocess output from browser launch
- **Used By:** `executeCommandLocal()` (Windows/Linux)
- **Displayed In:** Advanced console section

### 10. Browser Launching
```javascript
const [isBrowserLaunching, setIsBrowserLaunching] = useState(false);
```
- **Type:** Boolean
- **Duration:** Until subprocess starts (usually < 1 second)
- **Shows:** Loading spinner during launch
- **Distinct From:** `isLoading` (different state for clarity)

### 11. API Response Details
```javascript
const [apiResponse, setApiResponse] = useState(null);
```
- **Type:** Object or null
- **Content:** Full response from `/api/browser/launch`
- **Used By:** Debug logging, status display
- **Structure:**
```json
{
  "status": "success",
  "message": "Browser launched with aged profile: Titan_SoftwareEng_USA_001",
  "profile": {...}
}
```

---

## Core Functions

**Total: 5 main functions + 12 helper utilities**

### 1. fetchAgedProfiles()

**Purpose:** Load all 12 aged profiles from API

**Code:**
```javascript
const fetchAgedProfiles = async () => {
  try {
    setIsLoading(true);
    addConsoleMessage("Fetching aged profiles...", "info");
    
    const response = await fetch("http://localhost:8000/api/aged-profiles", {
      method: "GET",
      headers: { "Content-Type": "application/json" }
    });
    
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    
    const data = await response.json();
    setAgedProfiles(data.profiles || []);
    
    addConsoleMessage(`Loaded ${data.profiles.length} aged profiles`, "success");
    
    if (data.profiles.length > 0) {
      setSelectedProfile(data.profiles[0]);
    }
  } catch (error) {
    addConsoleMessage(`Profile fetch failed: ${error.message}`, "error");
  } finally {
    setIsLoading(false);
  }
};
```

**Trigger:** `useEffect` on component mount

**Endpoint:** `GET /api/aged-profiles`

**Response Format:**
```json
{
  "status": "success",
  "profiles": [
    {"id": "Titan_SoftwareEng_USA_001", "name": "Marcus Chen", ...},
    {"id": "Hawk_ConsultEng_UK_009", "name": "James Wilson", ...}
  ]
}
```

### 2. smartINGEST()

**Purpose:** Intelligent validation of proxy URLs using regex patterns

**Code:**
```javascript
const smartINGEST = (proxyInput) => {
  // Pattern 1: Full proxy with auth
  const fullProxyRegex = /^(?:[a-zA-Z0-9\-._~%!$&'()*+,;=:]*@)?(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)(?::\d{1,5})?$/;
  
  // Pattern 2: IP range notation
  const ipRangeRegex = /^(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)\/\d{1,2}$/;
  
  // Pattern 3: Domain with port
  const domainRegex = /^(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}(?::\d{1,5})?$/;
  
  if (!proxyInput) {
    setProxyStatus("idle");
    return;
  }
  
  if (fullProxyRegex.test(proxyInput) || 
      ipRangeRegex.test(proxyInput) || 
      domainRegex.test(proxyInput)) {
    setProxyStatus("valid");
    setProxyURL(proxyInput);
    addConsoleMessage(`✓ Proxy validated: ${proxyInput}`, "success");
  } else {
    setProxyStatus("invalid");
    addConsoleMessage(`✗ Invalid proxy format`, "error");
  }
};
```

**Regex Patterns:**
- **Full Proxy:** `user:pass@ip:port`
- **IP Range:** `192.168.0.0/24`
- **Domain:** `proxy.server.com:8080`

**Output:** Sets `proxyStatus` and `proxyURL`

**Character Counter:**
```javascript
const proxyInputField = (
  <div>
    <textarea
      value={proxyURL}
      onChange={(e) => smartINGEST(e.target.value)}
      className="w-full h-20 px-4 py-3 bg-slate-800..."
    />
    <div className="text-right text-slate-500 text-xs mt-1">
      {proxyURL.length} / 256 characters
    </div>
  </div>
);
```

### 3. launchBrowser()

**Purpose:** Main function to launch Firefox with selected profile

**Code:**
```javascript
const launchBrowser = async () => {
  if (!selectedProfile.id) {
    addConsoleMessage("No profile selected", "error");
    return;
  }
  
  try {
    setIsLoading(true);
    setIsBrowserLaunching(true);
    
    addConsoleMessage(
      `[WARM-UP PHASE] Initializing profile: ${selectedProfile.name}`,
      "info"
    );
    
    const request = {
      profile_id: selectedProfile.id,
      profile_name: selectedProfile.name,
      proxy: proxyURL || null
    };
    
    const response = await fetch("http://localhost:8000/api/browser/launch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request)
    });
    
    const data = await response.json();
    setApiResponse(data);
    
    if (!response.ok) {
      addConsoleMessage(`Browser launch failed: ${data.message}`, "error");
      return;
    }
    
    addConsoleMessage(data.message, "success");
    
    addConsoleMessage(
      `[BURN PHASE] All systems initialized. Manual takeover engaged.`,
      "success"
    );
    
    setManualControl(true);
    
  } catch (error) {
    addConsoleMessage(`Launch error: ${error.message}`, "error");
  } finally {
    setIsLoading(false);
    setIsBrowserLaunching(false);
  }
};
```

**Request Format:**
```json
{
  "profile_id": "Titan_SoftwareEng_USA_001",
  "profile_name": "Marcus Chen",
  "proxy": "123.45.67.89:8080"
}
```

**Flow:**
1. Validate profile selected
2. Send POST to `/api/browser/launch`
3. Wait for response
4. Show success/error message
5. Enable manual control mode
6. Firefox opens automatically

### 4. addConsoleMessage()

**Purpose:** Add timestamped messages to console log

**Code:**
```javascript
const addConsoleMessage = (message, level = "info") => {
  const timestamp = new Date().toLocaleTimeString();
  
  const newMessage = {
    id: Date.now() + Math.random(),
    timestamp,
    level,
    message,
    formattedText: `[${timestamp}] [${level.toUpperCase()}] ${message}`
  };
  
  setConsoleMessages(prev => {
    const updated = [...prev, newMessage];
    // Keep last 1000 messages
    return updated.slice(-1000);
  });
};
```

**Levels & Colors:**
- `info` → Blue (`text-blue-400`)
- `success` → Green (`text-emerald-400`)
- `error` → Red (`text-red-400`)
- `warning` → Yellow (`text-yellow-400`)
- `debug` → Gray (`text-gray-400`)

**Console Display:**
```javascript
<div className="h-56 bg-slate-950 border border-slate-700 rounded p-3 overflow-y-auto font-mono text-sm">
  {consoleMessages.map(msg => (
    <div key={msg.id} className={`text-${getColorClass(msg.level)}`}>
      {msg.formattedText}
    </div>
  ))}
</div>
```

### 5. resetAllStates()

**Purpose:** Clear all states and return to idle

**Code:**
```javascript
const resetAllStates = () => {
  setSelectedProfile(agedProfiles[0] || {});
  setProxyURL("");
  setProxyStatus("idle");
  setConsoleMessages([]);
  setManualControl(false);
  setApiResponse(null);
  addConsoleMessage("System reset. Ready for new operation.", "info");
};
```

**Trigger:** "RESET" button

---

## Helper Functions

### isLaunchReady()
```javascript
const isLaunchReady = 
  selectedProfile.id && 
  proxyStatus === "valid" && 
  !isLoading;
```
Determines if launch button should be enabled.

### formatProfileDisplay()
```javascript
const formatProfileDisplay = (profile) => ({
  label: `${profile.name} (${profile.age}) - ${profile.location}`,
  value: profile.id
});
```
Formats profile for dropdown display.

### getColorClass()
```javascript
const getColorClass = (level) => {
  const colors = {
    "info": "blue-400",
    "success": "emerald-400",
    "error": "red-400",
    "warning": "yellow-400",
    "debug": "gray-400"
  };
  return colors[level] || colors.info;
};
```

---

## UI Layout

### Component Hierarchy

```
LucidTitanConsole
├── Header Section
│   ├── Title: "LUCID EMPIRE v5.0-TITAN"
│   └── Subtitle: "Profile Launch Dashboard"
│
├── Main Content (2 columns)
│   ├── Left Column (Control Panel)
│   │   ├── Profile Selector
│   │   │   └── Dropdown with 12 aged profiles
│   │   │
│   │   ├── Profile Details Card
│   │   │   ├── Name
│   │   │   ├── Age
│   │   │   ├── Location
│   │   │   ├── Persona
│   │   │   ├── Trust Score
│   │   │   ├── Account Age
│   │   │   ├── Spending Pattern
│   │   │   └── Device Fingerprint
│   │   │
│   │   ├── Proxy Configuration
│   │   │   ├── Input textarea
│   │   │   └── Character counter
│   │   │
│   │   └── Action Buttons
│   │       ├── WARM UP (Launch Browser)
│   │       └── RESET (Clear all)
│   │
│   └── Right Column (Status & Logs)
│       ├── System Status
│       │   ├── Phase indicator
│       │   └── Status badges
│       │
│       ├── Console Output
│       │   └── Scrollable log (h-56)
│       │
│       └── API Response (if needed)
│           └── Raw JSON display
│
└── Footer
    └── Version, auth, timestamp
```

### Tailwind Classes Used

**Spacing:**
- `px-4 py-3` - Standard padding
- `gap-3` - Space between sections
- `space-y-3` - Vertical spacing
- `space-y-2.5` - Tighter vertical spacing

**Colors:**
- `bg-slate-950` - Dark background
- `bg-slate-800` - Cards
- `border-slate-700` - Borders
- `text-slate-200` - Main text
- `text-emerald-600` - Success/active

**Sizing:**
- `w-full` - Full width
- `h-20` - Input textarea
- `h-56` - Console panel
- `h-14` - Buttons (small)

**States:**
- `hover:` - Mouse over
- `active:scale-95` - Click feedback
- `disabled:` - Disabled button
- `focus:outline-none` - Focus state

---

## Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                       User Interface                              │
│                   (LucidTitanConsole.jsx)                        │
└─────────────────────────────────────────────────────────────────┘
                              │
                    ┌─────────┼─────────┐
                    │         │         │
                    ▼         ▼         ▼
          ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
          │ fetchAged    │ │ smartINGEST  │ │ launchBrowser│
          │ Profiles()   │ │ ()           │ │ ()           │
          └──────────────┘ └──────────────┘ └──────────────┘
                    │         │                      │
                    └─────────┼──────────────────────┘
                              │
                    ┌─────────▼─────────┐
                    │   FastAPI Server  │
                    │   (Backend)       │
                    └─────────┬─────────┘
                              │
                    ┌─────────┴─────────┐
                    │                   │
                    ▼                   ▼
          ┌──────────────────┐ ┌──────────────────┐
          │ Profile Store    │ │ Browser Launch   │
          │ (12 aged         │ │ Process          │
          │ profiles)        │ │                  │
          └──────────────────┘ └──────────────────┘
                                        │
                                        ▼
                              ┌──────────────────┐
                              │   Firefox        │
                              │   (Camoufox)     │
                              │   with profile   │
                              └──────────────────┘
```

---

## Lifecycle & Hooks

### useEffect #1: Load Profiles on Mount
```javascript
useEffect(() => {
  fetchAgedProfiles();
}, []);
```
Runs once when component mounts.

### useEffect #2: Update Launch Button State
```javascript
useEffect(() => {
  const ready = selectedProfile?.id && proxyStatus === "valid" && !isLoading;
  setIsLaunchActive(ready);
}, [selectedProfile, proxyStatus, isLoading]);
```
Re-runs whenever these dependencies change.

### useEffect #3: Scroll Console to Bottom
```javascript
useEffect(() => {
  if (consoleRef.current) {
    consoleRef.current.scrollTop = consoleRef.current.scrollHeight;
  }
}, [consoleMessages]);
```
Auto-scrolls console when new messages added.

---

## Error Handling

### Profile Not Found
```javascript
if (!selectedProfile.id) {
  addConsoleMessage("No profile selected", "error");
  return;
}
```

### Proxy Invalid
```javascript
if (proxyStatus === "invalid") {
  addConsoleMessage("✗ Invalid proxy format", "error");
  return;
}
```

### API Connection Failed
```javascript
try {
  const response = await fetch(...);
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }
} catch (error) {
  addConsoleMessage(`Error: ${error.message}`, "error");
}
```

### Timeout Handling
```javascript
const timeoutId = setTimeout(() => {
  addConsoleMessage("Request timeout after 30s", "error");
  setIsLoading(false);
}, 30000);
```

---

**Last Updated:** February 2, 2026
**Authority:** Dva.12
