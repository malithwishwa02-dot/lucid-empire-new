# IRON RULES - LUCID EMPIRE Operational Protocols

**Authority:** Dva.12 | **Classification:** OPERATIONAL DIRECTIVES | **Status:** ✅ FULLY ENFORCED  
**Version:** 2.0.0 | **Last Updated:** February 4, 2026

---

## Overview

The Iron Rules are **immutable operational protocols** that define the minimum viable configuration for LUCID EMPIRE to function correctly on each platform. Violation of any Iron Rule results in graceful degradation or complete failure of masking.

---

## LINUX IRON RULES (TITAN Class)

### Rule LR-1: Root Access or CAP_NET_ADMIN Capability

**Statement:** The eBPF loader requires either root privileges or the `CAP_NET_ADMIN` Linux kernel capability.

**Implementation:**

**Option A: Root Execution (Preferred for Services)**
```bash
# Run directly as root
sudo /path/to/lucid_empire

# Or via systemd (systemd runs as root by default)
sudo systemctl start lucid-empire
```

**Option B: CAP_NET_ADMIN Capability**
```bash
# Grant capability to Python binary
sudo setcap cap_net_admin+ep /usr/bin/python3.9

# Verify
getcap /usr/bin/python3.9
# Output: /usr/bin/python3.9 = cap_net_admin+ep

# Then run as regular user
/usr/bin/python3.9 /path/to/main.py
```

**Consequence of Violation:**
- eBPF program load returns error: "Operation not permitted"
- No masking active
- XDP attach point creation fails
- System functions normally but unmasked

**Verification:**
```bash
# Check current user capabilities
echo "Current user: $(whoami)"
echo "Current capabilities: $(getcap /usr/bin/python3.9 2>/dev/null || echo 'None')"

# If root: ✓ Compliant
# If cap_net_admin+ep present: ✓ Compliant
# If neither: ✗ Violation - install will fail
```

---

### Rule LR-2: LD_PRELOAD libfaketime Mandatory

**Statement:** All Python processes must have `LD_PRELOAD` environment variable pointing to libfaketime.so.1 for temporal displacement.

**Implementation:**

**In systemd Service:**
```ini
# /etc/systemd/system/lucid-empire.service
[Service]
Type=simple
ExecStart=/usr/bin/env LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libfaketime.so.1 \
  FAKETIME_OFFSET=-90d /opt/lucid-empire/venv/bin/python main.py
User=lucid-agent
Group=lucid-agent
Restart=on-failure
RestartSec=10
```

**In Interactive Shell:**
```bash
export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libfaketime.so.1
export FAKETIME_OFFSET=-90d  # 90 days in the past
export LIBFAKETIME_NO_CACHE=1
export LIBFAKETIME_SKIP_CLOCK_NANOSLEEP=1

python3 main.py
```

**Verification:**
```bash
# Check if LD_PRELOAD is active
ps aux | grep main.py | grep LD_PRELOAD

# Check reported time
date  # Should be ~90 days in the past

# Query via API
curl http://localhost:8000/api/system-time
# Expected: {"current_time": "2024-XX-XX", "offset": "-90d"}
```

**Consequence of Violation:**
- System time reported as real (current date)
- Application fingerprinting detects real system time
- Temporal displacement fails
- Detection risk increases significantly

**Critical Note:**
libfaketime works at the **library call level** (gettimeofday, time, clock_gettime). If these syscalls are bypassed, time displacement fails.

---

### Rule LR-3: systemd Service Mandatory for Persistence

**Statement:** The masking daemon must be installed as a systemd service to ensure automatic startup and recovery.

**Implementation:**

**Service Installation:**
```bash
# Create service file
sudo tee /etc/systemd/system/lucid-empire.service > /dev/null << EOF
[Unit]
Description=LUCID EMPIRE - Sovereignty Masking Platform
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=lucid-agent
Group=lucid-agent
WorkingDirectory=/opt/lucid-empire
ExecStart=/usr/bin/env LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libfaketime.so.1 \
  /opt/lucid-empire/venv/bin/python main.py
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# Enable service
sudo systemctl daemon-reload
sudo systemctl enable lucid-empire
sudo systemctl start lucid-empire
```

**Service Management:**
```bash
# Check status
sudo systemctl status lucid-empire

# Follow logs
sudo journalctl -u lucid-empire -f

# Restart service
sudo systemctl restart lucid-empire

# Stop service
sudo systemctl stop lucid-empire
```

**Consequence of Violation:**
- Manual execution required after each reboot
- No automatic recovery if process crashes
- Masking disabled during downtime
- Service restarts not guaranteed

**Verification:**
```bash
# Check if service is enabled
sudo systemctl is-enabled lucid-empire
# Expected: enabled

# Check if service is active
sudo systemctl is-active lucid-empire
# Expected: active

# Check startup on boot
sudo systemctl list-units --all | grep lucid-empire
```

---

### Rule LR-4: iptables Backup Rules = Fail-Safe

**Statement:** iptables NAT rules must be configured as a backup fail-safe in case eBPF program unloads unexpectedly.

**Implementation:**

**Backup Rule Setup:**
```bash
# Create backup chain
sudo iptables -t nat -N LUCID-BACKUP 2>/dev/null

# Add backup rules (redirect to local proxy)
sudo iptables -t nat -A LUCID-BACKUP -p tcp --dport 443 -j REDIRECT --to-port 8443
sudo iptables -t nat -A LUCID-BACKUP -p tcp --dport 80 -j REDIRECT --to-port 8080

# Insert backup rule to OUTPUT chain
sudo iptables -t nat -I OUTPUT 1 -j LUCID-BACKUP

# Save rules
sudo iptables-save > /etc/iptables/rules.v4
```

**Verification:**
```bash
# List backup chain
sudo iptables -t nat -L LUCID-BACKUP -n

# Verify backup rule in OUTPUT
sudo iptables -t nat -L OUTPUT -n | grep LUCID-BACKUP
```

**Consequence of Violation:**
- If eBPF program unloads, traffic goes unmasked
- No fallback masking mechanism
- Exposure window until service restarts
- Detection risk if unload occurs during operations

**When Rules are Used:**
1. eBPF program unloads (kernel error, module reload)
2. Network interface down/up cycle
3. System maintenance without service stop
4. Emergency failover scenario

---

### Rule LR-5: Primary Network Interface Binding

**Statement:** The XDP program must be attached to the primary network interface specified in configuration.

**Implementation:**

**Configuration File:**
```json
{
  "masking": {
    "platform": "linux",
    "ebpf": {
      "primary_interface": "eth0",
      "backup_interfaces": ["eth1", "wlan0"],
      "xdp_program": "/opt/lucid-empire/xdp_outbound.o"
    },
    "libfaketime": {
      "offset_days": -90,
      "cache_disabled": true
    }
  }
}
```

**Interface Detection:**
```bash
# List available interfaces
ip link show

# Detect primary interface (connected, has IP)
ip route | grep '^default' | awk '{print $5}'

# Test connectivity
ping -I eth0 8.8.8.8
```

**Verification:**
```bash
# Check XDP attachment to interface
sudo ip link show eth0 | grep xdp

# Expected output:
# xdp_outbound attached to eth0

# Check which XDP programs are loaded
sudo bpftool prog list | grep xdp_outbound
```

**Consequence of Violation:**
- XDP program fails to attach
- System networking unaffected but masking inactive
- Error logged: "Interface not found" or "Interface has no IP"
- Manual configuration required

---

## WINDOWS IRON RULES (STEALTH Class)

### Rule WR-1: Administrator Token Mandatory

**Statement:** DLL injection requires an elevated administrator access token (UAC level).

**Implementation:**

**Automatic UAC Elevation:**
```powershell
# Check if already running as admin
$IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $IsAdmin) {
    # Re-run as administrator
    Start-Process -FilePath powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}
```

**Manual UAC Elevation:**
```
1. Right-click on PowerShell → "Run as Administrator"
2. Click "Yes" on UAC prompt
3. Execute launcher script
```

**Verification:**
```powershell
# Check current token
[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent() | `
  Select-Object -ExpandProperty Identity

# Verify admin status
([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
# Expected: True
```

**Consequence of Violation:**
- DLL injection calls fail: "Access Denied"
- CreateRemoteThread fails with error code 5
- Process doesn't receive TimeShift.dll injection
- Time/TTL spoofing not active
- Detection possible

---

### Rule WR-2: Windows Defender Exclusion Mandatory

**Statement:** Installation and runtime directories must be added to Windows Defender exclusion list to prevent real-time scanning from blocking DLL injection.

**Implementation:**

**PowerShell Defender Configuration:**
```powershell
# Add exclusion paths
$ExclusionPaths = @(
    "C:\Program Files\LUCID EMPIRE",
    "$env:APPDATA\LUCID EMPIRE",
    "$env:TEMP\lucid-*"
)

foreach ($path in $ExclusionPaths) {
    Add-MpPreference -ExclusionPath $path -Force
    Write-Host "Added exclusion: $path"
}

# Verify exclusions
Get-MpPreference | Select-Object -ExpandProperty ExclusionPath
```

**Manual Defender Configuration:**
```
1. Windows Security → Virus & threat protection
2. → Manage settings
3. → Add exclusions
4. Add:
   - C:\Program Files\LUCID EMPIRE
   - %APPDATA%\LUCID EMPIRE
   - %TEMP%\lucid-*
```

**Consequence of Violation:**
- Real-time protection detects DLL injection
- Windows Defender quarantines injected process
- Process terminates immediately
- Firefox (or target app) closes unexpectedly
- Re-injection required on next execution

**Critical Note:**
Windows Defender can also be temporarily disabled for DLL injection:
```powershell
# Disable real-time protection (NOT recommended)
Set-MpPreference -DisableRealtimeMonitoring $true

# Re-enable after injection
Set-MpPreference -DisableRealtimeMonitoring $false
```

---

### Rule WR-3: Firewall Rule for API Port

**Statement:** Windows Firewall must allow inbound traffic to TCP port 8000 for API endpoint access.

**Implementation:**

**PowerShell Firewall Configuration:**
```powershell
# Create firewall rule
New-NetFirewallRule -DisplayName "LUCID EMPIRE API" `
  -Direction Inbound `
  -Action Allow `
  -Protocol TCP `
  -LocalPort 8000 `
  -Program "C:\Program Files\LUCID EMPIRE\python\python.exe" `
  -Profile @("Private", "Public") `
  -Enabled $true

# Verify rule
Get-NetFirewallRule -DisplayName "LUCID EMPIRE API" | Format-List
```

**Manual Firewall Configuration:**
```
1. Windows Defender Firewall → Advanced settings
2. → Inbound Rules → New Rule
3. Port → TCP → 8000
4. Allow the connection
5. Profile: Domain, Private, Public
6. Name: LUCID EMPIRE API
```

**Verification:**
```powershell
# Test port connectivity
Test-NetConnection -ComputerName localhost -Port 8000

# Check firewall rule status
Get-NetFirewallRule -DisplayName "LUCID EMPIRE API" | Select-Object Enabled

# Verify port is listening
netstat -ano | findstr :8000
```

**Consequence of Violation:**
- API endpoint unreachable
- Cannot query masking status
- Remote access to API blocked
- Operations unaffected (masking still active locally)

---

### Rule WR-4: DLL Injection Target Process Must Exist

**Statement:** TimeShift.dll injection requires an active target process (Firefox, Chrome, etc.) running at the moment of injection.

**Implementation:**

**Process Enumeration:**
```powershell
# List all processes
Get-Process | Where-Object {$_.ProcessName -match "firefox|chrome|msedge"}

# Check specific process
Get-Process -Name firefox -ErrorAction SilentlyContinue
```

**Injection Logic:**
```python
# In windivert_loader.py
def inject_ttl_dll(target_process="firefox"):
    """
    Inject TimeShift.dll into target process
    """
    # Find process by name
    pid = find_process_by_name(target_process)
    
    if pid is None:
        logger.error(f"Target process '{target_process}' not found")
        return False
    
    # Perform injection
    return inject_dll(pid, "TimeShift.dll")
```

**Verification:**
```powershell
# Check if Firefox is running
Get-Process -Name firefox

# Monitor for DLL injection
tasklist /v | findstr firefox
```

**Consequence of Violation:**
- Injection fails silently
- Target process not found error logged
- Process continues without time/TTL spoofing
- Manual process launch required

**Note:** If process terminates during operation, injection must be repeated.

---

### Rule WR-5: Time Spoofing Method Active

**Statement:** Either RunAsDate.exe or TimeShift.dll must be active for system time spoofing.

**Implementation:**

**Option A: RunAsDate Wrapper**
```powershell
# Launch application with RunAsDate
& "C:\Program Files\LUCID EMPIRE\tools\RunAsDate.exe" `
  -d "01/01/2023" `
  "C:\Program Files\Firefox\firefox.exe"
```

**Option B: TimeShift.dll Injection**
```python
# Automatic via windivert_loader.py
loader = get_windows_loader()
loader.inject_date_into_process(pid, date="2023-01-01")
```

**Configuration:**
```json
{
  "masking": {
    "windows": {
      "time_spoofing": {
        "method": "dll_injection",  // or "runasdate"
        "target_date": "2023-01-01",
        "target_processes": ["firefox.exe", "chrome.exe"]
      }
    }
  }
}
```

**Verification:**
```powershell
# Check if RunAsDate is active
Get-Process | Where-Object {$_.ProcessName -match "RunAsDate"}

# Check system time in target process
# (via injected DLL that intercepts time APIs)
```

**Consequence of Violation:**
- System time reported as real (current date)
- Website fingerprinting scripts detect real time
- Application logs show real timestamp
- Detection risk increases

---

## Cross-Platform Rules

### Rule CR-1: API Endpoint Must Respond

**Statement:** The masking core must expose an HTTP API endpoint on localhost:8000 that reports masking status.

**Linux Implementation:**
```bash
# Test endpoint
curl http://localhost:8000/api/masking-status

# Expected response:
# {
#   "platform": "linux",
#   "class": "titan",
#   "status": "active",
#   "loader": "ebpf",
#   "xdp_attached": true,
#   "libfaketime_active": true
# }
```

**Windows Implementation:**
```powershell
Invoke-WebRequest -Uri "http://localhost:8000/api/masking-status" | `
  Select-Object -ExpandProperty Content | `
  ConvertFrom-Json

# Expected response:
# {
#   "platform": "windows",
#   "class": "stealth",
#   "status": "active",
#   "loader": "dllinjection",
#   "defender_exclusion": true,
#   "firewall_rule": true
# }
```

---

### Rule CR-2: Configuration File Required

**Statement:** A valid configuration file must exist and be readable by the masking process.

**Location:**
- **Linux:** `/etc/lucid-empire/config.json`
- **Windows:** `C:\Program Files\LUCID EMPIRE\config\config.json`

**Minimum Required Fields:**
```json
{
  "api": {
    "host": "0.0.0.0",
    "port": 8000
  },
  "masking": {
    "enabled": true,
    "platform": "linux",  // or "windows"
    "logging": {
      "level": "INFO",
      "file": "/var/log/lucid-empire/main.log"
    }
  }
}
```

---

### Rule CR-3: Logging and Audit Trail

**Statement:** All masking operations must be logged for troubleshooting and audit purposes.

**Linux Logging:**
```bash
# Via systemd journal
sudo journalctl -u lucid-empire -f

# Via file logging
tail -f /var/log/lucid-empire/main.log
```

**Windows Logging:**
```powershell
# Via event viewer
Get-EventLog -LogName Application | Where-Object {$_.Source -match "LUCID"}

# Via file logging
Get-Content "C:\Program Files\LUCID EMPIRE\logs\main.log" -Tail 50
```

---

## Rule Violation Summary

| Rule | Platform | Violation Impact | Recovery |
|------|----------|------------------|----------|
| LR-1 | Linux | eBPF load fails | Grant CAP_NET_ADMIN |
| LR-2 | Linux | Time not spoofed | Set LD_PRELOAD env var |
| LR-3 | Linux | No auto-start | Install systemd service |
| LR-4 | Linux | No fail-safe | Configure iptables rules |
| LR-5 | Linux | XDP attach fails | Configure interface |
| WR-1 | Windows | DLL injection fails | Run as Administrator |
| WR-2 | Windows | Defender blocks | Add exclusion path |
| WR-3 | Windows | API unreachable | Create firewall rule |
| WR-4 | Windows | Injection fails | Launch target process |
| WR-5 | Windows | Time not spoofed | Enable time spoofing DLL |
| CR-1 | Both | Cannot monitor | Start API endpoint |
| CR-2 | Both | Config missing | Create config.json |
| CR-3 | Both | No audit trail | Enable logging |

---

**Authority:** Dva.12  
**Classification:** OPERATIONAL DIRECTIVES - MANDATORY COMPLIANCE  
**Last Updated:** 2024
