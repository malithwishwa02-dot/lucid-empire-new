# 🔌 API DOCUMENTATION

**Complete API Endpoint Reference**  
**Version:** 2.0.0

---

## API Overview

The LUCID EMPIRE API is built on FastAPI with JSON request/response format.

**Base URL:** `http://localhost:8000`

**Content-Type:** `application/json`

**Total Endpoints:** 15+ (including 7 new v2.0.0 endpoints)

---

## New in v2.0.0

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/preflight` | POST | Run 5 pre-flight checks |
| `/api/blacklist-check` | POST | Check IP against blacklists |
| `/api/archive` | POST | Archive profile to ZIP |
| `/api/incinerate` | POST | Secure delete profile |
| `/api/archives` | GET | List archived profiles |
| `/api/warm` | POST | Warm target site |
| `/api/inject` | POST | Inject cookies/history |

---

## Health & Status Endpoints

### GET /

**Description:** Health check / API status

**Response:** 200 OK
```json
{
  "status": "operational",
  "message": "Lucid Empire API - Advanced Behavioral Simulation",
  "docs": "/docs"
}
```

---

## Profile Endpoints

### GET /api/profiles

**Description:** List all profiles (including non-aged)

**Response:** 200 OK
```json
{
  "status": "success",
  "profiles": [
    {
      "id": "Titan_SoftwareEng_USA_001",
      "name": "Titan_SoftwareEng_USA_001",
      "type": "aged",
      "age_days": 90
    }
  ]
}
```

---

### GET /api/aged-profiles

**Description:** List only pre-aged profiles ready for browser launch

**Response:** 200 OK
```json
{
  "status": "success",
  "total": 12,
  "profiles": [
    {
      "name": "Titan_SoftwareEng_USA_001",
      "path": "/absolute/path/to/lucid_profile_data/Titan_SoftwareEng_USA_001",
      "age_days": 90,
      "has_history": true,
      "has_cookies": true,
      "has_commerce": true,
      "has_proxy": true
    },
    {
      "name": "Titan_GovClerk_UK_001",
      "path": "/absolute/path/to/lucid_profile_data/Titan_GovClerk_UK_001",
      "age_days": 90,
      "has_history": true,
      "has_cookies": true,
      "has_commerce": true,
      "has_proxy": true
    }
    // ... 10 more profiles
  ]
}
```

**Profiles Returned:**
1. Titan_SoftwareEng_USA_001
2. Titan_GovClerk_UK_001
3. Phantom_Student_130
4. sim_airbnb_traveler
5. sim_amazon_considered_purchase
6. sim_booking_affiliate
7. sim_dundle_gift_cards
8. sim_eneba_crypto
9. Titan_Doctor_NY_001
10. Titan_Research_Student_USA
11. (2 additional research profiles)

---

### GET /api/profiles/{profile_id}

**Description:** Get specific profile details

**Parameters:**
- `profile_id` (path): Profile identifier

**Example Request:**
```
GET /api/profiles/Titan_SoftwareEng_USA_001
```

**Response:** 200 OK
```json
{
  "status": "success",
  "profile": {
    "id": "Titan_SoftwareEng_USA_001",
    "path": "/path/to/profile",
    "created_at": 1643212800,
    "has_history": true,
    "has_cookies": true,
    "has_commerce": true,
    "has_proxy": true,
    "age_days": 90
  }
}
```

**Response:** 404 Not Found
```json
{
  "status": "error",
  "message": "Profile not found"
}
```

---

### POST /api/profiles

**Description:** Create new profile (rarely used)

**Request Body:**
```json
{
  "name": "custom_profile",
  "template": "Titan_SoftwareEng_USA_001",
  "copy_data": true
}
```

**Response:** 200 OK
```json
{
  "status": "success",
  "profile": {
    "id": "custom_profile_1234",
    "path": "/path/to/profile",
    "created_at": 1643212800
  }
}
```

---

### DELETE /api/profiles/{profile_id}

**Description:** Delete profile permanently

**Parameters:**
- `profile_id` (path): Profile to delete

**Example Request:**
```
DELETE /api/profiles/custom_profile_1234
```

**Response:** 200 OK
```json
{
  "status": "success",
  "message": "Profile deleted"
}
```

---

## Browser Launch Endpoint

### POST /api/browser/launch

**Description:** Launch Firefox with aged profile - THE MAIN OPERATION ENDPOINT

**Request Body:**
```json
{
  "profile_id": "Titan_SoftwareEng_USA_001",
  "profile_name": "Titan_SoftwareEng_USA_001"
}
```

**Request Schema (Pydantic Model):**
```python
class BrowserLaunchRequest(BaseModel):
    profile_id: str = "Titan_SoftwareEng_USA_001"
    profile_name: Optional[str] = None
```

**Response:** 200 OK (Success)
```json
{
  "status": "success",
  "message": "Browser launched with aged profile: Titan_SoftwareEng_USA_001",
  "url": "http://127.0.0.1:8000/demo",
  "profile": {
    "id": "Titan_SoftwareEng_USA_001",
    "path": "/absolute/path/to/lucid_profile_data/Titan_SoftwareEng_USA_001",
    "age_days": 90
  }
}
```

**Response:** 404 Not Found (Profile Missing)
```json
{
  "status": "error",
  "message": "Profile not found: InvalidProfileName"
}
```

**Response:** 500 Internal Server Error (Firefox Launch Failed)
```json
{
  "status": "error",
  "message": "Failed to launch Firefox: [error details]"
}
```

**Backend Process:**
1. Validates `profile_id` parameter
2. Constructs full profile path: `lucid_profile_data/{profile_id}`
3. Checks if profile directory exists
4. Determines Firefox binary (cross-platform)
5. Launches: `firefox -profile {profile_path} http://127.0.0.1:8000/demo`
6. Returns success response
7. Browser opens with profile loaded

---

## Pre-Flight & Validation Endpoints (NEW v2.0.0)

### POST /api/preflight

**Description:** Run all 5 pre-flight checks before browser launch

**Request Body:**
```json
{
  "proxy_string": "user:pass@1.2.3.4:8080",
  "profile_path": "/path/to/profile"
}
```

**Response:** 200 OK
```json
{
  "status": "success",
  "checks": {
    "PROXY_TUNNEL": { "status": "success", "message": "Connected in 45ms" },
    "GEO_MATCH": { "status": "success", "message": "Location verified" },
    "TRUST_SCORE": { "status": "success", "message": "Score: 85/100" },
    "TIME_SYNC": { "status": "success", "message": "Synchronized" },
    "BLACKLIST": { "status": "success", "message": "Clean IP" }
  },
  "all_passed": true
}
```

---

### POST /api/blacklist-check

**Description:** Check IP reputation against fraud databases

**Request Body:**
```json
{
  "ip_address": "1.2.3.4"
}
```

**Response:** 200 OK
```json
{
  "status": "success",
  "ip": "1.2.3.4",
  "risk_score": 15,
  "is_blacklisted": false,
  "checks": {
    "dnsbl": { "listed": false, "sources": [] },
    "abuseipdb": { "score": 10 },
    "datacenter": false
  }
}
```

---

## Profile Management Endpoints (NEW v2.0.0)

### POST /api/archive

**Description:** Archive a profile to ZIP file

**Request Body:**
```json
{
  "profile_path": "/path/to/profile"
}
```

**Response:** 200 OK
```json
{
  "status": "success",
  "archive_path": "/archives/profile_2026-02-04.zip",
  "size_bytes": 1234567
}
```

---

### POST /api/incinerate

**Description:** Securely delete a profile (3-pass overwrite)

**Request Body:**
```json
{
  "profile_path": "/path/to/profile"
}
```

**Response:** 200 OK
```json
{
  "status": "success",
  "message": "Profile securely deleted",
  "files_removed": 42
}
```

---

### GET /api/archives

**Description:** List all archived profiles

**Response:** 200 OK
```json
{
  "status": "success",
  "archives": [
    {
      "filename": "profile_2026-02-04.zip",
      "size_bytes": 1234567,
      "created_at": "2026-02-04T12:00:00Z"
    }
  ]
}
```

---

## Warming & Injection Endpoints (NEW v2.0.0)

### POST /api/warm

**Description:** Warm target site with browsing history

**Request Body:**
```json
{
  "target_url": "https://www.amazon.com",
  "profile_path": "/path/to/profile",
  "use_playwright": false
}
```

**Response:** 200 OK
```json
{
  "status": "success",
  "visits_generated": 15,
  "history_entries": 45,
  "cart_abandonments": 3
}
```

---

### POST /api/inject

**Description:** Inject cookies/history into Firefox profile

**Request Body:**
```json
{
  "profile_path": "/path/to/profile",
  "aging_days": 60,
  "fullz": {
    "first_name": "John",
    "last_name": "Doe",
    "email": "john@example.com"
  },
  "target_site": "https://www.amazon.com"
}
```

**Response:** 200 OK
```json
{
  "status": "success",
  "injected": {
    "cookies": 312,
    "history_entries": 847,
    "form_autofill": 15
  }
}
```

---

## Demo & GUI Endpoints

### GET /demo

**Description:** Demo page that opens after browser launch

**Response:** 200 OK (HTML)
```html
<!DOCTYPE html>
<html>
<head>
    <title>Lucid Empire - Live Operational Console</title>
    ...
</head>
<body>
    <div class="container">
        <h1>[LUCID EMPIRE] LIVE OPERATIONAL CONSOLE</h1>
        ...
    </div>
</body>
</html>
```

**Features:**
- Status display
- Profile information
- Active operational session indicator
- Return to console button
- View system logs button

---

### GET /gui

**Description:** Dashboard GUI (alternative to React frontend)

**Response:** 200 OK (HTML)
```html
<!DOCTYPE html>
<html>
<head>
    <title>Lucid Empire - Control Panel</title>
    ...
</head>
<body>
    <div class="header">LUCID EMPIRE</div>
    ...
</body>
</html>
```

---

## API Usage Examples

### Example 1: Check System Health

```bash
curl http://localhost:8000/
```

### Example 2: List Available Profiles

```bash
curl http://localhost:8000/api/aged-profiles
```

### Example 3: Launch Browser with Profile

```bash
curl -X POST http://localhost:8000/api/browser/launch \
  -H "Content-Type: application/json" \
  -d '{
    "profile_id": "Titan_SoftwareEng_USA_001",
    "profile_name": "Titan_SoftwareEng_USA_001"
  }'
```

### Example 4: JavaScript (Frontend)

```javascript
// Fetch available profiles
const response = await fetch('http://localhost:8000/api/aged-profiles');
const data = await response.json();
console.log(data.profiles);

// Launch browser
const launchResponse = await fetch(
  'http://localhost:8000/api/browser/launch',
  {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      profile_id: 'Titan_SoftwareEng_USA_001',
      profile_name: 'Titan_SoftwareEng_USA_001'
    })
  }
);
const launchData = await launchResponse.json();
```

### Example 5: Python Requests

```python
import requests

# Health check
response = requests.get('http://localhost:8000/')
print(response.json())

# Get profiles
profiles_response = requests.get('http://localhost:8000/api/aged-profiles')
profiles = profiles_response.json()['profiles']

# Launch browser
launch_response = requests.post(
    'http://localhost:8000/api/browser/launch',
    json={
        'profile_id': 'Titan_SoftwareEng_USA_001',
        'profile_name': 'Titan_SoftwareEng_USA_001'
    }
)
print(launch_response.json())
```

---

## Error Handling

### HTTP Status Codes

| Code | Meaning | Example |
|------|---------|---------|
| 200 | Success | Profile launched successfully |
| 404 | Not Found | Profile doesn't exist |
| 500 | Server Error | Firefox launch failed |

### Error Response Format

All errors follow this format:
```json
{
  "status": "error",
  "message": "Descriptive error message"
}
```

### Common Errors

**Profile Not Found**
```json
{
  "status": "error",
  "message": "Profile not found: NonExistentProfile"
}
```

**Firefox Not Available**
```json
{
  "status": "error",
  "message": "Failed to launch Firefox: [Errno 2] No such file or directory: 'firefox'"
}
```

**Invalid Request**
```json
{
  "status": "error",
  "message": "Unexpected error: Invalid request body"
}
```

---

## CORS Configuration

Current CORS settings allow all origins (development):
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

**For Production:** Restrict to specific origins:
```python
allow_origins=[
    "https://yourdomain.com",
    "https://www.yourdomain.com"
]
```

---

## API Documentation Auto-Generated Endpoints

FastAPI automatically generates interactive documentation:

- **Swagger UI:** http://localhost:8000/docs
- **ReDoc:** http://localhost:8000/redoc

Use these for:
- Interactive endpoint testing
- Request/response schema visualization
- Parameter documentation

---

## Rate Limiting

Currently: **No rate limiting** (open access)

For production, consider:
```python
from fastapi_limiter import FastAPILimiter
from fastapi_limiter.util import get_remote_address

# 100 requests per minute per IP
@limiter.limit("100/minute")
async def limited_endpoint():
    pass
```

---

## Authentication

Currently: **No authentication** (open access)

For production, implement:
```python
from fastapi.security import HTTPBearer, HTTPAuthCredentials

security = HTTPBearer()

@app.post("/api/browser/launch")
async def launch_browser(
    request: BrowserLaunchRequest,
    credentials: HTTPAuthCredentials = Depends(security)
):
    # Verify token
    if not verify_token(credentials.credentials):
        raise HTTPException(status_code=403)
    # ... launch browser
```

---

## Webhooks & Callbacks

Currently: **Not implemented**

Could be added for:
- Profile launch completion
- Browser shutdown notification
- Error alerts
- Operational milestones

---

**Last Updated:** February 4, 2026  
**Version:** 2.0.0  
**Authority:** Dva.12
