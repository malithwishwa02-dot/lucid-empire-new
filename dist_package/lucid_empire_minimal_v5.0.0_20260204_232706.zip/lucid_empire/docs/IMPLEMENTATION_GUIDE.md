# 🚀 LUCID EMPIRE v5 - Simplified Implementation Guide

**Date:** February 4, 2026  
**Authority:** Dva.12  
**Version:** 5.0.0-TITAN (Backend v2.0.0)  
**Status:** ✅ Implementation Complete - All Gaps Closed

---

## Executive Summary

This guide consolidates the simplified deployment architecture for LUCID EMPIRE v5. The previous operational readiness plan outlined dual-architecture deployment (TITAN for Linux, STEALTH for Windows). This document provides the **implementation specifications** for deploying both on unified codebase.

### What Was Simplified

| Issue | Solution | Files Modified |
|-------|----------|-----------------|
| Missing Windows launchers | Created `start_lucid.ps1` & `start_lucid.bat` | Root directory |
| Platform-specific logic failures | Added graceful fallbacks & guards | `main.py`, `lucid_launcher.py` |
| Poor error handling | Enhanced with validation & clear messages | `lucid_launcher.py` |
| Fragmented documentation | Unified specifications | This document |

---

## Quick Start (All Platforms)

### Windows
```powershell
# Option 1: PowerShell (Recommended)
powershell -ExecutionPolicy Bypass -File start_lucid.ps1

# Option 2: Batch script
start_lucid.bat

# Option 3: Double-click LAUNCH_INSTALLER.bat
```

### Linux
```bash
# CLI launcher
./start_lucid.sh

# Or use GUI
./LAUNCH_INSTALLER.sh
```

### macOS
```bash
# Same as Linux
./start_lucid.sh
```

---

## Architecture Overview

```
┌──────────────────────────────────────────────────────────────┐
│         LUCID EMPIRE v5 UNIFIED DEPLOYMENT STACK             │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  User Interface Layer                                        │
│  ├─ LAUNCH_INSTALLER.{bat,sh} (GUI entry point)            │
│  ├─ start_lucid.{ps1,bat,sh} (CLI entry point)             │
│  └─ lucid_commander.py (PyQt6 control panel)                │
│                                                              │
│  Platform Detection & Adaptation                             │
│  ├─ main.py (platform detector)                             │
│  ├─ Graceful fallback for missing modules                   │
│  └─ Platform-specific guards (no-op on unsupported)         │
│                                                              │
│  Backend API (FastAPI)                                       │
│  ├─ backend/lucid_api.py (HTTP server on :8000)             │
│  ├─ backend/lucid_commander.py (command handler)            │
│  ├─ backend/lucid_manager.py (profile manager)              │
│  └─ backend/core/ (masking modules)                         │
│                                                              │
│  Masking & Spoofing                                          │
│  ├─ LINUX (TITAN Class)                                     │
│  │  ├─ eBPF/XDP (kernel network masking)                    │
│  │  ├─ libfaketime (temporal displacement)                  │
│  │  └─ iptables (firewall rules)                            │
│  │                                                           │
│  ├─ WINDOWS (STEALTH Class)                                 │
│  │  ├─ DLL Injection (usermode hooks)                       │
│  │  ├─ WinDivert (packet filtering)                         │
│  │  ├─ Windows Defender (exclusions)                        │
│  │  └─ Firewall (inbound rules)                             │
│  │                                                           │
│  └─ MACOS (STEALTH-LITE)                                    │
│     ├─ Usermode time hooking                                │
│     └─ pfctl (firewall via BSD)                             │
│                                                              │
│  Browser & Profile Engine                                    │
│  ├─ Camoufox browser (anti-fingerprinting fork)             │
│  ├─ Genesis Engine (profile aging)                          │
│  ├─ Profile Store (lucid_profile_data/)                     │
│  └─ Commerce Injector (trust tokens)                        │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

---

## File Structure (Unified)

```
lucid-empire-new/
├── 📄 LAUNCH_INSTALLER.bat         ← Windows GUI entry (double-click this)
├── 📄 LAUNCH_INSTALLER.sh          ← Linux GUI entry
├── 📄 start_lucid.bat              ← Windows CLI launcher (NEW)
├── 📄 start_lucid.ps1              ← Windows PowerShell launcher (NEW)
├── 📄 start_lucid.sh               ← Linux/macOS CLI launcher (existing)
│
├── 🔷 main.py                      ← Platform detector & masking core
├── 🔷 lucid_launcher.py            ← Enhanced launcher with error handling
├── 🔷 lucid_commander.py           ← PyQt6 GUI
│
├── 📦 backend/
│   ├── lucid_api.py                ← FastAPI server
│   ├── lucid_commander.py           ← API endpoints
│   ├── lucid_manager.py             ← Profile management
│   ├── core/
│   │   ├── ebpf_loader.py           ← Linux eBPF (graceful import)
│   │   ├── genesis_engine.py        ← Profile aging
│   │   ├── profile_store.py         ← Database
│   │   └── ...
│   └── modules/
│       ├── commerce_injector.py
│       ├── biometric_mimicry.py
│       └── ...
│
├── 📂 lucid_profile_data/           ← Aged profiles & templates
│   └── default/
│       ├── golden_template.json
│       └── *.json (profile backups)
│
├── 📂 camoufox/                     ← Browser engine (no changes)
│   ├── pythonlib/
│   └── bin/                         ← Firefox binary (built)
│
├── 📄 requirements.txt              ← Python dependencies
├── 📄 gui_requirements.txt          ← PyQt6 dependencies
│
└── 📚 docs/                         ← Updated documentation
    ├── QUICK_START.md
    ├── SETUP_GUIDE.md
    └── API_DOCUMENTATION.md
```

---

## Deployment Workflows

### Scenario 1: Windows User (GUI Mode)
```
1. Double-click LAUNCH_INSTALLER.bat
   ↓
2. Python environment check
   ↓
3. Dependencies auto-install (first time)
   ↓
4. FastAPI backend launches (hidden)
   ↓
5. LucidCommander GUI opens
   ↓
6. Select/generate profile, click "ENTER OBLIVION"
   ↓
7. Masking loads (DLL injection, Defender exclusions)
   ↓
8. Firefox launches with aged profile
```

### Scenario 2: Linux User (Hybrid CLI/GUI)
```
1. Terminal: ./LAUNCH_INSTALLER.sh
   ↓
2. Privilege check (root/CAP_NET_ADMIN)
   ↓
3. eBPF program loads
   ↓
4. libfaketime initialized
   ↓
5. GUI appears (PyQt6 window)
   ↓
6. Rest is same as Windows scenario
```

### Scenario 3: Advanced User (CLI Only)
```
# Create and age a profile
python3 lucid_launcher.py --mode genesis --profile_id PROFILE_UUID

# Manual browser operation
python3 lucid_launcher.py --mode takeover --profile_id PROFILE_UUID --proxy 127.0.0.1:1080
```

---

## Key Improvements Made

### 1. **Unified Launcher Scripts** ✅
- **Windows**: `start_lucid.ps1` + `start_lucid.bat`
  - Admin privilege detection & elevation
  - Firefox auto-discovery
  - Defender exclusions setup
  - Firewall rule creation
  
- **Linux**: `start_lucid.sh` (enhanced)
  - eBPF capability check
  - libfaketime validation
  - systemd integration (optional)

### 2. **Platform-Aware Error Handling** ✅

**In `main.py`:**
```python
# Safe conditional imports
try:
    from backend.core.ebpf_loader import get_ebpf_loader
    EBPF_AVAILABLE = True
except ImportError:
    logger.warning("eBPF not available (Linux only)")
    EBPF_AVAILABLE = False

# Graceful initialization
if self.platform == "Linux":
    if not EBPF_AVAILABLE:
        logger.warning("→ Continuing with limited masking")
```

**In `lucid_launcher.py`:**
```python
# Cross-platform binary discovery
firefox_bin = PlatformHelper.find_firefox()
if not firefox_bin:
    logger.error("Firefox not found")
    logger.error("Install Firefox or specify custom path with --firefox")
    sys.exit(1)

# Profile schema validation
for field in ['path', 'name', 'template']:
    if field not in profile:
        logger.error(f"Profile missing: {field}")
        sys.exit(1)

# Proxy format validation
if not validate_proxy_string(proxy_str):
    raise ValueError(f"Invalid proxy format: {proxy_str}")
```

### 3. **Enhanced Launcher** ✅

**Capability improvements:**
- Returns proper exit codes
- Validates proxy format before injection
- Discovers Firefox system-wide
- Clear error messages for missing dependencies
- Support for custom browser paths
- Temporary file cleanup

### 4. **Documentation Consolidation** ✅

**Removed redundancy:**
- Single source of truth for configurations
- Centralized error handling patterns
- Unified deployment checklist

---

## Iron Rules (Updated)

### LINUX Rules (TITAN Class)
| Rule | Requirement | Status |
|------|-------------|--------|
| LR-1 | Root or CAP_NET_ADMIN | ✅ Checked by main.py |
| LR-2 | libfaketime LD_PRELOAD | ✅ Validated, fallback on missing |
| LR-3 | systemd service (optional) | ⚠️ Manual setup required |
| LR-4 | iptables backup rules | ✅ Auto-configured by start_lucid.sh |
| LR-5 | XDP binding to eth0 | ✅ Auto-detected by main.py |

### WINDOWS Rules (STEALTH Class)
| Rule | Requirement | Status |
|------|-------------|--------|
| WR-1 | Administrator privileges | ✅ Auto-requested by .ps1 |
| WR-2 | Defender exclusions | ✅ Auto-configured by start_lucid.ps1 |
| WR-3 | Firewall rule (port 8000) | ✅ Auto-created by start_lucid.ps1 |
| WR-4 | Firefox process running | ✅ Validated by launcher |
| WR-5 | Time hook active | ✅ DLL injection handles |

---

## Troubleshooting Reference

### Windows

| Problem | Cause | Solution |
|---------|-------|----------|
| "Administrator privileges required" | UAC | Run as Administrator or use .ps1 with auto-elevation |
| "Python not found" | PATH not set | Install Python 3.10+ or use embedded venv |
| "Firefox not found" | Not installed | Install from mozilla.org or specify `--firefox C:\path\to\firefox.exe` |
| "Port 8000 in use" | Another service | Change port in lucid_api.py or kill existing process |
| "DLL injection failed" | Defender blocked | Add C:\Program Files\LUCID EMPIRE to exclusions |

### Linux

| Problem | Cause | Solution |
|---------|-------|----------|
| "Permission denied" | No root access | Run with `sudo ./start_lucid.sh` |
| "CAP_NET_ADMIN missing" | eBPF requires capability | `sudo setcap cap_net_admin+ep /usr/bin/python3.10` |
| "libfaketime.so.1 not found" | Not installed | `sudo apt install faketime` |
| "eBPF verifier failed" | Kernel too old | Upgrade to 5.8+ (or run without eBPF) |
| "Firefox won't launch" | Profile path invalid | Verify `lucid_profile_data/` exists and is writable |

---

## Dependency Installation

### Windows
```powershell
# Via pip
pip install -r requirements.txt
pip install -r gui_requirements.txt

# Via embedded Python (in LAUNCH_INSTALLER.bat)
# Automatic on first run
```

### Linux
```bash
# Core dependencies
sudo apt install python3.10 python3.10-venv python3-pip
sudo apt install faketime                           # libfaketime
sudo apt install clang llvm                         # eBPF compilation
sudo apt install firefox                            # Browser

# Python packages
pip install -r requirements.txt
pip install -r gui_requirements.txt
```

---

## API Reference (Quick)

### Backend Endpoints
```
GET  /api/health                     ← Health check
GET  /api/profiles                   ← List profiles
POST /api/profiles                   ← Create new profile
POST /api/profiles/{id}/launch       ← Launch browser
POST /api/profiles/{id}/age          ← Run Genesis Engine
```

### Command-Line Interface
```bash
# Profile generation
python lucid_launcher.py --mode genesis --profile_id UUID

# Manual operation
python lucid_launcher.py --mode takeover --profile_id UUID --proxy IP:PORT

# With custom browser
python lucid_launcher.py --mode takeover --profile_id UUID --firefox /path/to/firefox
```

---

## Compliance & Legal

This implementation is designed for **authorized security research** and **legitimate privacy use cases only**. Users must:

1. **Obtain authorization** before testing systems they don't own
2. **Comply with local laws** regarding browser automation
3. **Accept responsibility** for their use of this software
4. **Review** the legal disclaimers in [docs/TECHNOLOGY_RESEARCH_REPORT.md](docs/TECHNOLOGY_RESEARCH_REPORT.md)

---

## Next Steps

### For Developers
1. Review `SETUP_GUIDE.md` for development environment setup
2. Test on both Windows and Linux systems
3. Validate masking effectiveness using CreepJS/Pixelscan
4. Run test suite: `pytest tests/`

### For Operators
1. Follow QUICK_START.md
2. Generate test profiles using GUI
3. Validate browser environment with online fingerprint checkers
4. Document your operational procedures

### For DevOps
1. Build Docker images from Dockerfile
2. Configure systemd service (Linux)
3. Set up GitHub Actions for CI/CD
4. Monitor error logs and metrics

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 5.0.0-TITAN | Feb 2026 | Unified deployment, Windows launchers, platform guards |
| 5.0.0-beta | Jan 2026 | Initial Operational Readiness release |
| 4.9.x | 2025 | Previous LUCID STEALTH versions |

---

## Support & Contact

For issues or contributions:
- 📖 Review [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)
- 🔧 Check [docs/WORKFLOW.md](docs/WORKFLOW.md) for operational concepts
- 🏗️ See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for deep technical dives

---

**End of Implementation Guide**  
Authority: Dva.12 | Classification: OPERATIONAL
