#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════
#  LUCID EMPIRE v5.0.0-TITAN :: ONE-CLICK INSTALLER
#  Linux/macOS Launcher Script
# ═══════════════════════════════════════════════════════════════════════════

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║                                                                  ║${NC}"
echo -e "${WHITE}║     ██╗     ██╗   ██╗ ██████╗██╗██████╗                         ║${NC}"
echo -e "${WHITE}║     ██║     ██║   ██║██╔════╝██║██╔══██╗                        ║${NC}"
echo -e "${WHITE}║     ██║     ██║   ██║██║     ██║██║  ██║                        ║${NC}"
echo -e "${WHITE}║     ██║     ██║   ██║██║     ██║██║  ██║                        ║${NC}"
echo -e "${WHITE}║     ███████╗╚██████╔╝╚██████╗██║██████╔╝                        ║${NC}"
echo -e "${WHITE}║     ╚══════╝ ╚═════╝  ╚═════╝╚═╝╚═════╝                         ║${NC}"
echo -e "${CYAN}║                                                                  ║${NC}"
echo -e "${CYAN}║     E M P I R E   v5.0.0-TITAN                                  ║${NC}"
echo -e "${CYAN}║     ONE-CLICK INSTALLER                                         ║${NC}"
echo -e "${CYAN}║                                                                  ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Detect OS
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    OS_TYPE="linux"
    echo -e "${GREEN}[OK]${NC} Detected: Linux"
elif [[ "$OSTYPE" == "darwin"* ]]; then
    OS_TYPE="macos"
    echo -e "${GREEN}[OK]${NC} Detected: macOS"
else
    OS_TYPE="unknown"
    echo -e "${YELLOW}[WARN]${NC} Unknown OS: $OSTYPE"
fi

# Check Python
echo -e "${CYAN}[*]${NC} Checking Python installation..."
if command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
elif command -v python &> /dev/null; then
    PYTHON_CMD="python"
else
    echo -e "${RED}[ERROR]${NC} Python not found!"
    echo "Please install Python 3.9+ using your package manager:"
    echo ""
    if [[ "$OS_TYPE" == "linux" ]]; then
        echo "  Ubuntu/Debian: sudo apt install python3 python3-pip python3-tk"
        echo "  Fedora:        sudo dnf install python3 python3-pip python3-tkinter"
        echo "  Arch:          sudo pacman -S python python-pip tk"
    elif [[ "$OS_TYPE" == "macos" ]]; then
        echo "  macOS:         brew install python3 python-tk"
    fi
    exit 1
fi

PY_VERSION=$($PYTHON_CMD --version 2>&1 | cut -d' ' -f2)
echo -e "${GREEN}[OK]${NC} Python $PY_VERSION found"

# Check Python version >= 3.9
PY_MAJOR=$($PYTHON_CMD -c "import sys; print(sys.version_info.major)")
PY_MINOR=$($PYTHON_CMD -c "import sys; print(sys.version_info.minor)")

if [[ "$PY_MAJOR" -lt 3 ]] || [[ "$PY_MAJOR" -eq 3 && "$PY_MINOR" -lt 9 ]]; then
    echo -e "${RED}[ERROR]${NC} Python 3.9+ required, found $PY_VERSION"
    exit 1
fi

# Check for tkinter
echo -e "${CYAN}[*]${NC} Checking tkinter availability..."
if $PYTHON_CMD -c "import tkinter" 2>/dev/null; then
    echo -e "${GREEN}[OK]${NC} tkinter available - GUI mode enabled"
    GUI_MODE=""
else
    echo -e "${YELLOW}[WARN]${NC} tkinter not available, will run in CLI mode"
    echo "To enable GUI, install tkinter:"
    if [[ "$OS_TYPE" == "linux" ]]; then
        echo "  Ubuntu/Debian: sudo apt install python3-tk"
        echo "  Fedora:        sudo dnf install python3-tkinter"
        echo "  Arch:          sudo pacman -S tk"
    elif [[ "$OS_TYPE" == "macos" ]]; then
        echo "  macOS:         brew install python-tk"
    fi
    GUI_MODE="--cli"
fi

echo ""
echo -e "${CYAN}[*]${NC} Launching LUCID EMPIRE Installer..."
echo ""

# Make installer executable
if [[ -f "LUCID_INSTALLER.py" ]]; then
    $PYTHON_CMD LUCID_INSTALLER.py $GUI_MODE
    EXIT_CODE=$?
else
    echo -e "${RED}[ERROR]${NC} LUCID_INSTALLER.py not found!"
    echo "Please ensure you're running from the project root directory."
    exit 1
fi

if [[ $EXIT_CODE -ne 0 ]]; then
    echo ""
    echo -e "${YELLOW}[!]${NC} Installation encountered issues. Check the log above."
else
    echo ""
    echo -e "${GREEN}[OK]${NC} Installation process completed."
    echo ""
    echo "═══════════════════════════════════════════════════════════════"
    echo "  To launch the browser manually:"
    echo "    python3 launch_lucid_browser.py --profile <name>"
    echo ""
    echo "  To see available profiles:"
    echo "    python3 launch_lucid_browser.py --list-profiles"
    echo "═══════════════════════════════════════════════════════════════"
    echo ""
fi

exit $EXIT_CODE
