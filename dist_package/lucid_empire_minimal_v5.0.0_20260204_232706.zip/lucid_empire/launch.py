#!/usr/bin/env python3
"""
LUCID EMPIRE v5.0 TITAN :: UNIVERSAL LAUNCHER
Purpose: Platform-detecting launcher that routes to the correct control panel
Authority: Dva.12

This is the main entry point that detects the OS and launches the appropriate
platform-specific control panel (Linux/TITAN or Windows/STEALTH).
"""

import sys
import os
import platform
import subprocess
from pathlib import Path

# Get project root
PROJECT_ROOT = Path(__file__).parent.absolute()


def detect_platform():
    """Detect the current operating system"""
    system = platform.system().lower()
    
    if system == "linux":
        return "linux"
    elif system == "windows":
        return "windows"
    elif system == "darwin":
        return "macos"  # Future support
    else:
        return "unknown"


def launch_linux():
    """Launch Linux control panel"""
    print("=" * 60)
    print("  LUCID EMPIRE v5.0 TITAN")
    print("  Platform: Linux / TITAN Class")
    print("=" * 60)
    print()
    
    control_panel = PROJECT_ROOT / "platforms" / "linux" / "lucid_control_panel_linux.py"
    
    if not control_panel.exists():
        print(f"[ERROR] Linux control panel not found: {control_panel}")
        sys.exit(1)
    
    # Check for libfaketime
    libfaketime_paths = [
        "/usr/lib/x86_64-linux-gnu/faketime/libfaketime.so.1",
        "/usr/lib/x86_64-linux-gnu/libfaketime.so.1",
        "/usr/local/lib/faketime/libfaketime.so.1",
        "/usr/lib/faketime/libfaketime.so.1"
    ]
    
    libfaketime = None
    for path in libfaketime_paths:
        if os.path.exists(path):
            libfaketime = path
            break
    
    env = os.environ.copy()
    
    if libfaketime:
        print(f"[OK] libfaketime found: {libfaketime}")
        env["LD_PRELOAD"] = libfaketime
        env["FAKETIME"] = "-90d"
        env["FAKETIME_NO_CACHE"] = "1"
    else:
        print("[WARN] libfaketime not found - time displacement disabled")
        print("[INFO] Install with: sudo apt install faketime")
    
    print()
    print("[*] Launching Linux Control Panel...")
    print()
    
    os.chdir(control_panel.parent)
    os.execve(sys.executable, [sys.executable, str(control_panel)], env)


def launch_windows():
    """Launch Windows control panel"""
    print("=" * 60)
    print("  LUCID EMPIRE v5.0 TITAN")
    print("  Platform: Windows / STEALTH Class")
    print("=" * 60)
    print()
    
    control_panel = PROJECT_ROOT / "platforms" / "windows" / "lucid_control_panel_windows.py"
    
    if not control_panel.exists():
        print(f"[ERROR] Windows control panel not found: {control_panel}")
        sys.exit(1)
    
    # Check for PyQt6
    try:
        import PyQt6
        print("[OK] PyQt6 found")
    except ImportError:
        print("[*] Installing PyQt6...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "PyQt6", "requests"])
    
    print()
    print("[*] Launching Windows Control Panel...")
    print()
    
    os.chdir(control_panel.parent)
    subprocess.run([sys.executable, str(control_panel)])


def launch_fallback():
    """Launch the original cross-platform control panel"""
    print("=" * 60)
    print("  LUCID EMPIRE v5.0 TITAN")
    print("  Platform: Generic")
    print("=" * 60)
    print()
    
    control_panel = PROJECT_ROOT / "lucid_control_panel.py"
    
    if control_panel.exists():
        print("[*] Launching generic Control Panel...")
        subprocess.run([sys.executable, str(control_panel)])
    else:
        print("[ERROR] No control panel found")
        sys.exit(1)


def main():
    print()
    
    current_platform = detect_platform()
    print(f"[*] Detected platform: {current_platform}")
    
    if current_platform == "linux":
        launch_linux()
    elif current_platform == "windows":
        launch_windows()
    elif current_platform == "macos":
        print("[INFO] macOS support coming soon")
        print("[INFO] Falling back to generic launcher")
        launch_fallback()
    else:
        print(f"[WARN] Unknown platform: {current_platform}")
        launch_fallback()


if __name__ == "__main__":
    main()
