#!/usr/bin/env python3
"""
LUCID EMPIRE v5.0 TITAN :: ONE-CLICK INSTALLER GUI
Purpose: Provides a graphical installer and launcher for the complete Lucid anti-detect browser system.
Authority: Dva.12
"""

import sys
import os
import subprocess
import threading
import shutil
from pathlib import Path

# Ensure we can find our modules
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QPushButton, QLabel, QProgressBar, QTextEdit, QStackedWidget,
        QFrame, QMessageBox, QSplashScreen
    )
    from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
    from PyQt6.QtGui import QFont, QColor, QPalette, QPixmap, QIcon
except ImportError:
    print("[ERROR] PyQt6 is not installed. Installing now...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "PyQt6"])
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QPushButton, QLabel, QProgressBar, QTextEdit, QStackedWidget,
        QFrame, QMessageBox, QSplashScreen
    )
    from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
    from PyQt6.QtGui import QFont, QColor, QPalette, QPixmap, QIcon


# --- CONFIGURATION ---
PROJECT_ROOT = Path(__file__).parent.absolute()
VENV_PATH = PROJECT_ROOT / "venv"
DASHBOARD_PATH = PROJECT_ROOT / "dashboard"
BACKEND_PATH = PROJECT_ROOT / "backend"


# --- DARK THEME STYLESHEET ---
DARK_STYLESHEET = """
QMainWindow, QWidget {
    background-color: #0a0a0f;
    color: #06b6d4;
    font-family: 'Consolas', 'Courier New', monospace;
}

QLabel {
    color: #06b6d4;
    font-size: 12px;
}

QLabel#title {
    font-size: 28px;
    font-weight: bold;
    color: #ffffff;
    padding: 10px;
}

QLabel#subtitle {
    font-size: 11px;
    color: #64748b;
    letter-spacing: 3px;
}

QLabel#status-ok {
    color: #10b981;
    font-weight: bold;
}

QLabel#status-error {
    color: #ef4444;
    font-weight: bold;
}

QLabel#status-pending {
    color: #f59e0b;
}

QPushButton {
    background-color: #1e293b;
    color: #06b6d4;
    border: 1px solid #334155;
    padding: 12px 24px;
    font-size: 13px;
    font-weight: bold;
    border-radius: 2px;
    min-width: 150px;
}

QPushButton:hover {
    background-color: #06b6d4;
    color: #000000;
    border-color: #06b6d4;
}

QPushButton:pressed {
    background-color: #0891b2;
}

QPushButton:disabled {
    background-color: #1e293b;
    color: #475569;
    border-color: #1e293b;
}

QPushButton#danger {
    background-color: #7f1d1d;
    border-color: #dc2626;
    color: #fca5a5;
}

QPushButton#danger:hover {
    background-color: #dc2626;
    color: #000000;
}

QPushButton#primary {
    background-color: #164e63;
    border-color: #06b6d4;
}

QPushButton#primary:hover {
    background-color: #06b6d4;
    color: #000000;
}

QProgressBar {
    background-color: #1e293b;
    border: 1px solid #334155;
    border-radius: 2px;
    height: 20px;
    text-align: center;
    color: #ffffff;
}

QProgressBar::chunk {
    background-color: #06b6d4;
}

QTextEdit {
    background-color: #020617;
    color: #94a3b8;
    border: 1px solid #1e293b;
    font-family: 'Consolas', 'Courier New', monospace;
    font-size: 11px;
    padding: 8px;
}

QFrame#separator {
    background-color: #1e293b;
    max-height: 1px;
}

QFrame#card {
    background-color: #0f172a;
    border: 1px solid #1e293b;
    border-radius: 4px;
    padding: 16px;
}
"""


class WorkerThread(QThread):
    """Background worker thread for long-running operations"""
    log_signal = pyqtSignal(str, str)  # message, type (info/success/error/warning)
    progress_signal = pyqtSignal(int)
    finished_signal = pyqtSignal(bool, str)  # success, message
    
    def __init__(self, task_type: str):
        super().__init__()
        self.task_type = task_type
        self.is_cancelled = False
    
    def log(self, msg: str, msg_type: str = "info"):
        self.log_signal.emit(msg, msg_type)
    
    def run(self):
        try:
            if self.task_type == "check_deps":
                self._check_dependencies()
            elif self.task_type == "install":
                self._install_all()
            elif self.task_type == "launch":
                self._launch_system()
        except Exception as e:
            self.finished_signal.emit(False, str(e))
    
    def _check_dependencies(self):
        """Check all system dependencies"""
        self.log("Checking system dependencies...", "info")
        self.progress_signal.emit(10)
        
        # Check Python
        try:
            result = subprocess.run([sys.executable, "--version"], capture_output=True, text=True)
            py_version = result.stdout.strip()
            self.log(f"[OK] Python: {py_version}", "success")
        except Exception as e:
            self.log(f"[FAIL] Python not found: {e}", "error")
            self.finished_signal.emit(False, "Python not found")
            return
        
        self.progress_signal.emit(30)
        
        # Check Node.js
        try:
            result = subprocess.run(["node", "--version"], capture_output=True, text=True, shell=True)
            if result.returncode == 0:
                node_version = result.stdout.strip()
                self.log(f"[OK] Node.js: {node_version}", "success")
            else:
                self.log("[WARN] Node.js not found - will need manual install", "warning")
        except Exception:
            self.log("[WARN] Node.js not found - will need manual install", "warning")
        
        self.progress_signal.emit(50)
        
        # Check npm
        try:
            result = subprocess.run(["npm", "--version"], capture_output=True, text=True, shell=True)
            if result.returncode == 0:
                npm_version = result.stdout.strip()
                self.log(f"[OK] npm: {npm_version}", "success")
            else:
                self.log("[WARN] npm not found", "warning")
        except Exception:
            self.log("[WARN] npm not found", "warning")
        
        self.progress_signal.emit(70)
        
        # Check if venv exists
        if VENV_PATH.exists():
            self.log("[OK] Python virtual environment found", "success")
        else:
            self.log("[INFO] Virtual environment will be created during install", "info")
        
        # Check if node_modules exists
        node_modules = DASHBOARD_PATH / "node_modules"
        if node_modules.exists():
            self.log("[OK] Dashboard dependencies installed", "success")
        else:
            self.log("[INFO] Dashboard dependencies will be installed", "info")
        
        self.progress_signal.emit(100)
        self.finished_signal.emit(True, "Dependency check complete")
    
    def _install_all(self):
        """Install all dependencies"""
        self.log("=" * 50, "info")
        self.log("LUCID EMPIRE INSTALLATION PROTOCOL", "info")
        self.log("=" * 50, "info")
        
        # Step 1: Create virtual environment
        self.log("\n[PHASE 1] Creating Python virtual environment...", "info")
        self.progress_signal.emit(5)
        
        if not VENV_PATH.exists():
            try:
                subprocess.run([sys.executable, "-m", "venv", str(VENV_PATH)], check=True)
                self.log("[OK] Virtual environment created", "success")
            except Exception as e:
                self.log(f"[FAIL] Could not create venv: {e}", "error")
                self.finished_signal.emit(False, "Failed to create virtual environment")
                return
        else:
            self.log("[OK] Virtual environment already exists", "success")
        
        self.progress_signal.emit(15)
        
        # Step 2: Install Python dependencies
        self.log("\n[PHASE 2] Installing Python dependencies...", "info")
        
        if os.name == 'nt':
            pip_path = VENV_PATH / "Scripts" / "pip.exe"
            python_path = VENV_PATH / "Scripts" / "python.exe"
        else:
            pip_path = VENV_PATH / "bin" / "pip"
            python_path = VENV_PATH / "bin" / "python"
        
        requirements_file = PROJECT_ROOT / "requirements.txt"
        if requirements_file.exists():
            try:
                process = subprocess.Popen(
                    [str(pip_path), "install", "-r", str(requirements_file)],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    cwd=str(PROJECT_ROOT)
                )
                for line in process.stdout:
                    line = line.strip()
                    if line:
                        if "Successfully" in line or "Requirement already" in line:
                            self.log(f"  {line}", "success")
                        elif "ERROR" in line or "error" in line.lower():
                            self.log(f"  {line}", "error")
                        else:
                            self.log(f"  {line}", "info")
                process.wait()
                if process.returncode == 0:
                    self.log("[OK] Python dependencies installed", "success")
                else:
                    self.log("[WARN] Some Python dependencies may have failed", "warning")
            except Exception as e:
                self.log(f"[FAIL] pip install failed: {e}", "error")
        
        self.progress_signal.emit(40)
        
        # Step 3: Install Playwright browsers
        self.log("\n[PHASE 3] Installing Playwright browsers...", "info")
        try:
            subprocess.run(
                [str(python_path), "-m", "playwright", "install"],
                check=True,
                cwd=str(PROJECT_ROOT)
            )
            self.log("[OK] Playwright browsers installed", "success")
        except Exception as e:
            self.log(f"[WARN] Playwright install issue: {e}", "warning")
        
        self.progress_signal.emit(60)
        
        # Step 4: Install Node.js dependencies
        self.log("\n[PHASE 4] Installing Dashboard dependencies...", "info")
        
        if DASHBOARD_PATH.exists():
            try:
                process = subprocess.Popen(
                    ["npm", "install"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    cwd=str(DASHBOARD_PATH),
                    shell=True
                )
                for line in process.stdout:
                    line = line.strip()
                    if line:
                        self.log(f"  {line}", "info")
                process.wait()
                if process.returncode == 0:
                    self.log("[OK] Dashboard dependencies installed", "success")
                else:
                    self.log("[WARN] npm install had issues", "warning")
            except Exception as e:
                self.log(f"[FAIL] npm install failed: {e}", "error")
        
        self.progress_signal.emit(90)
        
        # Step 5: Verify installation
        self.log("\n[PHASE 5] Verifying installation...", "info")
        
        verify_script = PROJECT_ROOT / "verify_integration.py"
        if verify_script.exists():
            try:
                result = subprocess.run(
                    [str(python_path), str(verify_script)],
                    capture_output=True,
                    text=True,
                    cwd=str(PROJECT_ROOT)
                )
                for line in result.stdout.split('\n'):
                    if line.strip():
                        self.log(line, "info")
            except Exception as e:
                self.log(f"[WARN] Verification script failed: {e}", "warning")
        
        self.progress_signal.emit(100)
        self.log("\n" + "=" * 50, "success")
        self.log("INSTALLATION COMPLETE", "success")
        self.log("=" * 50, "success")
        self.finished_signal.emit(True, "Installation complete!")
    
    def _launch_system(self):
        """Launch the backend and frontend"""
        self.log("Launching Lucid Empire systems...", "info")
        self.progress_signal.emit(20)
        
        if os.name == 'nt':
            python_path = VENV_PATH / "Scripts" / "python.exe"
        else:
            python_path = VENV_PATH / "bin" / "python"
        
        # Launch Backend
        self.log("\n[1/2] Starting Backend API Server...", "info")
        try:
            backend_cmd = [
                str(python_path), "-m", "uvicorn",
                "backend.lucid_api:app",
                "--reload", "--port", "8000"
            ]
            subprocess.Popen(
                backend_cmd,
                cwd=str(PROJECT_ROOT),
                creationflags=subprocess.CREATE_NEW_CONSOLE if os.name == 'nt' else 0
            )
            self.log("[OK] Backend server starting on http://localhost:8000", "success")
        except Exception as e:
            self.log(f"[FAIL] Backend launch failed: {e}", "error")
            self.finished_signal.emit(False, f"Backend launch failed: {e}")
            return
        
        self.progress_signal.emit(50)
        
        # Launch Frontend
        self.log("\n[2/2] Starting Dashboard Interface...", "info")
        try:
            if os.name == 'nt':
                frontend_cmd = ["cmd", "/c", "npm", "run", "dev"]
            else:
                frontend_cmd = ["npm", "run", "dev"]
            
            subprocess.Popen(
                frontend_cmd,
                cwd=str(DASHBOARD_PATH),
                creationflags=subprocess.CREATE_NEW_CONSOLE if os.name == 'nt' else 0,
                shell=True
            )
            self.log("[OK] Dashboard starting on http://localhost:3000", "success")
        except Exception as e:
            self.log(f"[FAIL] Dashboard launch failed: {e}", "error")
            self.finished_signal.emit(False, f"Dashboard launch failed: {e}")
            return
        
        self.progress_signal.emit(100)
        self.log("\n" + "=" * 50, "success")
        self.log("SYSTEMS ONLINE", "success")
        self.log("Access Console: http://localhost:3000", "success")
        self.log("API Docs: http://localhost:8000/docs", "success")
        self.log("=" * 50, "success")
        self.finished_signal.emit(True, "Systems launched successfully!")


class LucidInstallerGUI(QMainWindow):
    """Main installer window"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("LUCID EMPIRE v5.0 TITAN :: INSTALLER")
        self.setMinimumSize(800, 600)
        self.setStyleSheet(DARK_STYLESHEET)
        
        self.worker = None
        self._setup_ui()
    
    def _setup_ui(self):
        """Setup the main UI"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(30, 30, 30, 30)
        main_layout.setSpacing(20)
        
        # Header
        header_layout = QVBoxLayout()
        
        title_label = QLabel("LUCID EMPIRE")
        title_label.setObjectName("title")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(title_label)
        
        subtitle_label = QLabel("v5.0 TITAN // ANTI-DETECT BROWSER SYSTEM")
        subtitle_label.setObjectName("subtitle")
        subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(subtitle_label)
        
        main_layout.addLayout(header_layout)
        
        # Separator
        separator = QFrame()
        separator.setObjectName("separator")
        separator.setFrameShape(QFrame.Shape.HLine)
        main_layout.addWidget(separator)
        
        # Status Cards
        status_layout = QHBoxLayout()
        status_layout.setSpacing(15)
        
        # Python Status
        self.python_status = self._create_status_card("PYTHON", "Checking...")
        status_layout.addWidget(self.python_status)
        
        # Node.js Status
        self.node_status = self._create_status_card("NODE.JS", "Checking...")
        status_layout.addWidget(self.node_status)
        
        # Dependencies Status
        self.deps_status = self._create_status_card("DEPENDENCIES", "Checking...")
        status_layout.addWidget(self.deps_status)
        
        main_layout.addLayout(status_layout)
        
        # Progress Bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setFormat("%p%")
        main_layout.addWidget(self.progress_bar)
        
        # Log Console
        self.log_console = QTextEdit()
        self.log_console.setReadOnly(True)
        self.log_console.setMinimumHeight(200)
        main_layout.addWidget(self.log_console)
        
        # Button Row
        button_layout = QHBoxLayout()
        button_layout.setSpacing(15)
        
        self.check_btn = QPushButton("CHECK SYSTEM")
        self.check_btn.clicked.connect(self._on_check_clicked)
        button_layout.addWidget(self.check_btn)
        
        self.install_btn = QPushButton("INSTALL ALL")
        self.install_btn.setObjectName("primary")
        self.install_btn.clicked.connect(self._on_install_clicked)
        button_layout.addWidget(self.install_btn)
        
        self.launch_btn = QPushButton("LAUNCH SYSTEM")
        self.launch_btn.setObjectName("primary")
        self.launch_btn.clicked.connect(self._on_launch_clicked)
        button_layout.addWidget(self.launch_btn)
        
        self.exit_btn = QPushButton("EXIT")
        self.exit_btn.setObjectName("danger")
        self.exit_btn.clicked.connect(self.close)
        button_layout.addWidget(self.exit_btn)
        
        main_layout.addLayout(button_layout)
        
        # Footer
        footer_label = QLabel("AUTHORITY: Dva.12 | CLASSIFICATION: TOP SECRET")
        footer_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        footer_label.setStyleSheet("color: #475569; font-size: 10px;")
        main_layout.addWidget(footer_label)
        
        # Initial check
        QTimer.singleShot(500, self._on_check_clicked)
    
    def _create_status_card(self, title: str, status: str) -> QFrame:
        """Create a status card widget"""
        card = QFrame()
        card.setObjectName("card")
        card.setMinimumWidth(200)
        
        layout = QVBoxLayout(card)
        layout.setSpacing(8)
        
        title_label = QLabel(title)
        title_label.setStyleSheet("font-weight: bold; font-size: 11px; color: #64748b;")
        layout.addWidget(title_label)
        
        status_label = QLabel(status)
        status_label.setObjectName("status-pending")
        status_label.setStyleSheet("font-size: 14px;")
        layout.addWidget(status_label)
        
        card.status_label = status_label
        return card
    
    def _update_status_card(self, card: QFrame, status: str, status_type: str = "pending"):
        """Update a status card"""
        card.status_label.setText(status)
        if status_type == "ok":
            card.status_label.setStyleSheet("font-size: 14px; color: #10b981; font-weight: bold;")
        elif status_type == "error":
            card.status_label.setStyleSheet("font-size: 14px; color: #ef4444; font-weight: bold;")
        else:
            card.status_label.setStyleSheet("font-size: 14px; color: #f59e0b;")
    
    def _log(self, message: str, msg_type: str = "info"):
        """Add message to log console"""
        color_map = {
            "info": "#94a3b8",
            "success": "#10b981",
            "error": "#ef4444",
            "warning": "#f59e0b"
        }
        color = color_map.get(msg_type, "#94a3b8")
        self.log_console.append(f'<span style="color: {color};">{message}</span>')
        # Auto-scroll to bottom
        scrollbar = self.log_console.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())
    
    def _set_buttons_enabled(self, enabled: bool):
        """Enable/disable all action buttons"""
        self.check_btn.setEnabled(enabled)
        self.install_btn.setEnabled(enabled)
        self.launch_btn.setEnabled(enabled)
    
    def _on_check_clicked(self):
        """Handle check button click"""
        self._set_buttons_enabled(False)
        self.progress_bar.setValue(0)
        self.log_console.clear()
        
        self._update_status_card(self.python_status, "Checking...", "pending")
        self._update_status_card(self.node_status, "Checking...", "pending")
        self._update_status_card(self.deps_status, "Checking...", "pending")
        
        self.worker = WorkerThread("check_deps")
        self.worker.log_signal.connect(self._on_worker_log)
        self.worker.progress_signal.connect(self.progress_bar.setValue)
        self.worker.finished_signal.connect(self._on_check_finished)
        self.worker.start()
    
    def _on_install_clicked(self):
        """Handle install button click"""
        self._set_buttons_enabled(False)
        self.progress_bar.setValue(0)
        self.log_console.clear()
        
        self.worker = WorkerThread("install")
        self.worker.log_signal.connect(self._on_worker_log)
        self.worker.progress_signal.connect(self.progress_bar.setValue)
        self.worker.finished_signal.connect(self._on_install_finished)
        self.worker.start()
    
    def _on_launch_clicked(self):
        """Handle launch button click"""
        self._set_buttons_enabled(False)
        self.progress_bar.setValue(0)
        self.log_console.clear()
        
        self.worker = WorkerThread("launch")
        self.worker.log_signal.connect(self._on_worker_log)
        self.worker.progress_signal.connect(self.progress_bar.setValue)
        self.worker.finished_signal.connect(self._on_launch_finished)
        self.worker.start()
    
    def _on_worker_log(self, message: str, msg_type: str):
        """Handle log messages from worker"""
        self._log(message, msg_type)
        
        # Update status cards based on log messages
        if "[OK] Python" in message:
            self._update_status_card(self.python_status, "INSTALLED", "ok")
        elif "[FAIL] Python" in message:
            self._update_status_card(self.python_status, "NOT FOUND", "error")
        elif "[OK] Node.js" in message:
            self._update_status_card(self.node_status, "INSTALLED", "ok")
        elif "[WARN] Node.js" in message:
            self._update_status_card(self.node_status, "NOT FOUND", "error")
        elif "dependencies installed" in message.lower():
            self._update_status_card(self.deps_status, "READY", "ok")
    
    def _on_check_finished(self, success: bool, message: str):
        """Handle check completion"""
        self._set_buttons_enabled(True)
        if success:
            self._log(f"\n{message}", "success")
        else:
            self._log(f"\n{message}", "error")
    
    def _on_install_finished(self, success: bool, message: str):
        """Handle install completion"""
        self._set_buttons_enabled(True)
        if success:
            self._log(f"\n{message}", "success")
            self._update_status_card(self.deps_status, "INSTALLED", "ok")
            QMessageBox.information(self, "Installation Complete", 
                "All dependencies have been installed successfully!\n\nClick 'LAUNCH SYSTEM' to start.")
        else:
            self._log(f"\n{message}", "error")
            QMessageBox.warning(self, "Installation Failed", f"Installation failed:\n{message}")
    
    def _on_launch_finished(self, success: bool, message: str):
        """Handle launch completion"""
        self._set_buttons_enabled(True)
        if success:
            self._log(f"\n{message}", "success")
            QMessageBox.information(self, "Systems Online", 
                "Lucid Empire is now running!\n\n"
                "Console: http://localhost:3000\n"
                "API Docs: http://localhost:8000/docs\n\n"
                "Two terminal windows have been opened for the servers.")
        else:
            self._log(f"\n{message}", "error")
            QMessageBox.warning(self, "Launch Failed", f"Launch failed:\n{message}")


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    
    # Set dark palette
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor(10, 10, 15))
    palette.setColor(QPalette.ColorRole.WindowText, QColor(6, 182, 212))
    palette.setColor(QPalette.ColorRole.Base, QColor(2, 6, 23))
    palette.setColor(QPalette.ColorRole.Text, QColor(148, 163, 184))
    app.setPalette(palette)
    
    window = LucidInstallerGUI()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
