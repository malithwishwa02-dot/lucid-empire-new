from .sample import sample_webgl

__all__ = ['sample_webgl']
