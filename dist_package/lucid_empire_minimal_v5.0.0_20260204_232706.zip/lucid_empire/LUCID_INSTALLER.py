#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  LUCID EMPIRE v5.0.0-TITAN :: ONE-CLICK INSTALLER GUI                        ║
║  Cross-Platform Anti-Detect Browser Installation System                      ║
║  Supports: Windows 10/11, Ubuntu/Debian, Fedora, Arch Linux                  ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import sys
import os
import platform
import subprocess
import threading
import shutil
import json
import urllib.request
import zipfile
import tarfile
from pathlib import Path
from datetime import datetime

# Add project root to path
PROJECT_ROOT = Path(__file__).parent.absolute()
sys.path.insert(0, str(PROJECT_ROOT))

# Try to import tkinter (built into Python)
try:
    import tkinter as tk
    from tkinter import ttk, messagebox, scrolledtext
    HAS_TK = True
except ImportError:
    HAS_TK = False
    print("[!] tkinter not available - running in CLI mode")


# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

VERSION = "5.0.0-TITAN"
CAMOUFOX_VERSION = "135.0.1"
CAMOUFOX_RELEASE = "beta.24"

# Paths
VENV_PATH = PROJECT_ROOT / "venv"
CAMOUFOX_BIN_PATH = PROJECT_ROOT / "camoufox" / "bin"
CAMOUFOX_CACHE_WIN = Path.home() / "AppData" / "Local" / "camoufox" / "camoufox" / "Cache"
CAMOUFOX_CACHE_LINUX = Path.home() / ".cache" / "camoufox"
ASSETS_PATH = PROJECT_ROOT / "assets"
MODELS_PATH = ASSETS_PATH / "models"
PROFILE_PATH = PROJECT_ROOT / "lucid_profile_data"

# Download URLs
CAMOUFOX_URLS = {
    "windows": "https://github.com/nicoswan/camoufox/releases/download/beta.24/camoufox-win-x86_64.zip",
    "linux": "https://github.com/nicoswan/camoufox/releases/download/beta.24/camoufox-linux-x86_64.tar.gz",
}

# Required Python packages
REQUIRED_PACKAGES = [
    "playwright",
    "camoufox",
    "fastapi",
    "uvicorn",
    "httpx",
    "pydantic",
    "aiofiles",
    "python-multipart",
    "websockets",
    "faker",
    "requests",
]


# ═══════════════════════════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def get_os_info():
    """Detect operating system"""
    system = platform.system().lower()
    if system == "windows":
        return "windows", platform.release(), platform.machine()
    elif system == "linux":
        # Try to get distro info
        distro = "linux"
        try:
            with open("/etc/os-release") as f:
                for line in f:
                    if line.startswith("ID="):
                        distro = line.split("=")[1].strip().strip('"')
                        break
        except:
            pass
        return "linux", distro, platform.machine()
    elif system == "darwin":
        return "macos", platform.mac_ver()[0], platform.machine()
    return system, "", platform.machine()


def run_command(cmd, cwd=None, shell=False):
    """Run a command and return output"""
    try:
        result = subprocess.run(
            cmd,
            cwd=cwd,
            shell=shell,
            capture_output=True,
            text=True,
            timeout=600  # 10 minute timeout for long installs
        )
        return result.returncode == 0, result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        return False, "Command timed out"
    except Exception as e:
        return False, str(e)


def download_file(url, dest_path, progress_callback=None):
    """Download a file with progress"""
    try:
        response = urllib.request.urlopen(url)
        total_size = int(response.headers.get('content-length', 0))
        downloaded = 0
        block_size = 8192
        
        with open(dest_path, 'wb') as f:
            while True:
                buffer = response.read(block_size)
                if not buffer:
                    break
                downloaded += len(buffer)
                f.write(buffer)
                if progress_callback and total_size:
                    progress = int((downloaded / total_size) * 100)
                    progress_callback(progress)
        
        return True, f"Downloaded to {dest_path}"
    except Exception as e:
        return False, str(e)


# ═══════════════════════════════════════════════════════════════════════════════
# INSTALLER ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

class LucidInstaller:
    """Core installation engine"""
    
    def __init__(self, log_callback=None, progress_callback=None):
        self.log = log_callback or print
        self.progress = progress_callback or (lambda x: None)
        self.os_type, self.os_version, self.arch = get_os_info()
        self.errors = []
        self.warnings = []
        
    def log_info(self, msg):
        self.log(f"[INFO] {msg}")
        
    def log_ok(self, msg):
        self.log(f"[OK] {msg}")
        
    def log_warn(self, msg):
        self.warnings.append(msg)
        self.log(f"[WARN] {msg}")
        
    def log_error(self, msg):
        self.errors.append(msg)
        self.log(f"[ERROR] {msg}")
        
    def log_header(self, msg):
        self.log(f"\n{'='*60}")
        self.log(f"  {msg}")
        self.log(f"{'='*60}")
    
    # ─────────────────────────────────────────────────────────────────────────
    # STEP 1: System Check
    # ─────────────────────────────────────────────────────────────────────────
    
    def check_system(self):
        """Check system requirements"""
        self.log_header("PHASE 1: SYSTEM CHECK")
        self.progress(5)
        
        # OS Info
        self.log_info(f"Operating System: {self.os_type.upper()} {self.os_version}")
        self.log_info(f"Architecture: {self.arch}")
        self.log_info(f"Project Root: {PROJECT_ROOT}")
        
        # Python version
        py_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        if sys.version_info >= (3, 9):
            self.log_ok(f"Python {py_version}")
        else:
            self.log_error(f"Python {py_version} - Requires 3.9+")
            return False
        
        self.progress(10)
        
        # Check pip
        success, output = run_command([sys.executable, "-m", "pip", "--version"])
        if success:
            self.log_ok("pip available")
        else:
            self.log_error("pip not found")
            return False
        
        self.progress(15)
        
        # Check disk space (need at least 2GB)
        try:
            if self.os_type == "windows":
                import ctypes
                free_bytes = ctypes.c_ulonglong(0)
                ctypes.windll.kernel32.GetDiskFreeSpaceExW(
                    str(PROJECT_ROOT), None, None, ctypes.pointer(free_bytes)
                )
                free_gb = free_bytes.value / (1024**3)
            else:
                import shutil
                free_gb = shutil.disk_usage(PROJECT_ROOT).free / (1024**3)
            
            if free_gb >= 2:
                self.log_ok(f"Disk space: {free_gb:.1f} GB available")
            else:
                self.log_warn(f"Low disk space: {free_gb:.1f} GB (recommend 2+ GB)")
        except:
            self.log_warn("Could not check disk space")
        
        self.progress(20)
        return True
    
    # ─────────────────────────────────────────────────────────────────────────
    # STEP 2: Virtual Environment
    # ─────────────────────────────────────────────────────────────────────────
    
    def setup_venv(self):
        """Create or verify virtual environment"""
        self.log_header("PHASE 2: PYTHON ENVIRONMENT")
        self.progress(25)
        
        if VENV_PATH.exists():
            self.log_ok("Virtual environment exists")
        else:
            self.log_info("Creating virtual environment...")
            success, output = run_command([sys.executable, "-m", "venv", str(VENV_PATH)])
            if success:
                self.log_ok("Virtual environment created")
            else:
                self.log_error(f"Failed to create venv: {output}")
                return False
        
        self.progress(30)
        return True
    
    def get_pip_path(self):
        """Get path to pip in venv"""
        if self.os_type == "windows":
            return VENV_PATH / "Scripts" / "pip.exe"
        return VENV_PATH / "bin" / "pip"
    
    def get_python_path(self):
        """Get path to python in venv"""
        if self.os_type == "windows":
            return VENV_PATH / "Scripts" / "python.exe"
        return VENV_PATH / "bin" / "python"
    
    # ─────────────────────────────────────────────────────────────────────────
    # STEP 3: Python Dependencies
    # ─────────────────────────────────────────────────────────────────────────
    
    def install_dependencies(self):
        """Install Python dependencies"""
        self.log_header("PHASE 3: PYTHON DEPENDENCIES")
        self.progress(35)
        
        pip_path = self.get_pip_path()
        
        # Upgrade pip first
        self.log_info("Upgrading pip...")
        run_command([str(pip_path), "install", "--upgrade", "pip"])
        
        # Install from requirements.txt if exists
        req_file = PROJECT_ROOT / "requirements.txt"
        if req_file.exists():
            self.log_info("Installing from requirements.txt...")
            success, output = run_command(
                [str(pip_path), "install", "-r", str(req_file)],
                cwd=str(PROJECT_ROOT)
            )
            if success:
                self.log_ok("Requirements installed")
            else:
                self.log_warn("Some requirements may have failed")
        
        self.progress(45)
        
        # Ensure critical packages
        self.log_info("Ensuring critical packages...")
        for pkg in REQUIRED_PACKAGES:
            success, _ = run_command([str(pip_path), "install", pkg])
            if success:
                self.log_ok(f"  {pkg}")
            else:
                self.log_warn(f"  {pkg} - install issue")
        
        self.progress(55)
        return True
    
    # ─────────────────────────────────────────────────────────────────────────
    # STEP 4: Camoufox Binary
    # ─────────────────────────────────────────────────────────────────────────
    
    def install_camoufox(self):
        """Install Camoufox browser binary"""
        self.log_header("PHASE 4: CAMOUFOX BROWSER")
        self.progress(60)
        
        # Check if already installed
        if self.os_type == "windows":
            binary_path = CAMOUFOX_BIN_PATH / "camoufox-win" / "camoufox.exe"
            cache_path = CAMOUFOX_CACHE_WIN
        else:
            binary_path = CAMOUFOX_BIN_PATH / "camoufox-linux" / "camoufox"
            cache_path = CAMOUFOX_CACHE_LINUX
        
        if binary_path.exists():
            self.log_ok(f"Camoufox binary found: {binary_path.name}")
            
            # Ensure version.json exists in cache
            self._create_version_json(cache_path)
            self.progress(70)
            return True
        
        # Try using camoufox Python package to fetch
        self.log_info("Fetching Camoufox binary via Python package...")
        python_path = self.get_python_path()
        
        try:
            success, output = run_command(
                [str(python_path), "-c", "from camoufox.sync_api import Camoufox; print('OK')"],
                cwd=str(PROJECT_ROOT)
            )
            if "OK" in output:
                self.log_ok("Camoufox package available - binary will auto-download on first run")
                self._create_version_json(cache_path)
                self.progress(70)
                return True
        except:
            pass
        
        # Manual download fallback
        self.log_info("Manual download required...")
        url = CAMOUFOX_URLS.get(self.os_type)
        if not url:
            self.log_error(f"No download URL for {self.os_type}")
            return False
        
        # Download
        temp_file = PROJECT_ROOT / f"camoufox_download.{'zip' if self.os_type == 'windows' else 'tar.gz'}"
        self.log_info(f"Downloading Camoufox (~500MB)...")
        
        def progress_cb(pct):
            self.progress(60 + int(pct * 0.1))
            
        success, msg = download_file(url, temp_file, progress_cb)
        if not success:
            self.log_error(f"Download failed: {msg}")
            return False
        
        # Extract
        self.log_info("Extracting...")
        dest_dir = CAMOUFOX_BIN_PATH / f"camoufox-{self.os_type}"
        dest_dir.mkdir(parents=True, exist_ok=True)
        
        try:
            if self.os_type == "windows":
                with zipfile.ZipFile(temp_file, 'r') as zf:
                    zf.extractall(dest_dir)
            else:
                with tarfile.open(temp_file, 'r:gz') as tf:
                    tf.extractall(dest_dir)
            self.log_ok("Extracted successfully")
            temp_file.unlink()
        except Exception as e:
            self.log_error(f"Extraction failed: {e}")
            return False
        
        # Create version.json
        self._create_version_json(cache_path)
        
        self.progress(70)
        return True
    
    def _create_version_json(self, cache_path):
        """Create version.json for Camoufox"""
        cache_path.mkdir(parents=True, exist_ok=True)
        version_file = cache_path / "version.json"
        
        version_data = {
            "release": CAMOUFOX_RELEASE,
            "version": CAMOUFOX_VERSION
        }
        
        with open(version_file, 'w') as f:
            json.dump(version_data, f, indent=2)
        
        self.log_ok(f"Version file created: {version_file}")
    
    # ─────────────────────────────────────────────────────────────────────────
    # STEP 5: Assets & Models
    # ─────────────────────────────────────────────────────────────────────────
    
    def setup_assets(self):
        """Setup assets and models"""
        self.log_header("PHASE 5: ASSETS & MODELS")
        self.progress(75)
        
        # Create directories
        MODELS_PATH.mkdir(parents=True, exist_ok=True)
        PROFILE_PATH.mkdir(parents=True, exist_ok=True)
        
        # Check trajectory model
        model_file = MODELS_PATH / "ghost_motor_v5.pkl"
        if model_file.exists():
            self.log_ok("Trajectory model found")
        else:
            self.log_info("Generating trajectory model...")
            gen_script = PROJECT_ROOT / "scripts" / "generate_trajectory_model.py"
            if gen_script.exists():
                python_path = self.get_python_path()
                success, _ = run_command([str(python_path), str(gen_script)], cwd=str(PROJECT_ROOT))
                if success and model_file.exists():
                    self.log_ok("Trajectory model generated")
                else:
                    self.log_warn("Model generation issue - will use fallback")
            else:
                self.log_warn("Model generator not found - will use algorithmic fallback")
        
        self.progress(80)
        
        # Check profiles
        profile_dirs = [d for d in PROFILE_PATH.iterdir() if d.is_dir()] if PROFILE_PATH.exists() else []
        if profile_dirs:
            self.log_ok(f"Profiles available: {len(profile_dirs)}")
        else:
            self.log_info("No profiles yet - create via dashboard or CLI")
        
        self.progress(85)
        return True
    
    # ─────────────────────────────────────────────────────────────────────────
    # STEP 6: Verification
    # ─────────────────────────────────────────────────────────────────────────
    
    def verify_installation(self):
        """Run verification checks"""
        self.log_header("PHASE 6: VERIFICATION")
        self.progress(90)
        
        checks = []
        
        # Check 1: Python environment
        python_path = self.get_python_path()
        if python_path.exists():
            checks.append(("Python venv", True))
            self.log_ok("Python environment")
        else:
            checks.append(("Python venv", False))
            self.log_error("Python environment missing")
        
        # Check 2: Core modules
        try:
            success, output = run_command(
                [str(python_path), "-c", "from backend.firefox_injector import FirefoxProfileInjector; print('OK')"],
                cwd=str(PROJECT_ROOT)
            )
            if "OK" in output:
                checks.append(("Firefox Injector", True))
                self.log_ok("Firefox Injector module")
            else:
                checks.append(("Firefox Injector", False))
                self.log_warn("Firefox Injector import issue")
        except:
            checks.append(("Firefox Injector", False))
        
        # Check 3: Camoufox
        try:
            success, output = run_command(
                [str(python_path), "-c", "import camoufox; print('OK')"],
                cwd=str(PROJECT_ROOT)
            )
            if "OK" in output:
                checks.append(("Camoufox package", True))
                self.log_ok("Camoufox package")
            else:
                checks.append(("Camoufox package", False))
                self.log_warn("Camoufox import issue")
        except:
            checks.append(("Camoufox package", False))
        
        # Check 4: Launcher
        launcher = PROJECT_ROOT / "launch_lucid_browser.py"
        if launcher.exists():
            checks.append(("Browser launcher", True))
            self.log_ok("Browser launcher")
        else:
            checks.append(("Browser launcher", False))
            self.log_error("Browser launcher missing")
        
        # Check 5: Trajectory model
        model = MODELS_PATH / "ghost_motor_v5.pkl"
        if model.exists():
            checks.append(("Trajectory model", True))
            self.log_ok("Trajectory model")
        else:
            checks.append(("Trajectory model", False))
            self.log_warn("Trajectory model missing (will use fallback)")
        
        self.progress(95)
        
        # Summary
        passed = sum(1 for _, ok in checks if ok)
        total = len(checks)
        
        self.log("")
        self.log(f"{'='*60}")
        self.log(f"  VERIFICATION: {passed}/{total} checks passed")
        self.log(f"{'='*60}")
        
        self.progress(100)
        return passed >= total - 1  # Allow 1 non-critical failure
    
    # ─────────────────────────────────────────────────────────────────────────
    # MAIN INSTALLATION
    # ─────────────────────────────────────────────────────────────────────────
    
    def run_full_install(self):
        """Run complete installation"""
        start_time = datetime.now()
        
        self.log("")
        self.log("╔══════════════════════════════════════════════════════════╗")
        self.log("║     LUCID EMPIRE v5.0.0-TITAN INSTALLATION               ║")
        self.log("║     Anti-Detect Browser System                           ║")
        self.log("╚══════════════════════════════════════════════════════════╝")
        self.log("")
        
        steps = [
            ("System Check", self.check_system),
            ("Python Environment", self.setup_venv),
            ("Dependencies", self.install_dependencies),
            ("Camoufox Browser", self.install_camoufox),
            ("Assets & Models", self.setup_assets),
            ("Verification", self.verify_installation),
        ]
        
        for step_name, step_func in steps:
            try:
                if not step_func():
                    self.log_error(f"Step failed: {step_name}")
                    if step_name in ["System Check", "Python Environment"]:
                        return False
            except Exception as e:
                self.log_error(f"Exception in {step_name}: {e}")
                if step_name in ["System Check", "Python Environment"]:
                    return False
        
        elapsed = (datetime.now() - start_time).total_seconds()
        
        self.log("")
        self.log("╔══════════════════════════════════════════════════════════╗")
        self.log("║     INSTALLATION COMPLETE                                ║")
        self.log(f"║     Time: {elapsed:.1f} seconds                                   ║")
        self.log("╚══════════════════════════════════════════════════════════╝")
        self.log("")
        self.log("To launch the browser:")
        self.log(f"  python launch_lucid_browser.py --profile <name>")
        self.log("")
        self.log("To launch with target URL:")
        self.log(f"  python launch_lucid_browser.py --profile <name> --url <url>")
        self.log("")
        
        return len(self.errors) == 0


# ═══════════════════════════════════════════════════════════════════════════════
# GUI APPLICATION (Tkinter)
# ═══════════════════════════════════════════════════════════════════════════════

class LucidInstallerGUI:
    """Cross-platform GUI installer using tkinter"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("LUCID EMPIRE v5.0.0 - Installer")
        self.root.geometry("800x600")
        self.root.minsize(700, 500)
        
        # Dark theme colors
        self.bg_color = "#0a0a0f"
        self.fg_color = "#06b6d4"
        self.accent_color = "#10b981"
        self.error_color = "#ef4444"
        self.warn_color = "#f59e0b"
        self.btn_bg = "#1e293b"
        self.btn_hover = "#334155"
        
        self.root.configure(bg=self.bg_color)
        
        self._setup_styles()
        self._create_widgets()
        
        self.installer = None
        self.install_thread = None
        
    def _setup_styles(self):
        """Configure ttk styles"""
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configure colors
        style.configure("Dark.TFrame", background=self.bg_color)
        style.configure("Dark.TLabel", 
                       background=self.bg_color, 
                       foreground=self.fg_color,
                       font=("Consolas", 10))
        style.configure("Title.TLabel",
                       background=self.bg_color,
                       foreground="#ffffff",
                       font=("Consolas", 24, "bold"))
        style.configure("Subtitle.TLabel",
                       background=self.bg_color,
                       foreground="#64748b",
                       font=("Consolas", 10))
        
        # Progress bar
        style.configure("Cyan.Horizontal.TProgressbar",
                       background=self.fg_color,
                       troughcolor=self.btn_bg)
        
    def _create_widgets(self):
        """Create GUI widgets"""
        # Main frame
        main_frame = ttk.Frame(self.root, style="Dark.TFrame")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Header
        header_frame = ttk.Frame(main_frame, style="Dark.TFrame")
        header_frame.pack(fill=tk.X, pady=(0, 20))
        
        title = ttk.Label(header_frame, 
                         text="LUCID EMPIRE",
                         style="Title.TLabel")
        title.pack()
        
        subtitle = ttk.Label(header_frame,
                            text="v5.0.0-TITAN  •  ANTI-DETECT BROWSER SYSTEM",
                            style="Subtitle.TLabel")
        subtitle.pack()
        
        # OS Info
        os_type, os_ver, arch = get_os_info()
        os_label = ttk.Label(header_frame,
                            text=f"Platform: {os_type.upper()} {os_ver} ({arch})",
                            style="Dark.TLabel")
        os_label.pack(pady=(10, 0))
        
        # Progress bar
        progress_frame = ttk.Frame(main_frame, style="Dark.TFrame")
        progress_frame.pack(fill=tk.X, pady=10)
        
        self.progress_var = tk.DoubleVar(value=0)
        self.progress_bar = ttk.Progressbar(
            progress_frame,
            variable=self.progress_var,
            maximum=100,
            style="Cyan.Horizontal.TProgressbar",
            length=400
        )
        self.progress_bar.pack(fill=tk.X)
        
        self.progress_label = ttk.Label(progress_frame,
                                        text="Ready to install",
                                        style="Dark.TLabel")
        self.progress_label.pack(pady=(5, 0))
        
        # Log area
        log_frame = ttk.Frame(main_frame, style="Dark.TFrame")
        log_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.log_text = scrolledtext.ScrolledText(
            log_frame,
            bg="#0f0f14",
            fg=self.fg_color,
            font=("Consolas", 9),
            insertbackground=self.fg_color,
            relief=tk.FLAT,
            padx=10,
            pady=10
        )
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
        # Configure log tags
        self.log_text.tag_configure("ok", foreground=self.accent_color)
        self.log_text.tag_configure("error", foreground=self.error_color)
        self.log_text.tag_configure("warn", foreground=self.warn_color)
        self.log_text.tag_configure("info", foreground=self.fg_color)
        self.log_text.tag_configure("header", foreground="#ffffff", font=("Consolas", 9, "bold"))
        
        # Button frame
        btn_frame = ttk.Frame(main_frame, style="Dark.TFrame")
        btn_frame.pack(fill=tk.X, pady=(10, 0))
        
        # Install button
        self.install_btn = tk.Button(
            btn_frame,
            text="⚡ ONE-CLICK INSTALL",
            command=self.start_install,
            bg=self.fg_color,
            fg="#000000",
            font=("Consolas", 12, "bold"),
            relief=tk.FLAT,
            padx=30,
            pady=10,
            cursor="hand2"
        )
        self.install_btn.pack(side=tk.LEFT, padx=(0, 10))
        
        # Launch button
        self.launch_btn = tk.Button(
            btn_frame,
            text="🚀 LAUNCH BROWSER",
            command=self.launch_browser,
            bg=self.btn_bg,
            fg=self.fg_color,
            font=("Consolas", 12, "bold"),
            relief=tk.FLAT,
            padx=30,
            pady=10,
            cursor="hand2",
            state=tk.DISABLED
        )
        self.launch_btn.pack(side=tk.LEFT, padx=(0, 10))
        
        # Verify button
        self.verify_btn = tk.Button(
            btn_frame,
            text="✓ VERIFY",
            command=self.run_verify,
            bg=self.btn_bg,
            fg=self.fg_color,
            font=("Consolas", 12, "bold"),
            relief=tk.FLAT,
            padx=20,
            pady=10,
            cursor="hand2"
        )
        self.verify_btn.pack(side=tk.LEFT)
        
        # Exit button
        exit_btn = tk.Button(
            btn_frame,
            text="EXIT",
            command=self.root.quit,
            bg=self.btn_bg,
            fg="#64748b",
            font=("Consolas", 10),
            relief=tk.FLAT,
            padx=15,
            pady=10,
            cursor="hand2"
        )
        exit_btn.pack(side=tk.RIGHT)
        
    def log(self, message, tag="info"):
        """Add message to log"""
        self.log_text.configure(state=tk.NORMAL)
        
        # Determine tag based on content
        if message.startswith("[OK]"):
            tag = "ok"
        elif message.startswith("[ERROR]"):
            tag = "error"
        elif message.startswith("[WARN]"):
            tag = "warn"
        elif "===" in message:
            tag = "header"
        
        self.log_text.insert(tk.END, message + "\n", tag)
        self.log_text.see(tk.END)
        self.log_text.configure(state=tk.DISABLED)
        self.root.update_idletasks()
        
    def update_progress(self, value):
        """Update progress bar"""
        self.progress_var.set(value)
        self.progress_label.configure(text=f"Progress: {value}%")
        self.root.update_idletasks()
        
    def start_install(self):
        """Start installation in background thread"""
        self.install_btn.configure(state=tk.DISABLED, text="Installing...")
        self.verify_btn.configure(state=tk.DISABLED)
        self.log_text.configure(state=tk.NORMAL)
        self.log_text.delete(1.0, tk.END)
        self.log_text.configure(state=tk.DISABLED)
        
        def install_worker():
            self.installer = LucidInstaller(
                log_callback=self.log,
                progress_callback=self.update_progress
            )
            success = self.installer.run_full_install()
            
            self.root.after(0, lambda: self.install_complete(success))
        
        self.install_thread = threading.Thread(target=install_worker, daemon=True)
        self.install_thread.start()
        
    def install_complete(self, success):
        """Called when installation completes"""
        self.install_btn.configure(state=tk.NORMAL, text="⚡ ONE-CLICK INSTALL")
        self.verify_btn.configure(state=tk.NORMAL)
        
        if success:
            self.launch_btn.configure(state=tk.NORMAL)
            self.progress_label.configure(text="Installation Complete!")
            messagebox.showinfo(
                "Installation Complete",
                "LUCID EMPIRE has been installed successfully!\n\n"
                "Click 'LAUNCH BROWSER' to start."
            )
        else:
            self.progress_label.configure(text="Installation had errors")
            messagebox.showwarning(
                "Installation Warning",
                "Installation completed with some issues.\n\n"
                "Check the log for details."
            )
    
    def run_verify(self):
        """Run verification only"""
        self.log_text.configure(state=tk.NORMAL)
        self.log_text.delete(1.0, tk.END)
        self.log_text.configure(state=tk.DISABLED)
        
        def verify_worker():
            installer = LucidInstaller(
                log_callback=self.log,
                progress_callback=self.update_progress
            )
            installer.verify_installation()
        
        threading.Thread(target=verify_worker, daemon=True).start()
        
    def launch_browser(self):
        """Launch the browser"""
        self.log("\nLaunching LUCID Browser...")
        
        python_path = VENV_PATH / ("Scripts" if get_os_info()[0] == "windows" else "bin") / "python"
        if get_os_info()[0] == "windows":
            python_path = python_path.with_suffix(".exe")
        
        launcher = PROJECT_ROOT / "launch_lucid_browser.py"
        
        if launcher.exists() and python_path.exists():
            try:
                subprocess.Popen(
                    [str(python_path), str(launcher), "--list-profiles"],
                    cwd=str(PROJECT_ROOT)
                )
                self.log("[OK] Browser launcher started")
            except Exception as e:
                self.log(f"[ERROR] Failed to launch: {e}")
                messagebox.showerror("Launch Error", str(e))
        else:
            self.log("[ERROR] Launcher or Python not found")
            messagebox.showerror(
                "Launch Error",
                "Launcher or Python environment not found.\n"
                "Please run installation first."
            )
    
    def run(self):
        """Start the GUI"""
        # Center window
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f"+{x}+{y}")
        
        self.root.mainloop()


# ═══════════════════════════════════════════════════════════════════════════════
# CLI MODE (Fallback)
# ═══════════════════════════════════════════════════════════════════════════════

def run_cli_install():
    """Run installation in CLI mode"""
    print("")
    print("╔══════════════════════════════════════════════════════════╗")
    print("║  LUCID EMPIRE v5.0.0-TITAN :: CLI INSTALLER              ║")
    print("╚══════════════════════════════════════════════════════════╝")
    print("")
    
    installer = LucidInstaller()
    success = installer.run_full_install()
    
    return 0 if success else 1


# ═══════════════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    """Main entry point"""
    # Check for CLI mode flag
    if "--cli" in sys.argv or not HAS_TK:
        return run_cli_install()
    
    # Run GUI
    try:
        app = LucidInstallerGUI()
        app.run()
        return 0
    except Exception as e:
        print(f"[ERROR] GUI failed: {e}")
        print("[INFO] Falling back to CLI mode...")
        return run_cli_install()


if __name__ == "__main__":
    sys.exit(main())
