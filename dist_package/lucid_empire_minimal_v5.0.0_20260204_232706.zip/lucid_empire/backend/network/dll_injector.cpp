/* LUCID EMPIRE STEALTH Class - DLL Injector
 * Purpose: Inject TimeShift.dll into target browser process
 * Platform: Windows 10/11 with API hooking
 * Features: Process injection, stealth deployment, EDR evasion
 */

#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>
#include <stdio.h>
#include <string.h>
#include <iostream>
#include <string>

/* Configuration */
#define TARGET_PROCESS L"firefox.exe"
#define DLL_NAME L"TimeShift.dll"
#define CONFIG_NAME L"TimeShift.conf"

/* Injection methods */
typedef enum {
    INJECT_METHOD_CREATE_REMOTE_THREAD,
    INJECT_METHOD_QUEUE_USER_APC,
    INJECT_METHOD_SET_WINDOWS_HOOK_EX
} INJECTION_METHOD;

/* Global state */
static INJECTION_METHOD g_method = INJECT_METHOD_CREATE_REMOTE_THREAD;
static BOOL g_verbose = FALSE;
static BOOL g_stealth = TRUE;

/* Logging functions */
static void log_info(const wchar_t* format, ...) {
    if (!g_verbose) return;
    
    wchar_t buffer[1024];
    va_list args;
    va_start(args, format);
    vswprintf_s(buffer, sizeof(buffer), format, args);
    va_end(args);
    
    wprintf(L"[INFO] %s\n", buffer);
}

static void log_error(const wchar_t* format, ...) {
    wchar_t buffer[1024];
    va_list args;
    va_start(args, format);
    vswprintf_s(buffer, sizeof(buffer), format, args);
    va_end(args);
    
    wprintf(L"[ERROR] %s\n", buffer);
}

/* Check if running with administrator privileges */
static BOOL is_admin(void) {
    BOOL result = FALSE;
    SID_IDENTIFIER_AUTHORITY authority = SECURITY_NT_AUTHORITY;
    PSID admin_sid = NULL;
    
    if (AllocateAndInitializeSid(&authority, 2, SECURITY_BUILTIN_DOMAIN_RID,
                                DOMAIN_ALIAS_RID_ADMINS, 0, 0, 0, 0, 0, 0, &admin_sid)) {
        CheckTokenMembership(NULL, admin_sid, &result);
        FreeSid(admin_sid);
    }
    
    return result;
}

/* Find process by name */
static DWORD find_process(const wchar_t* process_name) {
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) {
        log_error(L"Failed to create process snapshot");
        return 0;
    }
    
    PROCESSENTRY32 pe32;
    pe32.dwSize = sizeof(PROCESSENTRY32);
    
    if (!Process32First(snapshot, &pe32)) {
        CloseHandle(snapshot);
        log_error(L"Failed to enumerate processes");
        return 0;
    }
    
    DWORD pid = 0;
    do {
        if (_wcsicmp(pe32.szExeFile, process_name) == 0) {
            pid = pe32.th32ProcessID;
            log_info(L"Found process %s with PID %d", process_name, pid);
            break;
        }
    } while (Process32Next(snapshot, &pe32));
    
    CloseHandle(snapshot);
    return pid;
}

/* Enable debug privileges for injection */
static BOOL enable_debug_privileges(void) {
    HANDLE token;
    TOKEN_PRIVILEGES privileges;
    LUID luid;
    
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token)) {
        log_error(L"Failed to open process token");
        return FALSE;
    }
    
    if (!LookupPrivilegeValue(NULL, L"SeDebugPrivilege", &luid)) {
        log_error(L"Failed to lookup debug privilege");
        CloseHandle(token);
        return FALSE;
    }
    
    privileges.PrivilegeCount = 1;
    privileges.Privileges[0].Luid = luid;
    privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    
    if (!AdjustTokenPrivileges(token, FALSE, &privileges, 0, NULL, NULL)) {
        log_error(L"Failed to adjust token privileges");
        CloseHandle(token);
        return FALSE;
    }
    
    CloseHandle(token);
    log_info(L"Debug privileges enabled");
    return TRUE;
}

/* Create remote thread injection method */
static BOOL inject_create_remote_thread(DWORD pid, const wchar_t* dll_path) {
    HANDLE hProcess = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ, FALSE, pid);
    if (!hProcess) {
        log_error(L"Failed to open target process (PID %d)", pid);
        return FALSE;
    }
    
    /* Allocate memory in target process */
    SIZE_T path_len = (wcslen(dll_path) + 1) * sizeof(wchar_t);
    LPVOID remote_mem = VirtualAllocEx(hProcess, NULL, path_len, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remote_mem) {
        log_error(L"Failed to allocate memory in target process");
        CloseHandle(hProcess);
        return FALSE;
    }
    
    /* Write DLL path to target process */
    if (!WriteProcessMemory(hProcess, remote_mem, dll_path, path_len, NULL)) {
        log_error(L"Failed to write DLL path to target process");
        VirtualFreeEx(hProcess, remote_mem, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        return FALSE;
    }
    
    /* Get LoadLibraryW address */
    HMODULE kernel32 = GetModuleHandle(L"kernel32.dll");
    FARPROC load_library = GetProcAddress(kernel32, "LoadLibraryW");
    if (!load_library) {
        log_error(L"Failed to get LoadLibraryW address");
        VirtualFreeEx(hProcess, remote_mem, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        return FALSE;
    }
    
    /* Create remote thread */
    HANDLE hThread = CreateRemoteThread(hProcess, NULL, 0, (LPTHREAD_START_ROUTINE)load_library, remote_mem, 0, NULL);
    if (!hThread) {
        log_error(L"Failed to create remote thread");
        VirtualFreeEx(hProcess, remote_mem, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        return FALSE;
    }
    
    log_info(L"Remote thread created, waiting for DLL load...");
    
    /* Wait for thread completion */
    WaitForSingleObject(hThread, 5000);
    
    /* Check if DLL was loaded successfully */
    DWORD exit_code;
    if (GetExitCodeThread(hThread, &exit_code)) {
        if (exit_code == 0) {
            log_error(L"DLL failed to load in target process");
        } else {
            log_info(L"DLL loaded successfully at address 0x%p in target process", (void*)exit_code);
        }
    }
    
    /* Cleanup */
    CloseHandle(hThread);
    VirtualFreeEx(hProcess, remote_mem, 0, MEM_RELEASE);
    CloseHandle(hProcess);
    
    return TRUE;
}

/* Create configuration file for TimeShift DLL */
static BOOL create_config_file(const wchar_t* config_path, int days_offset) {
    /* Configuration structure */
    typedef struct {
        BOOL enabled;
        LARGE_INTEGER time_offset;
        SYSTEMTIME base_time;
        DWORD target_pid;
        char log_file[MAX_PATH];
    } TIME_CONFIG;
    
    TIME_CONFIG config = {0};
    config.enabled = TRUE;
    config.time_offset.QuadPart = -(LONGLONG)days_offset * 24 * 60 * 60 * 10000000; /* days_offset days in 100ns units */
    GetSystemTime(&config.base_time);
    config.target_pid = GetCurrentProcessId();
    
    /* Convert config path to ANSI for log file */
    char config_ansi[MAX_PATH];
    WideCharToMultiByte(CP_ACP, 0, config_path, -1, config_ansi, sizeof(config_ansi), NULL, NULL);
    strcpy_s(config.log_file, sizeof(config.log_file), config_ansi);
    strcpy_s(strrchr(config.log_file, '.'), sizeof(config.log_file) - (config.log_file - strrchr(config.log_file, '.')), ".log");
    
    HANDLE hFile = CreateFileW(config_path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        log_error(L"Failed to create config file");
        return FALSE;
    }
    
    DWORD written;
    if (!WriteFile(hFile, &config, sizeof(config), &written, NULL) || written != sizeof(config)) {
        log_error(L"Failed to write config file");
        CloseHandle(hFile);
        return FALSE;
    }
    
    CloseHandle(hFile);
    log_info(L"Configuration file created: %s (offset: %d days)", config_path, days_offset);
    return TRUE;
}

/* Check for EDR/AV interference */
static BOOL check_edr_presence(void) {
    /* Check for common EDR processes */
    const wchar_t* edr_processes[] = {
        L"msmpeng.exe",      /* Windows Defender */
        L"MsMpEng.exe",
        L"procexp64.exe",    /* Process Explorer */
        L"procmon.exe",      /* Process Monitor */
        L"Wireshark.exe",    /* Network analysis */
        NULL
    };
    
    for (int i = 0; edr_processes[i]; i++) {
        if (find_process(edr_processes[i])) {
            log_info(L"EDR/AV process detected: %s", edr_processes[i]);
            return TRUE;
        }
    }
    
    return FALSE;
}

/* Validate Iron Rules compliance */
static BOOL validate_iron_rules(void) {
    log_info(L"Validating Iron Rules compliance...");
    
    /* WR-1: Token Elevation */
    if (!is_admin()) {
        log_error(L"Iron Rule WR-1 violation: Administrator privileges required");
        return FALSE;
    }
    log_info(L"✓ WR-1: Administrator privileges confirmed");
    
    /* WR-2: Defense Evasion - Check Windows Defender exclusions */
    /* This is a simplified check - in production, you'd verify registry keys */
    log_info(L"⚠ WR-2: Windows Defender exclusion check (manual verification recommended)");
    
    /* WR-3: API Visibility - Check firewall */
    /* Simplified check for port 8000 */
    SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock != INVALID_HANDLE_VALUE) {
        sockaddr_in addr = {0};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = inet_addr("127.0.0.1");
        addr.sin_port = htons(8000);
        
        if (connect(sock, (sockaddr*)&addr, sizeof(addr)) == 0) {
            log_info(L"✓ WR-3: Port 8000 accessible");
        } else {
            log_info(L"⚠ WR-3: Port 8000 not accessible (firewall may be blocking)");
        }
        closesocket(sock);
    }
    
    log_info(L"Iron Rules validation complete");
    return TRUE;
}

/* Print usage information */
static void print_usage(const wchar_t* prog_name) {
    wprintf(L"LUCID EMPIRE STEALTH Class - DLL Injector\n");
    wprintf(L"=========================================\n\n");
    wprintf(L"Usage: %s [options]\n\n", prog_name);
    wprintf(L"Options:\n");
    wprintf(L"  -p, --pid PID          Target process ID\n");
    wprintf(L"  -n, --name NAME        Target process name (default: firefox.exe)\n");
    wprintf(L"  -d, --days DAYS        Time offset in days (default: 90)\n");
    wprintf(L"  -m, --method METHOD    Injection method:\n");
    wprintf(L"                           1 = CreateRemoteThread (default)\n");
    wprintf(L"                           2 = QueueUserAPC\n");
    wprintf(L"                           3 = SetWindowsHookEx\n");
    wprintf(L"  -v, --verbose          Enable verbose logging\n");
    wprintf(L"  -s, --stealth          Enable stealth mode (default)\n");
    wprintf(L"  --no-stealth           Disable stealth mode\n");
    wprintf(L"  -h, --help             Show this help\n\n");
    wprintf(L"Iron Rules:\n");
    wprintf(L"  WR-1: Requires Administrator privileges\n");
    wprintf(L"  WR-2: Windows Defender exclusion required\n");
    wprintf(L"  WR-3: Firewall rule for port 8000 required\n");
    wprintf(L"  WR-4: Target process must be running\n");
    wprintf(L"  WR-5: Time hook must be active\n\n");
}

/* Main function */
int wmain(int argc, wchar_t* argv[]) {
    DWORD target_pid = 0;
    const wchar_t* target_name = TARGET_PROCESS;
    int days_offset = 90;
    
    /* Parse command line arguments */
    for (int i = 1; i < argc; i++) {
        if (_wcsicmp(argv[i], L"-h") == 0 || _wcsicmp(argv[i], L"--help") == 0) {
            print_usage(argv[0]);
            return 0;
        } else if (_wcsicmp(argv[i], L"-v") == 0 || _wcsicmp(argv[i], L"--verbose") == 0) {
            g_verbose = TRUE;
        } else if (_wcsicmp(argv[i], L"-s") == 0 || _wcsicmp(argv[i], L"--stealth") == 0) {
            g_stealth = TRUE;
        } else if (_wcsicmp(argv[i], L"--no-stealth") == 0) {
            g_stealth = FALSE;
        } else if (_wcsicmp(argv[i], L"-p") == 0 || _wcsicmp(argv[i], L"--pid") == 0) {
            if (i + 1 < argc) {
                target_pid = _wtoi(argv[++i]);
            }
        } else if (_wcsicmp(argv[i], L"-n") == 0 || _wcsicmp(argv[i], L"--name") == 0) {
            if (i + 1 < argc) {
                target_name = argv[++i];
            }
        } else if (_wcsicmp(argv[i], L"-d") == 0 || _wcsicmp(argv[i], L"--days") == 0) {
            if (i + 1 < argc) {
                days_offset = _wtoi(argv[++i]);
            }
        } else if (_wcsicmp(argv[i], L"-m") == 0 || _wcsicmp(argv[i], L"--method") == 0) {
            if (i + 1 < argc) {
                int method = _wtoi(argv[++i]);
                if (method >= 1 && method <= 3) {
                    g_method = (INJECTION_METHOD)method;
                }
            }
        }
    }
    
    wprintf(L"LUCID EMPIRE STEALTH Class - DLL Injector\n");
    wprintf(L"=========================================\n");
    
    /* Validate Iron Rules */
    if (!validate_iron_rules()) {
        wprintf(L"[-] Iron Rules validation failed\n");
        return 1;
    }
    
    /* Check for EDR presence */
    if (g_stealth && check_edr_presence()) {
        wprintf(L"[!] EDR/AV processes detected - stealth mode recommended\n");
    }
    
    /* Enable debug privileges */
    if (!enable_debug_privileges()) {
        wprintf(L"[-] Failed to enable debug privileges\n");
        return 1;
    }
    
    /* Find target process */
    if (target_pid == 0) {
        target_pid = find_process(target_name);
        if (target_pid == 0) {
            wprintf(L"[-] Target process '%s' not found\n", target_name);
            wprintf(L"[*] Make sure the browser is running before injection\n");
            return 1;
        }
    }
    
    /* Get current directory and construct paths */
    wchar_t dll_path[MAX_PATH];
    wchar_t config_path[MAX_PATH];
    GetCurrentDirectory(MAX_PATH, dll_path);
    wcscat_s(dll_path, L"\\");
    wcscat_s(dll_path, DLL_NAME);
    
    wcscpy_s(config_path, MAX_PATH, dll_path);
    wcscpy_s(wcsrchr(config_path, '.'), MAX_PATH - (config_path - wcsrchr(config_path, '.')), L".conf");
    
    /* Verify DLL exists */
    if (GetFileAttributesW(dll_path) == INVALID_FILE_ATTRIBUTES) {
        wprintf(L"[-] DLL not found: %s\n", dll_path);
        wprintf(L"[*] Make sure TimeShift.dll is in the current directory\n");
        return 1;
    }
    
    /* Create configuration file */
    if (!create_config_file(config_path, days_offset)) {
        wprintf(L"[-] Failed to create configuration file\n");
        return 1;
    }
    
    /* Perform injection */
    wprintf(L"[*] Injecting DLL into process %d...\n", target_pid);
    wprintf(L"[*] DLL: %s\n", dll_path);
    wprintf(L"[*] Config: %s\n", config_path);
    wprintf(L"[*] Time offset: %d days\n", days_offset);
    
    BOOL success = FALSE;
    
    switch (g_method) {
    case INJECT_METHOD_CREATE_REMOTE_THREAD:
        wprintf(L"[*] Using CreateRemoteThread injection method\n");
        success = inject_create_remote_thread(target_pid, dll_path);
        break;
        
    case INJECT_METHOD_QUEUE_USER_APC:
        wprintf(L"[*] QueueUserAPC method not implemented\n");
        break;
        
    case INJECT_METHOD_SET_WINDOWS_HOOK_EX:
        wprintf(L"[*] SetWindowsHookEx method not implemented\n");
        break;
    }
    
    if (success) {
        wprintf(L"[+] DLL injection completed successfully\n");
        wprintf(L"[+] TimeShift hooks are now active in target process\n");
        wprintf(L"[+] Check TimeShift.log for injection details\n");
    } else {
        wprintf(L"[-] DLL injection failed\n");
        return 1;
    }
    
    return 0;
}
