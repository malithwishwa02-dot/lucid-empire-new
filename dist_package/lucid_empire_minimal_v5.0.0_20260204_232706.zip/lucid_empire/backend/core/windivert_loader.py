"""
LUCID EMPIRE v5 TITAN :: WINDOWS NETWORK LOADER
Authority: Dva.12
Platform: Windows 10/11 (DLL Injection + WinAPI)

This module handles network masking on Windows through DLL injection
and WinAPI hooks. This provides user-mode network interception for
TTL normalization, window size manipulation, and time injection.
"""

import os
import sys
import ctypes
import logging
import subprocess
import platform
from pathlib import Path
from typing import Optional
from ctypes import wintypes

logger = logging.getLogger(__name__)

class WindowsNetworkLoader:
    """
    Windows Network Masking Loader
    
    Provides user-mode network masking through DLL injection and WinAPI hooks.
    This is the "Stealth" method for network masking on Windows.
    """
    
    def __init__(self):
        """Initialize Windows network loader"""
        self.kernel32 = ctypes.WinDLL("kernel32", use_errno=True)
        self.ntdll = ctypes.CDLL("ntdll", use_errno=True)
        self.is_admin = self._check_admin()
        self.required_dlls = []
        
        logger.info(f"Windows Network Loader initialized. Admin: {self.is_admin}")
    
    @staticmethod
    def _check_admin() -> bool:
        """
        Check if running as Administrator
        
        Returns:
            True if running with admin privileges
        """
        try:
            return ctypes.windll.shell32.IsUserAnAdmin()
        except Exception:
            return False
    
    def check_privileges(self) -> bool:
        """
        Verify Administrator privileges
        
        Returns:
            True if sufficient privileges
        """
        if not self.is_admin:
            logger.error("Administrator privileges required for network operations")
            logger.info("Please run PowerShell as Administrator")
            return False
        
        logger.info("✓ Running with Administrator privileges")
        return True
    
    def check_os_version(self) -> bool:
        """
        Check Windows version (require Windows 10+)
        
        Returns:
            True if compatible
        """
        version_info = sys.getwindowsversion()
        
        if version_info.major < 10:
            logger.error(f"Windows {version_info.major} not supported (require 10+)")
            return False
        
        if version_info.major == 10:
            os_name = "Windows 10"
        elif version_info.major == 11:
            os_name = "Windows 11"
        else:
            os_name = f"Windows {version_info.major}"
        
        logger.info(f"✓ Detected: {os_name} (Build {version_info.build})")
        return True
    
    def inject_ttl_dll(self, target_process_id: int, dll_path: str) -> bool:
        """
        Inject TTL manipulation DLL into target process
        
        This DLL hooks WinAPI socket functions to modify TTL values
        to appear as Windows (TTL=128) instead of Linux (TTL=64)
        
        Args:
            target_process_id: PID of target process
            dll_path: Path to TTL manipulation DLL
            
        Returns:
            True if injection successful
        """
        if not Path(dll_path).exists():
            logger.error(f"DLL not found: {dll_path}")
            return False
        
        if not self.check_privileges():
            return False
        
        try:
            logger.info(f"Injecting TTL DLL into process {target_process_id}")
            
            # Open process with required permissions
            PROCESS_ALL_ACCESS = 0x1F0FFF
            h_process = self.kernel32.OpenProcess(PROCESS_ALL_ACCESS, False, target_process_id)
            
            if not h_process:
                logger.error(f"Could not open process {target_process_id}")
                return False
            
            # Allocate memory for DLL path
            dll_path_bytes = dll_path.encode('utf-8')
            dll_len = len(dll_path_bytes) + 1
            
            p_dll_path = self.kernel32.VirtualAllocEx(
                h_process,
                None,
                dll_len,
                0x1000,  # MEM_COMMIT
                0x04     # PAGE_READWRITE
            )
            
            if not p_dll_path:
                logger.error("VirtualAllocEx failed")
                self.kernel32.CloseHandle(h_process)
                return False
            
            # Write DLL path to process memory
            written = wintypes.SIZE_T()
            success = self.kernel32.WriteProcessMemory(
                h_process,
                p_dll_path,
                dll_path_bytes,
                dll_len,
                ctypes.byref(written)
            )
            
            if not success:
                logger.error("WriteProcessMemory failed")
                self.kernel32.VirtualFreeEx(h_process, p_dll_path, 0, 0x8000)
                self.kernel32.CloseHandle(h_process)
                return False
            
            # Create remote thread to call LoadLibraryA
            load_lib_a = self.kernel32.GetProcAddress(
                self.kernel32.GetModuleHandleA(b"kernel32.dll"),
                b"LoadLibraryA"
            )
            
            h_thread = self.kernel32.CreateRemoteThread(
                h_process,
                None,
                0,
                load_lib_a,
                p_dll_path,
                0,
                None
            )
            
            if not h_thread:
                logger.error("CreateRemoteThread failed")
                self.kernel32.VirtualFreeEx(h_process, p_dll_path, 0, 0x8000)
                self.kernel32.CloseHandle(h_process)
                return False
            
            # Wait for thread to complete
            self.kernel32.WaitForSingleObject(h_thread, 0xFFFFFFFF)  # INFINITE
            
            # Cleanup
            self.kernel32.VirtualFreeEx(h_process, p_dll_path, 0, 0x8000)
            self.kernel32.CloseHandle(h_thread)
            self.kernel32.CloseHandle(h_process)
            
            logger.info(f"✓ TTL DLL injected into process {target_process_id}")
            return True
            
        except Exception as e:
            logger.error(f"DLL injection failed: {e}")
            return False
    
    def setup_defender_exclusion(self, path: str) -> bool:
        """
        Add path to Windows Defender exclusions
        
        This prevents false positives from DLL injection activities
        
        Args:
            path: Path to exclude from scanning
            
        Returns:
            True if successful
        """
        if not self.check_privileges():
            return False
        
        try:
            logger.info(f"Adding Windows Defender exclusion: {path}")
            
            # Use PowerShell to add exclusion
            ps_cmd = f'Add-MpPreference -ExclusionPath "{path}" -Force'
            
            result = subprocess.run(
                ["powershell.exe", "-Command", ps_cmd],
                capture_output=True,
                timeout=30
            )
            
            if result.returncode == 0:
                logger.info(f"✓ Defender exclusion added: {path}")
                return True
            else:
                logger.warning(f"Defender exclusion failed: {result.stderr.decode()}")
                return False
                
        except Exception as e:
            logger.error(f"Defender exclusion error: {e}")
            return False
    
    def setup_firewall_rule(self, port: int = 8000) -> bool:
        """
        Create Windows Firewall rule for API port
        
        Args:
            port: Port number to allow
            
        Returns:
            True if successful
        """
        if not self.check_privileges():
            return False
        
        try:
            logger.info(f"Creating firewall rule for port {port}")
            
            ps_cmd = (
                f'New-NetFirewallRule -DisplayName "LUCID EMPIRE - API Server" '
                f'-Direction Inbound -LocalPort {port} -Protocol TCP '
                f'-Action Allow -ErrorAction SilentlyContinue'
            )
            
            result = subprocess.run(
                ["powershell.exe", "-Command", ps_cmd],
                capture_output=True,
                timeout=30
            )
            
            if result.returncode == 0:
                logger.info(f"✓ Firewall rule created for port {port}")
                return True
            else:
                logger.warning(f"Firewall rule creation warning: {result.stderr.decode()}")
                return False
                
        except Exception as e:
            logger.error(f"Firewall rule error: {e}")
            return False
    
    def check_windivert(self) -> bool:
        """
        Check if WinDivert driver is available
        
        WinDivert allows packet-level network filtering
        
        Returns:
            True if WinDivert is installed
        """
        try:
            # Check registry for WinDivert
            import winreg
            
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, 
                              r"SYSTEM\CurrentControlSet\Services\WinDivert") as key:
                logger.info("✓ WinDivert driver found")
                return True
                
        except Exception:
            logger.warning("WinDivert driver not found")
            logger.info("Download from: https://reqrypt.org/windivert.html")
            return False
    
    def check_required_dlls(self) -> dict:
        """
        Check for required DLL files
        
        Returns:
            Dictionary of DLL availability
        """
        dlls = {
            "TimeShift.dll": self._find_dll("TimeShift.dll"),
            "WinDivert.dll": self._find_dll("WinDivert.dll"),
            "mscoree.dll": Path("C:\\Windows\\System32\\mscoree.dll").exists()
        }
        
        for dll, found in dlls.items():
            status = "✓" if found else "✗"
            logger.info(f"{status} {dll}: {'Found' if found else 'Not found'}")
        
        return dlls
    
    @staticmethod
    def _find_dll(dll_name: str) -> bool:
        """
        Search for DLL in common locations
        
        Args:
            dll_name: DLL filename
            
        Returns:
            True if found
        """
        search_paths = [
            Path("C:\\Program Files\\LucidEmpire\\lib") / dll_name,
            Path("C:\\Program Files (x86)\\LucidEmpire\\lib") / dll_name,
            Path(os.path.expanduser("~/.lucid-empire/lib")) / dll_name,
            Path("C:\\Windows\\System32") / dll_name,
        ]
        
        for path in search_paths:
            if path.exists():
                return True
        
        return False
    
    def get_firefox_processes(self) -> list:
        """
        Get list of Firefox process IDs
        
        Returns:
            List of Firefox PIDs
        """
        try:
            result = subprocess.run(
                ["tasklist", "/FI", "IMAGENAME eq firefox.exe", "/FO", "CSV", "/NH"],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            pids = []
            for line in result.stdout.split('\n'):
                if 'firefox.exe' in line:
                    parts = line.split(',')
                    if len(parts) >= 2:
                        try:
                            pid = int(parts[1].strip().strip('"'))
                            pids.append(pid)
                        except ValueError:
                            pass
            
            logger.info(f"Found {len(pids)} Firefox processes: {pids}")
            return pids
            
        except Exception as e:
            logger.error(f"Could not enumerate Firefox processes: {e}")
            return []


class TimeInjectionLoader:
    """
    Windows Time Injection Handler
    
    Manages time injection into processes for temporal masking
    """
    
    def __init__(self):
        """Initialize time injection handler"""
        self.runasdate_exe = "C:\\Program Files\\LucidEmpire\\bin\\RunAsDate.exe"
    
    def inject_date_into_process(self, process_id: int, fake_date: str) -> bool:
        """
        Inject fake date into process
        
        Uses RunAsDate or custom DLL injection to make process see
        a different system date
        
        Args:
            process_id: Target process ID
            fake_date: Date string (e.g., "01/15/2024")
            
        Returns:
            True if successful
        """
        try:
            logger.info(f"Injecting date into process {process_id}: {fake_date}")
            
            if Path(self.runasdate_exe).exists():
                # Use RunAsDate
                cmd = [self.runasdate_exe, "/pid", str(process_id), "/date", fake_date]
                result = subprocess.run(cmd, capture_output=True, timeout=10)
                
                if result.returncode == 0:
                    logger.info(f"✓ Date injected via RunAsDate")
                    return True
            
            logger.warning("RunAsDate not available, using system date")
            return False
            
        except Exception as e:
            logger.error(f"Time injection failed: {e}")
            return False


def get_windows_loader() -> Optional[WindowsNetworkLoader]:
    """
    Factory function to get Windows loader if available
    
    Returns:
        WindowsNetworkLoader instance or None
    """
    try:
        loader = WindowsNetworkLoader()
        
        # Run basic checks
        if not loader.check_os_version():
            logger.error("Unsupported Windows version")
            return None
        
        if not loader.check_privileges():
            logger.error("Administrator privileges required")
            return None
        
        logger.info("✓ Windows loader ready")
        return loader
        
    except Exception as e:
        logger.error(f"Windows loader initialization failed: {e}")
        return None


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    loader = get_windows_loader()
    if loader:
        print("Windows Loader Status: OK")
        print(f"Admin: {loader.is_admin}")
        print(f"Firefox processes: {loader.get_firefox_processes()}")
        loader.check_required_dlls()
    else:
        print("Windows Loader Status: UNAVAILABLE")
